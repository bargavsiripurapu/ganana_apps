<?php
/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  TORQUE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * Reads and stores torque information which is running as background process
 * using cron jobs
 *
 * @category Job_Submission_Portal
 * @package  TORQUE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class CrawlerController extends Controller
{

    /**
     * Specifies Access Rules for this controller
     *
     * @return Array with the access details
     */
    public function accessRules() 
    {
        return array(
            array('allow', 
                'actions' => array('index', 'view'),
                'users' => array('*'),
            ),
        );
    }

    /**
     * Performs before processing request, required operations here
     *
     * @param Object $action specifies which type of action
     *
     * @return true for further processing
     */
    public function beforeAction($action) 
    {
        /* foreach (Yii::app()->log->routes as $route) {
            if ($route instanceof CWebLogRoute) {
                $route->enabled = false;
            }
        } */
        return true;
    }

    /**
     * Calls required function based on specified id
     * 
     * @param string $id Identifier
     * 
     * @return NULL
     */
    public function actionIndex($id = null) 
    {
        $str = "";
        if (isset($_POST['data'])) {
            $str = $_POST['data'];
        }
        switch ($id) {
        case "jobs":
            /*
            if ($str == "") {
                $host = Yii::app()->params->GHPCS['masterserverip'];
                $user = GhpcsUser::model()->find("username='admin'");
                $userId = $user->id;
                $sshHost = new GSsh(array('host' => $host));
                if ($sshHost->getConnected() 
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $cmd = "qstat -x;echo $?";
                    $response = REQUIRED::lastCommandExitStatus(
                        $sshHost->cmd($cmd)
                    );
                    if (isset($response['status']) && $response['status']) {
                        $str = $response['message'];
                    }
                    $sshHost->disconnect();
                }
            } */
            $updated = CrawlerController::updateJobInfo($str);
            if ($updated) {
                echo "SUCCESS";
            }
            break;
        case "nodes":
            if ($str == "") {
                $host = Yii::app()->params->GHPCS['masterserverip'];
                $user = GhpcsUser::model()->find("username='admin'");
                $userId = $user->id;
                $sshHost = new GSsh(array('host' => $host));
                if ($sshHost->getConnected() 
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $cmd = base64_decode(
                        "cGJzbm9kZXMgLWEgfCBzZWQgJ3MvXiBcKy8vZycgfGF3ayAtRiAiPSIgJ".
                        "3tnc3ViKC8gLywiIiwkMSk7Z3N1YigvIC8sIiIsJDIpO2lmKCQyPT0iIi".
                        "AmJiAkMSE9IiIpeyQxPSJ7XCJuYW1lXCI6XCIiJDEiXCIifWVsc2UgaWY".
                        "oJDE9PSIiICYmICQyPT0iIil7JDE9In0ifWVsc2V7JDE9IlwiIiQxIlwi".
                        "OlwiIiQyIlwiIn07cHJpbnQgJDF9JyB8IHNlZCAnOmE7TjskIWJhO3MvX".
                        "G4vLC9nJyB8IHNlZCAncy8sfS99L2cnIHwgYXdrIC1GICJcdCIgJ3twcm".
                        "ludCAiWyIkMCJdIn0n"
                    );
                    // $cmd = "pbsnodes -x;echo $?";
                    $response = REQUIRED::lastCommandExitStatus(
                        $sshHost->cmd($cmd)
                    );
                    if (isset($response['status']) && $response['status']) {
                        $str = $response['message'];
                    }
                    $sshHost->disconnect();
                }
            }
            CrawlerController::updateNodeInfo($str);
            break;
        case "queues":
            CrawlerController::updateQueueInfo();
            break;
        default:
            echo "Invalid Request";
            break;
        }
    }

    /**
     * Updates the jobs table with qstat from torque
     * 
     * @param String $str Job Information 
     *
     * @return Boolean $updated Trur if updated otherwise false
     */
    public static function updateJobInfo($str = null) 
    {
        $host = Yii::app()->params->GHPCS['masterserverip'];
        $user = GhpcsUser::model()->find("username='admin'");
        $userId = $user->id;
        $sshHost = new GSsh(array('host' => $host));
        $accounted = array();
        if ($sshHost->getConnected()
            && $sshHost->authenticateAuto($userId)
        ) {
            /*$cmd = base64_decode(
                "c2NvbnRyb2wgc2hvdyBqb2JzIHwgc2VkICdzL1woPSBcfD0".
                "kXCkvPW5cL2EgL2cnIHxzZWQgJ3MvXiBcKy8vZycgfCBhd2sgLUYgIiAiICd7c3R".
                "yPXN1YnN0cigkMCwxLDYpO2lmKHN0cj09IlJlYXNvbiIpe2dzdWIoIiAiLCJAQCI".
                "sJDApO307Zm9yKGk9MTtpPD1ORjtpKyspe2dzdWIoIl5bXj1dKj0iLCJcIiY6XCI".
                "iLCRpKTskaT0iXCIiJGkiXCIsIjt9O3ByaW50ICQwfScgfCBzZWQgJ3MvIiIvIi9".
                "nJyB8IHNlZCAncy89Oi8iOi9nJyB8IGF3ayAtdiBwcmV2PSIiIC1GICJcbiIgJ3t".
                "pZigkMT09IiIpe3ByaW50ICJ7InByZXYifSI7cHJldj0iIjt9ZWxzZXtpZihOUj4".
                "xKXtwcmV2PXByZXYiLCIkMH1lbHNle3ByZXY9JDB9fX0nIHxzZWQgJy9ee30vZCc".
                "gfCBzZWQgJzphO047JCFiYTtzL1xuLywvZycgfCBhd2sgLUYgIlx0IiAne3ByaW5".
                "0ICJbIiQwIl0ifScgfCBzZWQgJ3Mveywvey9nJyB8IHNlZCAncy8sfS99L2cnIHw".
                "gc2VkICdzLyxbLCBdLywvZycgfCBzZWQgJ3MvQEAvIC9nJw=="
            ).";echo $?";
            */
            $cmd = base64_decode(
                "c2NvbnRyb2wgc2hvdyBqb2JzIHwgc2VkICdzL14kLy0tLS0t".
                "LS0tLS0tLS0tLS0tLS0tLS9nJyB8IHNlZCAnOmE7TjskIWJhO3MvXG4vIC9nJyB8I".
                "HNlZCAncy9cIFwrL1xuL2cnIHwgc2VkICdzLz0kLz1OQS9nJyB8IGF3ayAtdiBwcm".
                "V2PSIiIC12IGpvYj0iIiAtRiAiXHQiICd7c3BsaXQoJDEsYXJyLCI9Iik7aWYoYXJ".
                "yWzJdPT0iIiAmJiBhcnJbMV0hPSItLS0tLS0tLS0tLS0tLS0tLS0tLS0iKXtwcmV2".
                "PXByZXYiICJhcnJbMV07YXJyWzFdPSIifTtpZihhcnJbMV0hPSIiKXtwcmV2PXByZ".
                "XYiXG4iJDF9fUVORHtwcmludCBwcmV2fScgfCBzZWQgJy9eJC9kJyB8IGF3ayAtRi".
                "AiXHQiICd7aWYoJDEhPSItLS0tLS0tLS0tLS0tLS0tLS0tLS0iKXtzcGxpdCgkMSx".
                "hcnIsIj0iKTtwcmludCAiXCIiYXJyWzFdIlwiOlwiImFyclsyXSJcIiJ9IGVsc2Ug".
                "e3ByaW50ICQxfX0nIHwgc2VkICdzLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS99LHsvZ".
                "ycgfCBzZWQgJzphO047JCFiYTtzL1xuLywvZycgfCBhd2sgLUYgIlx0IiAne2dzdW".
                "IoIix7JCIsIiIsJDApO3ByaW50ICJbeyIkMCJdIn0nIHwgc2VkICdzLyx9L30vZyc".
                "gfCBzZWQgJ3Mveywvey9nJw=="
            ).';echo $?';
            $response = REQUIRED::lastCommandExitStatus(
                $sshHost->cmd($cmd)
            );
            if (isset($response['status'])  
                && $response['status']  
                && isset($response['message'])
            ) {
                $str = $response['message'];
            }
            $cmd = base64_decode(
                "ZGlmZiA8KHFzdGF0IC14IHwgc2VkICcvXi0vZCcgfCBjdXQgLWQgJyAnIC1mIDEg".
                "fCBhd2sgLUYgIiAiICdOUj4xe3ByaW50ICQwfScpIDwocXN0YXQgLWEgfCBzZWQg".
                "Jy9eLS9kJyB8IGN1dCAtZCAnICcgLWYgMSB8IGF3ayAtRiAiICIgJ05SPjR7cHJp".
                "bnQgJDB9JykgfCBhd2sgLUYgIiAiICdOUj4xe3ByaW50ICQyfSc="
            ).";echo $?";
            $response = REQUIRED::lastCommandExitStatus(
                $sshHost->cmd($cmd)
            );
            if (isset($response['status']) 
                && $response['status'] 
                && isset($response['message'])
            ) {
                $accounted = json_decode($response['message']);
            }
            $sshHost->disconnect();
        }
        $response = $str;
        $updated = false;
        $pendingJobs = array();
        $runningJobs = array();
        $holdedJobs = array();
        $activeJobs = array();
        // libxml_use_internal_errors(true);
        if ($response !== "") {
            try {
                // $xml = simplexml_load_string($response);
                // $json = json_encode($xml);
                $taskDetails = json_decode($response, true);
                if (!empty($taskDetails)) {
                    // Making job array as uniform to access
                    // if (!isset($taskDetails['Job'][0])) {
                    // $temp = $taskDetails['Job'];
                    // $taskDetails['Job'] = array($temp);
                    // }
                    $updated = true;
                    foreach ($taskDetails as $task) {
                        $jobDetails = array();
                        $jobId = explode('.', $task['JobId']);
                        $jobDetails['job_id'] = (int) $jobId[0];
                        if (isset($task['UserId'])) {
                            $jobDetails['submitted_by'] = explode(
                                '(', $task['UserId']
                            );
                        } else {
                            $jobDetails['submitted_by'] = null;
                        }
                        $tmpSubmitBy = $jobDetails['submitted_by'][0];
                        $jobDetails['submitted_by'] = $tmpSubmitBy;
                        $task['UserId'] = $tmpSubmitBy;
                        $jobDetails['last_updated'] = date("Y-m-d H:i:s");
                        if (isset($task['JobState'])) {
                            $job_state = $task['JobState'];
                        } else {
                            $job_state = null;
                        }
                        if (!is_null($job_state)) {                            
                            switch($job_state) {
                            case 'RUNNING':
                                $sshHost = new GSsh(array('host' => $host));
                                if ($sshHost->getConnected()
                                    && $sshHost->authenticateAuto($userId)
                                ) {
                                    $cmd = base64_decode(
                                        "eD1gc2NvbnRyb2wgc2hvdyBqb2JzIC0tZGV0YW".
                                        "lscyBAQGpvYl9pZEBAIHwgc2VkICdzL14gXCsv".
                                        "L2cnIHwgZ3JlcCAiXk5vZGVzIiB8IHNlZCAncy".
                                        "9Ob2Rlcz0vL2cnIHwgc2VkICdzL0NQVV9JRHM9".
                                        "Ly9nJ3wgc2VkICdzL01lbS4qJC8vZydgO2VjaG".
                                        "8gIiR4IiB8IGF3ayAtRiAiICIgLXYgbGluZXM9".
                                        "YGVjaG8gIiR4IiB8IHdjIC1sYCAne2lmKGxpbm".
                                        "VzPT0xKXt4PSQyOyQyPSIiO2dzdWIoIiwiLCIg".
                                        "IngiXG4iLCQwKTtwcmludCAkMCIieH1lbHNle3".
                                        "ByaW50ICQwfX0nIHwgIHNlZCAncy9eXHwkLyIv".
                                        "ZycgfCBzZWQgJ3MvXCAvIjoiL2cnIHwgc2VkIC".
                                        "dzLzAtLy9nJyB8IGF3ayAtRiAiOiIgJ3tnc3Vi".
                                        "KCJcIiIsIiIsJDIpOyQyPSQyKzE7cHJpbnQgJD".
                                        "EiOiIkMn0nfCBwYXN0ZSAtZCwgLXMgfCBhd2sg".
                                        "LUYgIlx0IiAne3ByaW50ICJ7IiQwIn0ifSc="
                                    ).
                                        ';echo $?';
                                    $cmd = str_replace(
                                        "@@job_id@@",
                                        $task['JobId'],
                                        $cmd
                                    );
                                    $response = REQUIRED::lastCommandExitStatus(
                                        $sshHost->cmd($cmd)
                                    );
                                    if (isset($response['status']) 
                                        && $response['status']
                                    ) {
                                        $t = $response['message'];
                                        $task['exec_host'] = $t;
                                    }
                                }
                                array_push($runningJobs, $task);
                                break;
                            case 'PENDING':
                                if (isset($task['Reason']) 
                                    && strpos($task['Reason'], "Held") === false
                                ) {
                                    array_push($pendingJobs, $task);
                                } else {
                                    array_push($holdedJobs, $task);
                                }
                                break;
                            } 
                            // array_push($activeJobs, "" . $jobDetails['job_id']);
                        }
                        if ($job_state == "COMPLETED") {
                            $jobDetails['is_deleted'] = true;
                        } else {
                            $jobDetails['is_deleted'] = false;
                        }
                        $jobDetails['status'] = json_encode($task);
                        $job = new Job();
                        $tempObj = new Job();
                        if (!$tempObj->exists(
                            'job_id=:job_id', 
                            array(':job_id' => $jobDetails['job_id'])
                        )
                        ) {
                            $job->attributes = $jobDetails;
                            $updated = $updated && $job->save();
                        } else {
                            $updated = $updated && $job->updateAll(
                                array(
                                    'is_deleted' => $jobDetails['is_deleted'],
                                    'status' => $jobDetails['status'],
                                    'submitted_by' => $jobDetails['submitted_by'],
                                    'last_updated' => date("Y-m-d H:i:s"),
                                    'is_active' => true
                                ), 
                                'job_id=:job_id', 
                                array(':job_id' => $jobDetails['job_id'])
                            );
                        }
                    }
                }
            } catch (Exception $e) {
                print_r($e);
            }
        }
        // if (!empty($activeJobs)) {
        // $criteria = new CDbCriteria;
        // $criteria->addNotInCondition("job_id", $activeJobs);
        // Job::model()->updateAll(
        // array('is_active' => false),
        // $criteria
        // );
        // }
        $activeJobs = array_merge($activeJobs, $holdedJobs);
        $activeJobs = array_merge($activeJobs, $pendingJobs);
        $activeJobs = array_merge($activeJobs, $runningJobs);
        Yii::app()->cache->set('holdedJobs', $holdedJobs);
        Yii::app()->cache->set('pendingJobs', $pendingJobs);
        Yii::app()->cache->set('runningJobs', $runningJobs);
        Yii::app()->cache->set('activeJobs', $activeJobs);
        return $updated;
    }
    /**
     * Updates queue information from torque
     *
     * @param String  $str   Queue Information
     * @param Boolean $debug Debug Information
     *
     * @return NULL
     */
    public static function updateQueueInfo($str = null, $debug = null)
    {
        $host = Yii::app()->params->GHPCS['masterserverip'];
        $user = GhpcsUser::model()->find("username='admin'");
        $userId = $user->id;
        $sshHost = new GSsh(array('host' => $host));
        if ($sshHost->getConnected() && $sshHost->authenticateAuto($userId)) {
            // $cmd = 'qstat -Qf | sed \':a;N;$!ba;s/\n\t//g\' | '.
            // 'sed \'s/Queue:/Queue:name =/g\';echo $?';
            $cmd = 'c2NvbnRyb2wgc2hvdyBwYXJ0aXRpb25zIHwgc2VkICdzL1woPSBcfD0kX'.
            'CkvPW5cL2EgL2cnIHxzZWQgJ3MvXiBcKy8vZycgfCBhd2sgLUYgIiAiICd7c3RyP'.
            'XN1YnN0cigkMCwxLDYpO2lmKHN0cj09IlJlYXNvbiIpe2dzdWIoIiAiLCJAQCIsJ'.
            'DApO307Zm9yKGk9MTtpPD1ORjtpKyspe2dzdWIoIl5bXj1dKj0iLCJcIiY6XCIiL'.
            'CRpKTskaT0iXCIiJGkiXCIsIjt9O3ByaW50ICQwfScgfCBzZWQgJ3MvIiIvIi9nJ'.
            'yB8IHNlZCAncy89Oi8iOi9nJyB8IGF3ayAtdiBwcmV2PSIiIC1GICJcbiIgJ3tpZ'.
            'igkMT09IiIpe3ByaW50ICJ7InByZXYifSI7cHJldj0iIjt9ZWxzZXtpZihOUj4xK'.
            'XtwcmV2PXByZXYiLCIkMH1lbHNle3ByZXY9JDB9fX0nIHxzZWQgJy9ee30vZCcgf'.
            'CBzZWQgJzphO047JCFiYTtzL1xuLywvZycgfCBhd2sgLUYgIlx0IiAne3ByaW50I'.
            'CJbIiQwIl0ifScgfCBzZWQgJ3Mveywvey9nJyB8IHNlZCAncy8sfS99L2cnIHwgc'.
            '2VkICdzLyxbLCBdLywvZycgfCBzZWQgJ3MvQEAvIC9nJw==';
            $cmd = base64_decode($cmd).";echo $?";
            $response = REQUIRED::lastCommandExitStatus($sshHost->cmd($cmd));
            if (isset($response['status']) && $response['status']) {
                $queues = json_decode($response['message'], true);
                foreach ($queues as $key => $queue) {
                    REQUIRED::replaceKey($queue, 'PartitionName', 'name');
                    $nQueue = Queue::model()->find(
                        'name=:name',
                        array(':name' => $queue['name'])
                    );
                    if (!$nQueue) {
                        $nQueue = new Queue();
                        $attrs = array(
                            'name' => $queue['name'],
                            'status' => json_encode($queue)
                        );
                        $nQueue->attributes = $attrs;
                        $nQueue->save();
                    }
                }
            }
            $sshHost->disconnect();
        }
    } 
    /**
     * Updates queue information from torque
     *
     * @param String  $str   Queue Information
     * @param Boolean $debug Debug Information
     *
     * @return NULL
     */
    public static function updateQueueInfoOld($str = null, $debug = null) 
    {
        $host = Yii::app()->params->GHPCS['masterserverip'];
        $user = GhpcsUser::model()->find("username='admin'");
        $userId = $user->id;
        $sshHost = new GSsh(array('host' => $host));
        if ($sshHost->getConnected() && $sshHost->authenticateAuto($userId)) {
            $cmd = 'qstat -Qf | sed \':a;N;$!ba;s/\n\t//g\' | '.
             'sed \'s/Queue:/Queue:name =/g\';echo $?';
            $response = REQUIRED::lastCommandExitStatus($sshHost->cmd($cmd));
            if (isset($response['status']) && $response['status']) {
                $str = $response['message'];
            }
            $sshHost->disconnect();
        }
        $response = $str;
        $response = str_replace("\r\n\t", "\n\t", $response);
        $response = str_replace("\n\t", "", $response);
        $templateResourcesArr = array(
            'arch' => null,
            'mem' => null,
            'ncpus' => null,
            'nodect' => null,
            'procct' => null,
            'nodes' => null,
            'pvmem' => null,
            'vmem' => null,
            'walltime' => null
        );
        $resourceAvailable = array();
        $resourceDefault = array();
        $resourceMinimum = array();
        $resourceMaximum = array();
        $queueArray = explode("Queue:", $response);
        unset($queueArray[0]);
        // $queueArray = preg_split("/\n\n/", $response);
        $queueArray = array_values($queueArray);
        foreach ($queueArray as $index => $queue) {
            $tmpResourceAvailable = $templateResourcesArr;
            $tmpResourceDefault = $templateResourcesArr;
            $tmpResourceMaximum = $templateResourcesArr;
            $tmpResourceMinimum = $templateResourcesArr;
            $pattern = preg_quote("resources", '/');
            $pattern = "/^.*$pattern.*\$/m";
            if (preg_match_all($pattern, $queue, $matches)) {
                foreach ($matches[0] as $match) {
                    if (strpos(trim($match, " "), "resources_max") !== false) {
                        $res = explode("=", $match);
                        $res[0] = explode(".", $res[0]);
                        $tmpResourceMaximum[trim($res[0][1])] = trim($res[1], " ");
                    }
                    if (strpos(trim($match, " "), "resources_min") !== false) {
                        $res = explode("=", $match);
                        $res[0] = explode(".", $res[0]);
                        $tmpResourceMinimum[trim($res[0][1])] = trim($res[1], " ");
                    }
                    if (strpos(trim($match, " "), "resources_default") !== false) {
                        $res = explode("=", $match);
                        $res[0] = explode(".", $res[0]);
                        $tmpResourceDefault[trim($res[0][1])] = trim($res[1], " ");
                    }
                    if (strpos(
                        trim($match, " "), "resources_available"
                    ) !== false
                    ) {
                        $res = explode("=", $match);
                        $res[0] = explode(".", $res[0]);
                        $tRA = trim($res[1], " ");
                        $tmpResourceAvailable[trim($res[0][1])] = $tRA;
                    }
                }
            }
            $resourceAvailable[$index] = $tmpResourceAvailable;
            $resourceDefault[$index] = $tmpResourceDefault;
            $resourceMinimum[$index] = $tmpResourceMinimum;
            $resourceMaximum[$index] = $tmpResourceMaximum;
            $queue = explode("\n", $queue);
            foreach ($queue as $k => $q) {
                $q = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $q);
                if (empty($q)) {
                    unset($queue[$k]);
                } else {
                    $queue[$k] = $q;
                }
            }
            $queueArray[$index] = $queue;
        }
        $templateQueueNames = array(
            'name' => 'name',
            'disallowed_types' => 'disallowed_types',
            'enabled' => 'enabled',
            'features_required' => 'features_required',
            'keep_completed' => 'keep_completed',
            'kill_delay' => 'kill_delay',
            'max_queuable' => 'max_queuable',
            'max_running' => 'max_running',
            'max_user_queuable' => 'max_user_queuable',
            'max_user_run' => 'max_user_run',
            'Priority' => 'priority',
            'queue_type' => 'queue_type',
            'required_login_property' => 'required_login_property',
            'started' => 'started',
            'acl_group_enable' => 'acl_group_enable',
            'acl_group_sloppy' => 'acl_group_sloppy',
            'acl_host_enable' => 'acl_host_enable',
            'acl_logic_or' => 'acl_logic_or',
            'acl_user_enable' => 'acl_user_enable',
            'route_destinations' => 'route_destinations'
        );
        $templateResources = array(
            'arch',
            'mem',
            'ncpus',
            'nodect',
            'procct',
            'nodes',
            'pvmem',
            'vmem',
            'walltime'
        );
        $dataBaseResources = array(
            'arch' => null,
            'mem' => null,
            'ncpus' => null,
            'nodect' => null,
            'procct' => null,
            'nodes' => null,
            'pvmem' => null,
            'vmem' => null,
            'walltime' => null
        );
        $queueDetails = array();
        $updatedQueues = array();
        foreach ($queueArray as $kq => $queue) {    
            $qd = explode("=", $queue[0]);
            array_push($updatedQueues, trim($qd[1], " "));
            foreach ($queue as $tk => $tq) {
                $tempQ = explode("=", $tq);
                if (isset($tempQ[1])) {
                    if (trim($tempQ[0]) == "queue_type") {
                        $tempQ[1] = strtolower($tempQ[1]);
                    }
                    $queue[trim($tempQ[0])] = trim($tempQ[1]);
                }
                unset($queue[$tk]);
            }
            if (isset($queue['state_count'])) {
                $tmpStateCount = str_replace(" ", ",", trim($queue['state_count']));
                $queue['state_count'] = trim($tmpStateCount, ",");
            }
            $queueArray[$kq] = $queue;
        }
        $aclList = array(
        'acl_user_enable', 
        'acl_group_enable', 
        'acl_host_enable', 
        'acl_group_sloppy', 
        'acl_logic_or'
        );
        foreach ($queueArray as $kq => $queue) {
            $tempArray = array();
            $tempResourceAvailable = $dataBaseResources;
            $tempResourceDefault = $dataBaseResources;
            $tempResourceMin = $dataBaseResources;
            $tempResourceMax = $dataBaseResources;
            foreach ($queue as $kqq => $qq) {
                if (isset($templateQueueNames[$kqq])) {
                    $qq = ((trim($qq) == "True") ? true : $qq);
                    $qq = ((trim($qq) == "False") ? false : $qq);
                    $tempArray[$templateQueueNames[$kqq]] = $qq;
                }
            }
            foreach ($aclList as $acl) {
                if (!array_key_exists($acl, $tempArray)) {
                    $tempArray[$acl] = null;
                }
            }
            $queueDetails[$kq] = $tempArray;
        
            $model = new Queue();
            Queue::model()->updateAll(
                array(
                'route_destinations' => null,
                'disallowed_types' => null,
                'enabled' => null,
                'started' => null,
                'keep_completed' => null,
                'kill_delay' => null,
                'max_queuable' => null,
                'max_running' => null,
                'max_user_queuable' => null,
                'max_user_run' => null,
                'priority' => null,
                'required_login_property' => null,
                'acl_group_enable' => null,
                'acl_group_sloppy' => null,
                'acl_host_enable' => null,
                'acl_logic_or' => null,
                'acl_user_enable' => null
                ), 
                'name=:name', 
                array(':name' => $queue['name'])
            );
            $data = Queue::model()->find(
                'name=:name', array(':name' => $queue['name'])
            );
            $queue['status'] = json_encode($queueArray[$kq]);
            if ($data) {
                $model->updateAll(
                    $queue, 
                    'id=:queue_id', 
                    array(":queue_id" => $data->id)
                );
            } else {
                $queueDBArray = array();
                foreach ($templateQueueNames as $key => $dbAttrName) {
                    $queueDBArray[$dbAttrName] = (isset(
                        $queue[$dbAttrName]
                    ) ? $queue[$dbAttrName] : null);
                }
                $queueDBArray['status'] = json_encode($queue);
                $model->attributes = $queueDBArray;
                $model->save(false);
            }
        }
        foreach ($queueArray as $kq => $queue) {
            $model = Queue::model()->find(
                'name=:name', 
                array(':name' => $queue['name'])
            );
            if ($model) {
                $resModel = ResourcesAvailable::model()->find(
                    "queue_id=:queue_id", 
                    array(":queue_id" => $model->id)
                );
                $resourceObj = new ResourcesAvailable();
                if ($resModel != null) {
                    $resourceAvailable[$kq]['queue_id'] = $model->id;
                    $resourceObj->updateAll(
                        $resourceAvailable[$kq], 
                        "queue_id=:queue_id", 
                        array(":queue_id" => $model->id)
                    );
                } else {
                    $resourceAvailable[$kq]["queue_id"] = $model->id;
                    $resourceObj->attributes = $resourceAvailable[$kq];
                    $resourceObj->save(false);
                }
                $resModel = ResourcesDefault::model()->find(
                    "queue_id=:queue_id", 
                    array(":queue_id" => $model->id)
                );
                $resourceObj = new ResourcesDefault();
                if ($resModel) {
                    $resourceDefault[$kq]['queue_id'] = $model->id;
                    $resourceObj->updateAll(
                        $resourceDefault[$kq], 
                        "queue_id=:queue_id", 
                        array(":queue_id" => $model->id)
                    );
                } else {
                    $resourceDefault[$kq]["queue_id"] = $model->id;
                    $resourceObj->attributes = $resourceDefault[$kq];
                    $resourceObj->save(false);
                }
                $resModel = ResourcesMax::model()->find(
                    "queue_id=:queue_id", 
                    array(":queue_id" => $model->id)
                );
                $resourceObj = new ResourcesMax();
                if ($resModel) {
                    $resourceMaximum[$kq]['queue_id'] = $model->id;
                    $resourceObj->updateAll(
                        $resourceMaximum[$kq], 
                        "queue_id=:queue_id", 
                        array(":queue_id" => $model->id)
                    );
                } else {
                    $resourceMaximum[$kq]["queue_id"] = $model->id;
                    $resourceObj->attributes = $resourceMaximum[$kq];
                    $resourceObj->save(false);
                }
                /*$resModel = ResourcesMin::model()->find(
                    "queue_id=:queue_id", 
                    array(":queue_id" => $model->id)
                );
                $resourceObj = new ResourcesMin();
                if ($resModel) {
                    $resourceMinimum[$kq]['queue_id'] = $model->id;
                    $resourceObj->updateAll(
                        $resourceMinimum[$kq], 
                        "queue_id=:queue_id", 
                        array(":queue_id" => $model->id)
                    );
                } else {
                    $resourceMinimum[$kq]["queue_id"] = $model->id;
                    $resourceObj->attributes = $resourceMinimum[$kq];
                    $resourceObj->save(false);
                }*/
            }
        }
        $model = new Queue();
        $queueIds = array();
        foreach ($updatedQueues as $queue) {
            $tempModel = Queue::model()->find(
                'name=:name', array(':name' => $queue)
            );
            array_push($queueIds, $tempModel->id);
        }
        if (!empty($queueIds)) {
            $dcriteria = new CDbCriteria;
            $dcriteria->addNotInCondition('queue_id', $queueIds);
            ResourcesMin::model()->deleteAll($dcriteria);
            ResourcesMax::model()->deleteAll($dcriteria);
            ResourcesDefault::model()->deleteAll($dcriteria);
            ResourcesAvailable::model()->deleteAll($dcriteria);
            AclUser::model()->deleteAll($dcriteria);
            AclHost::model()->deleteAll($dcriteria);
            AclGroup::model()->deleteAll($dcriteria);       
            $ncriteria = new CDbCriteria;
            $ncriteria->addNotInCondition('id', $queueIds);     
            $model->deleteAll($ncriteria);
        } else {
            // ResourcesMin::model()->deleteAll();
            // ResourcesMax::model()->deleteAll();
            // ResourcesDefault::model()->deleteAll();
            // ResourcesAvailable::model()->deleteAll();
            AclUser::model()->deleteAll();
            AclHost::model()->deleteAll();
            AclGroup::model()->deleteAll();
            $model->deleteAll();
        }
        CrawlerController::updateAclInfo($queueArray);
    }

    /**
     * Updates the nodes table with pbsnodes from torque
     *
     * @param String $str Node Information
     *
     * @return NULL
     */
    public static function updateNodeInfo($str = null) 
    {
        $responseXML = null;
        if (is_null($responseXML)) {
            $host = Yii::app()->params->GHPCS['masterserverip'];
                $user = GhpcsUser::model()->find("username='admin'");
                $userId = $user->id;
                $sshHost = new GSsh(array('host' => $host));
            if ($sshHost->getConnected()
                && $sshHost->authenticateAuto($userId)
            ) {
                // $cmd = "pbsnodes -x;echo $?";
                $cmd = base64_decode(
                    "cGJzbm9kZXMgLWEgfCBzZWQgJ3MvXiBcKy8vZycgfGF3ayAtRiAiPSIgJ3tn".
                    "c3ViKC8gLywiIiwkMSk7Z3N1YigvIC8sIiIsJDIpO2lmKCQyPT0iIiAmJiAk".
                    "MSE9IiIpeyQxPSJ7XCJuYW1lXCI6XCIiJDEiXCIifWVsc2UgaWYoJDE9PSIi".
                    "ICYmICQyPT0iIil7JDE9In0ifWVsc2V7JDE9IlwiIiQxIlwiOlwiIiQyIlwi".
                    "In07cHJpbnQgJDF9JyB8IHNlZCAnOmE7TjskIWJhO3MvXG4vLC9nJyB8IHNl".
                    "ZCAncy8sfS99L2cnIHwgYXdrIC1GICJcdCIgJ3twcmludCAiWyIkMCJdIn0n"
                );
                $cmd = "c2NvbnRyb2wgc2hvdyBub2RlcyB8IHNlZCAncy9cICMvXG4jL2cn".
                "IHwgc2VkICcvIy4qJC9kJyB8c2VkICdzL1woPSBcfD0kXCkvPW5cL2EgL2cn".
                "IHxzZWQgJ3MvXiBcKy8vZycgfCBzZWQgJy9PUy97cy9cIC8tL2d9JyB8YXdrI".
                "C1GICIgIiAne3N0cj1zdWJzdHIoJDAsMSw2KTtpZihzdHI9PSJSZWFzb24iKX".
                "tnc3ViKCIgIiwiQEAiLCQwKTt9O2ZvcihpPTE7aTw9TkY7aSsrKXtnc3ViKCJ".
                "eW149XSo9IiwiXCImOlwiIiwkaSk7JGk9IlwiIiRpIlwiLCI7fTtwcmludCAkM".
                "Dt9JyB8IHNlZCAncy8iIi8iL2cnIHwgc2VkICdzLz06LyI6L2cnIHwgYXdrIC1".
                "2IHByZXY9IiIgLUYgIlxuIiAne2lmKCQxPT0iIil7cHJpbnQgInsicHJldiJ9I".
                "jtwcmV2PSIiO31lbHNle2lmKE5SPjEpe3ByZXY9cHJldiIsIiQwfWVsc2V7cHJl".
                "dj0kMH19fScgfHNlZCAnL157fS9kJyB8IHNlZCAnOmE7TjskIWJhO3MvXG4vLC9".
                "nJyB8IGF3ayAtRiAiXHQiICd7cHJpbnQgIlsiJDAiXSJ9JyB8IHNlZCAncy97L".
                "C97L2cnIHwgc2VkICdzLyx9L30vZycgfCBzZWQgJ3MvLFssIF0vLC9nJy".
                "B8IHNlZCAncy9AQC8gL2cn";
                $response = REQUIRED::lastCommandExitStatus(
                    $sshHost->cmd(base64_decode($cmd).";echo $?")
                );
                // print_r(base64_decode($cmd));
                if (isset($response['status']) && $response['status']) {
                    $str = $response['message'];
                }
                $sshHost->disconnect();
            }
                $responseXML = $str;
        }
        if ($responseXML !== null) {
            try {
                // $xml = simplexml_load_string($responseXML);
                $nodeDetails = json_decode($responseXML, true);
                $nodeNames = "";
                foreach ($nodeDetails as $key => $node) {
                    $nodeNames .= "'" . $node['NodeName'] . "',";
                    $node['status'] = json_encode($node);
                    $nodeDetail = Node::model()->find(
                        'name=:name', 
                        array(':name' => $node['NodeName'])
                    );
                    $nodeDetails['Node'][$key] = $node;
                    $nodeObj = new Node();
                    if (count($nodeDetail) > 0) {
                        $nodeObj->updateAll(
                            array(
                            'status' => json_encode($node),
                            'np' => isset($node['CPUTot']) ? $node['CPUTot'] : 1,
                            'gpus' => isset($node['gpus']) ? $node['gpus'] : null,
                            'mics' => isset($node['mics']) ? $node['mics'] : null,
                            ), 'name=:name', array(':name' => $node['NodeName'])
                        );
                    } else {
                        $data = array(
                            'name' => $node['NodeName'],
                            'np' => $node['CPUTot']
                        );
                        if (isset($node['gpus']) && is_int((int) $node['gpus'])) {
                            $data['gpus'] = $node['gpus'];
                        }
                        if (isset($node['mics']) && is_int((int) $node['mics'])) {
                            $data['mics'] = $node['mics'];
                        }
                        $data['status'] = json_encode($node);
                        $nodeObj->attributes = $data;
                        $nodeObj->save(false);
                    }
                }
                $nodeNames = "(" . trim($nodeNames, ",") . ")";
                $node = new Node();
                $node->deleteAll("name NOT IN" . $nodeNames);
            } catch (Exception $ex) {
                print_r($ex);
            }
        }
    }

    /**
     * Updates ACL tables based on the queue update information and it is the
     * part of updateQueuesInfo function
     * 
     * @param Array $queueArray Queue Information
     *
     * @return NULL
     */
    public static function updateAclInfo($queueArray) 
    {
        $aclArray = array('acl_user', 'acl_group', 'acl_host');
        foreach ($queueArray as $queue) {
            foreach ($aclArray as $aclValue) {
                $model = new Queue();
                $q = $model->findByAttributes(array('name' => $queue['name']));
                $aclRecord = null;
                $aclEnableString = "";
                switch ($aclValue) {
                case "acl_user":
                    $aclRecord = new AclUser();
                    $aclEnableString = "acl_user_enable";
                    break;
                case "acl_group":
                    $aclRecord = new AclGroup();
                    $aclEnableString = "acl_group_enable";
                    break;
                case "acl_host":
                    $aclRecord = new AclHost();
                    $aclEnableString = "acl_host_enable";
                    break;
                }
                if (isset($queue[$aclValue . "s"])) {
                    if (isset($q->id)) {
                        $aclArrs = explode(',', $queue[$aclValue . "s"]);
                        foreach ($aclArrs as $aclVal) {
                            if (!$aclRecord->exists(
                                'queue_id=:queue_id AND name=:name', 
                                array(
                                ':queue_id' => $q->id, 
                                ':name' => $aclVal
                                )
                            )
                            ) {
                                $aclRecord->attributes = array(
                                'queue_id' => $q->id, 
                                'name' => $aclVal
                                );
                                $aclRecord->save(false);
                            }
                        }
                    }
                } else {
                    $aclRecord->deleteAll(
                        'queue_id=:queue_id', 
                        array(':queue_id' => $q->id)
                    );
                }
            }
        }
    }

    /**
     * Updates database based on torque server parameters
     * 
     * @return NULL
     */
    public static function torqueServerInfo() 
    {
        $cmd = 'qmgr -c "print server" | grep "set server" |'.
        ' awk -F " " \'{print $3","$5}\';echo $?';
        $host = Yii::app()->params->GHPCS['masterserverip'];
        $user = GhpcsUser::model()->find("username='admin'");
        $userId = $user->id;
        $sshHost = new GSsh(array('host' => $host));
        if ($sshHost->getConnected() && $sshHost->authenticateAuto($userId)) {
            $response = REQUIRED::lastCommandExitStatus($sshHost->cmd($cmd));
            if (isset($response['status']) 
                && isset($response['message']) 
                && $response['status']
            ) {
                $responses = explode("\n", $response['message']);
                $updatedParameters = "";
                $cmd = "UPDATE gjsppbs_torque_server_parameters SET key_value=null";
                $db = Yii::app()->controller->module->db;
                $connection = new CDbConnection(
                    $db['connectionString'], 
                    $db['username'], 
                    $db['password']
                );
                $connection->active = true;
                $command = $connection->createCommand($cmd);
                $command->execute();
                foreach ($responses as $index => $response) {
                    if ("bash: qmgr: command not found" !== trim($response)) {
                        $attrValues = explode(",", $response);
                        $attribute = trim($attrValues[0]);
                        $value = trim($attrValues[1]);
                        $data = ServerParams::model()->find(
                            'key_attr=:key_attr', 
                            array(':key_attr' => strtolower($attribute))
                        );
                        $updateData = array();
                        if ($data) {
                            switch ($data->value_type) {
                            case "multiple":
                                $values = array();
                                if ($data->key_value != "" 
                                    && $data->key_value != null
                                ) {
                                    $values = json_decode($data->key_value, true);
                                }
                                array_push($values, $value);
                                $updateData['key_value'] = json_encode($values);
                                break;
                            case "integer":
                                $updateData['key_value'] = (int) $value;
                                break;
                            case "boolean":
                                $updateData['key_value'] = (
                                ($value == 'True') ? "1" : "0"
                                );
                                break;
                            default:
                                $updateData['key_value'] = $value;
                                break;
                            }
                            if (isset($updateData['key_value'])) {
                                ServerParams::model()->updateAll(
                                    $updateData, 
                                    'id=:id', 
                                    array(':id' => $data->id)
                                );
                            }
                        }
                    }
                }
            }
            $sshHost->disconnect();
        }
    }

}

// End of the CrawlerController Class
// End of the CrawlerController.php file
