<?php

/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  TORQUE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * Department Controller is used to set the configuration of departments
 *
 * @category Job_Submission_Portal
 * @package  TORQUE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class DepartmentController extends Controller
{

    /**
     * Specify the application alert generation rules
     * This method is used by beforeAction
     *
     * @return array alert generation rules
     */
    public function alertRules()
    {
        return array(
            'actions' => array('index', 'error')
        );
    }

    /**
     * Specifies filters of the controller which requires
     *
     * @return array action filters
     */
    public function filters()
    {
        return array(
            'accessControl', // perform access control
        );
    }

    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     *
     * @return array access control rules
     */
    public function accessRules()
    {
        return array(
            array('allow', // allow everyone to perform 'error' action
                'actions' => array('error'),
                'users' => array('*'),
            ),
            array('allow', // allow authenticated user to perform 'index' actions
                'actions' => array(
                    'create',
                    'update',
                    'index',
                    'delete',
                    'view',
                ),
                'users' => array('admin','root'),
            ),
            array('deny', // deny all users
                'users' => array('*'),
            ),
        );
    }
    
    /**
     * Loads the department list page
     *
     * @return NULL
     */
    public function actionIndex() 
    {  
        $this->layout = '//layouts/column2';
        $model = Department::model()->findAll();
        $this->render('index', array('model' => $model));
    }
    
    /**
     * Loads/Manages the create form page
     *
     * @return NULL
     */
    public function actionCreate() 
    {
        $model = new DepartmentForm();
        if (isset($_POST['DepartmentForm'])) {
            $model->attributes = $_POST['DepartmentForm'];
            if ($model->validate()) {
                $dep = new Department();
                $transaction = $dep->dbConnection->beginTransaction();
                $ret = false;
                try{ 
                    $dep->name = $model->name;
                    $dep->description = $model->description;
                    $ret = $dep->save();
                    if ($ret) {
                        if (!empty($model->users)) {
                            foreach ($model->users['user_id'] as $k => $v) {
                                $member = new DepartmentMembers();
                                $member->user_id = (int) $v;
                                $member->is_lead = (trim(
                                    $model->users['is_lead'][$k]
                                ) == 'true') ? true : false;
                                $ret = $member->save();
                                if ($ret) {
                                    $rel = new DepartmentRelation();
                                    $rel->member_id = $member->id;
                                    $rel->dep_id = $dep->id;
                                    $ret = $rel->save();
                                }
                            }
                        }               
                    }
                } catch(CDbException $e){
                    $ret = false;
                    Yii::app()->user->setFlash(
                        'error', 
                        'Unable to create department, due to unknown '.
                        'database problem.Please try again.'
                    );    
                }
                !$ret ? $transaction->rollback() : $transaction->commit();
                $this->redirect(array('index')); 
            }     
        }
        $this->render('create', array('model' => $model)); 
    }
    /**
     * Shows the details of department.
     *
     * @param Integer $id Department Identifier
     *
     * @return NULL
     */
    public function actionView($id) 
    {
        $this->layout = '//layouts/column2';
        $model = DepartmentRelation::model()
            ->with("department")
            ->with("depmembers")
            ->findAll("dep_id=".$id);
        $this->render('view', array("model" => $model));
    }
     /**
      * Loads/Modifies the department details
      *
      * @param Integer $id Department Identifier
      * 
      * @return NULL
      */
    public function actionUpdate($id) 
    {
        $this->layout = '//layouts/column2';
        $dep = DepartmentRelation::model()
            ->with("department")
            ->with("depmembers")
            ->findAll("dep_id=".$id);        
        $model = new DepartmentForm();
        if (isset($_POST['DepartmentForm'])) {
            $model->attributes = $_POST['DepartmentForm'];
            if ($model->validate()) {
                $trn = new Department();
                $transaction = $trn->dbConnection->beginTransaction();
                $ret = false;
                try {
                    $dept = Department::model()->find('id=:id', array(':id' => $id));
                    $dept->description = $model->description;
                    $ret = $dept->save();
                    if ($ret) {
                        if (!empty($model->users)) {
                            $reqMembers = array();
                            foreach ($model->users['user_id'] as $k => $v) {
                                $member = DepartmentMembers::model()->find(
                                    'user_id=:user_id',
                                    array(':user_id' => $v)
                                );
                                if (!$member) {
                                    $member = new DepartmentMembers();
                                }
                                $member->user_id = (int) $v;
                                $member->is_lead = (trim(
                                    $model->users['is_lead'][$k]
                                ) == 'true') ? true : false;
                                $ret = $member->save();
                                if ($ret) {
                                    array_push($reqMembers, $member->id);
                                    $rel = DepartmentRelation::model()->find(
                                        'member_id=:member_id AND dep_id=:dep_id',
                                        array(
                                            ":member_id" => $member->id,
                                            ":dep_id" => $dept->id
                                        )
                                    );
                                    if (!$rel) {
                                        $rel = new DepartmentRelation();
                                    }
                                    $rel->member_id = $member->id;
                                    $rel->dep_id = $id;
                                    $ret = $rel->save();
                                    if (!$ret) {
                                        break;
                                    }
                                }
                            }
                            $alreadyMembers = array();
                            foreach ($dep as $key => $deptObj) {
                                array_push($alreadyMembers, $deptObj->member_id);
                            }
                            sort($reqMembers);
                            sort($alreadyMembers);
                            $notRequireMembers = array_diff(
                                $alreadyMembers, $reqMembers
                            );
                            foreach ($notRequireMembers as $k => $member) {
                                $rel = DepartmentRelation::model()->find(
                                    "member_id=:member_id AND dep_id=:dep_id",
                                    array(
                                    ":member_id" => $member,
                                    ":dep_id" => $id 
                                    )
                                );
                                $ret = $rel->delete();
                            }
                            if ($ret) {
                                $transaction->commit();
                            }
                        }                              
                    }    
                } catch (Exception $e) {
                    $ret = false;
                }           
                if (!$ret) {
                    $transaction->rollback();
                    Yii::app()->user->setFlash(
                        "error",
                        "Something goes wrong with Database.Please try again."
                    );
                }                         
                $this->redirect(array('view','id' => $id));
            }            
        }
        if (isset($dep[0])) {
            $model->name = $dep[0]->department->name;
            $model->description = $dep[0]->department->description;    
            $users = array('user_id' => array(),'is_lead' => array());
            foreach ($dep as $key => $dept) {
                array_push($users['user_id'], $dept->depmembers->user_id);
                array_push($users['is_lead'], $dept->depmembers->is_lead);
            }
            $model->users = $users;
        }
        $this->render('update', array("model" => $model, "dep" => $dep));
    }
    /**
     * Delete(s) the requested department
     *
     * @param Integer $ajax Ajax Parameter 
     * @param Integer $id   Department identifier
     * 
     * @return NULL
     */
    public function actionDelete($ajax=null,$id=null) 
    {
        $department = new Department();
        $transaction = $department->dbConnection->beginTransaction();
        $criteria = new CDbCriteria;
        $criteria->addCondition("dep_id=:dep_id");
        $criteria->params = array(":dep_id" => (int) $id);
        $rel = DepartmentRelation::model()->deleteAll($criteria);
        $ret = false;
        try {
            if (is_int($rel)) {
                $ret = Department::model()->deleteAll("id=".$id);
                $transaction->commit();
            }
        } catch (Exception $e) {
            $ret = false;
        }
        if (!$ret) {
            $transaction->rollback();
            Yii::app()->user->setFlash(
                "error", 
                "Unable to delete the department.Please try again."
            );
        }
         
        // if AJAX request (triggered by deletion via admin grid view),
        // we should not redirect the browser
        if (!isset($_GET['ajax'])) {
            $this->redirect(
                isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('index')
            );
        }
         
    }
}
