<?php

/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  TORQUE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * Dashboard Controller gives the information about torque cluster's server
 *
 * @category Job_Submission_Portal
 * @package  TORQUE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class DashboardController extends Controller
{

    /**
     * Specify the application alert generation rules
     * This method is used by beforeAction
     *
     * @return array alert generation rules
     */
    public function alertRules()
    {
        return array(
            'actions' => array('index', 'error')
        );
    }

    /**
     * Specifies filters of the controller which requires
     *
     * @return array action filters
     */
    public function filters()
    {
        return array(
            'accessControl', // perform access control
        );
    }

    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     *
     * @return array access control rules
     */
    public function accessRules()
    {
        return array(
            array('allow', // allow everyone to perform 'error' action
                'actions' => array('error'),
                'users' => array('*'),
            ),
            array('allow', // allow authenticated user to perform 'index' actions
                'actions' => array(
                    'index',
                    'getQueueInfo',
                    'getHostInfo',
                    'showchart'
                ),
                'users' => array('@'),
            ),
            array(
                'allow',
                'actions' => array('export','listUsers','delete'),
                'users' => array('admin','root'),
            ),
            array('deny', // deny all users
                'users' => array('*'),
            ),
        );
    }
    /**
     * Executes before perform any action
     *
     * @return Boolean true
     */ 
    public function beforeAction() 
    {
        Yii::import($this->module->id . ".controllers.CrawlerController");
        CrawlerController::updateNodeInfo();
        CrawlerController::updateQueueInfo();
        CrawlerController::updateJobInfo();
        return true;
    }
    /**
     * Gives the information about the cluster
     *
     * @return null
     */
    public function actionIndex()
    {
        if (Yii::app()->params['GJSPSLURM']['agreement'] != 'Accepted') {
            if (Yii::app()->request->isPostRequest) {
                if (isset($_POST['accept']) && $_POST['accept']==1) {
                    GjspUtils::setConfig('agreement', 'Accepted');
                    if (!isset(Yii::app()->params['GJSPSLURM']['portalid'])) {
                        $min=0;
                        $max=9999;
                        $portalId=  sprintf(
                            "%04d-%04d-%04d-%04d",
                            mt_rand($min, $max),
                            mt_rand($min, $max),
                            mt_rand($min, $max),
                            mt_rand($min, $max)
                        );
                        GjspUtils::setConfig("portalid", $portalId);
                    }
                    Yii::import(
                        $this->module->id . 
                        ".controllers.SettingsController"
                    );
                    SettingsController::initializePortal(&$this); 
                    $this->refresh();
                } else {
                    Yii::app()->user->setFlash(
                        'error',
                        'Licence must be accepted'
                    );
                }
            }
            // display the license agreement notice form
            $this->render('agreement');
            return;
        }
        CrawlerController::updateJobInfo();
        $params = array();
        $host = Yii::app()->params->GHPCS['masterserverip'];
        $user = GhpcsUser::model()->find("username='admin'");
        $userId = $user->id;
        $sshHost = new GSsh(array('host' => $host));
        $nodeInfo = Node::model()->findAll();
        $nodeState = array();
        $params['coreSummary'] = array(
            'avail' => 0, 
            'used' => 0, 
            'offline' => 0,
            'total' => 0,
            'free' => 0,
        );
        foreach ($nodeInfo as $key => $node) {
            $node = json_decode($node->status, true);
            $nodeName = $node['NodeName'];
            $params['coreSummary']['total'] += $node['CPUTot'];
            $nodeState[$key] = array(
                'id' => $key + 1,
                'host' => $nodeName,
                'num_proc' => $node['CPUTot'], 
                'used' => 0,
                'reserved' => 0,
                'free' => 0,
                'State' => 'offline',
            );
            $onArray = array('DOWN','DRAIN','DOWN*','down','drain','down*');
            if (!in_array($node['State'], $onArray)) {
                //State is not Down or Drain
                $nodeState[$key]['State'] = 'online';
            } 
            if ($node['State'] != "DOWN") {
                //State is not Down
                $params['coreSummary']['offline'] += $node['CPUTot'];
            } else {
                //State is Down
                $params['coreSummary']['used'] += $node['CPUAlloc'];
                $params['coreSummary']['free'] += 
                ($node['CPUTot'] - $node['CPUAlloc']);

            }
            $params['coreSummary']['total'] += $node['CPUTot'];
            //             if (strpos($node['State'], "ALLOCATED") === false) {
            //                 $nodeState[$key]['State'] = 'online';
            //             } else {
            //                 $nodeState[$key]['used'] = $node['CPUAlloc'];
            //                 $params['coreSummary']['used'] += $node['CPUAlloc'];
            //             }
            //         // var_dump(strpos($node['State'], "DOWN"));
            //             if (strpos($node['State'], "DOWN") === FALSE) {
            // #                || strpos($node['State'], "DOWN*") === false) {
            //                 $nodeState[$key]['State'] = 'online';
            //             } else {
            //                 $params['coreSummary']['offline'] += $node['CPUTot'];
            //             }
        }
        $total = $params['coreSummary']['total'];
        $offline = $params['coreSummary']['offline'];
        $used = $params['coreSummary']['used'];
        $params['coreSummary']['avail'] = $total - $offline - $used;
        $params['details'] = $nodeState;
        if ($sshHost->getConnected() && $sshHost->authenticateAuto($userId)) {
            $cmd = "c3F1ZXVlIHwgc2VkICcxZCcgfCBzZWQgJ3MvXiBcKy8vZycgfCBhd2sgLXY".
                "gcXVldWVkPTAgLXYgcnVubmluZz0wIC12IGhvbGRlZD0wIC1GICIgIiAne3N3a".
                "XRjaCgkNSl7Y2FzZSAiUEQiOiBxdWV1ZWQrPTE7YnJlYWs7Y2FzZSAiUiI6IHJ".
                "1bm5pbmcrPTE7YnJlYWs7Y2FzZSAiUyI6IGhvbGRlZCs9MTticmVhazt9O31FT".
                "kR7cHJpbnQgIltbXCJydW5uaW5nXCIsInJ1bm5pbmciXSxbXCJxdWV1ZWRcIiw".
                "icXVldWVkIl0sW1wiaG9sZGVkXCIsICJob2xkZWQiXV0ifSc=";
            $cmd = base64_decode($cmd);
            $response = REQUIRED::lastCommandExitStatus(
                $sshHost->cmd($cmd.';echo $?')
            );
            $chartData = array();
            if ($response['status']) {
                $chartData = json_decode($response['message']);
                $params['chartData'] = $chartData;
            }
            Yii::import($this->module->id . ".controllers.TaskController");
            $jobs = Yii::app()->cache->get("activeJobs");
            $jobsObject = TaskController::getUserJobs($jobs);
            $jobInfo = array();
            if ($jobsObject && is_array($jobsObject)) {
                foreach ($jobsObject as $k => $jobObject) {
                    $status = $jobObject;
                    $user = explode("@", trim($status['UserId']));
                    $user = $user[0];
                    $jobDetail = array(
                        'id' => (int) $jobObject['JobId'],
                        'jobname' => $status['JobName'],
                        'user' => $user,
                        'queue' => $status['Partition'],
                        'submit_time' => $status['SubmitTime'],
                        'application' => $jobObject['application'],
                        'job_state' => $status['JobState'],
                        'priority' => $status['Priority'],
                        'slots' => isset($status['NumCPUs']) ? 
                            $status['NumCPUs'] : 0
                    );
                    array_push($jobInfo, $jobDetail); 
                }
            }
            $params['jobinfo'] = $jobInfo;
            $this->render('dashboard', $params);
            $sshHost->disconnect();
        }
    }

    /**
     * This is the action to handle external exceptions.
     *
     * @return null
     */
    public function actionError()
    {
        if ($error = Yii::app()->errorHandler->error) {
            if (Yii::app()->request->isAjaxRequest) {
                echo $error['message'];
            } else {
                $this->render('//home/error', $error);
            }
        }
    }
    /**
     * Return the queue information
     *
     * @return Array
     */
    public function actionGetQueueInfo()
    {
        $responseArray['status'] = INVALID_REQUEST;
        $responseArray['message'] = "Invalid Request";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $user = GhpcsUser::model()->find("username='admin'");
            $userId = $user->id;
            $host = Yii::app()->params->GHPCS['masterserverip'];
            $sshHost = new GSsh(array('host' => $host));
            switch ($_POST['query']) {
            case "jobs":
                $queueCommand = GjspCommandFiles::model()->find(
                    'name=:name',
                    array(
                    ':name' => 'sge_job_info_based_on_queue'
                    )
                );
                $queueCommand = base64_decode($queueCommand->content);
                $responseStr = str_replace(
                    "@@queue@@",
                    trim($_POST['queue']),
                    $queueCommand
                );
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $fileName = '/tmp/queueCommand.sh';
                    if ($sshHost->writeFile($fileName, $responseStr, 755)) {
                        $cmd = "sh {$fileName};echo $?";
                        $response = REQUIRED::lastCommandExitStatus(
                            $sshHost->cmd($cmd)
                        );
                        if (!$response['status']) {
                            $responseArray['status'] = COMMAND_ERROR;
                            $responseArray['message'] = 'Problem with '.
                            'the command.';
                        } else {
                            if (isset($response['message'])
                                && !empty($response['message'])
                            ) {
                                $jobs = json_decode($response['message'], true);
                                $jobs = $this->_getUserJobs($jobs);
                                $jobArray = array();
                                $addedJobs = array();
                                if (!empty($jobs)) {
                                    foreach ($jobs as $key => $job) {
                                        $slots = 0;
                                        foreach ($job as $index => $detail) {
                                            if ($index != 'queue'
                                                && strpos(
                                                    $index,
                                                    'queue'
                                                ) !== false
                                            ) {
                                                unset($jobs[$key][$index]);
                                            }
                                            if (strpos(
                                                $index,
                                                'master'
                                            ) !== false
                                            ) {
                                                if ($detail == "SLAVE") {
                                                    $slots++;
                                                }
                                                unset($jobs[$key][$index]);
                                            }
                                        }
                                        // $jobs[$key]['slots'] = $slots;
                                        array_push($jobArray, $jobs[$key]);
                                    }
                                }
                                if (!empty($jobArray)) {
                                    $responseArray['status'] = SUCCESS;
                                    $responseArray['message'] = $jobArray;
                                } else {
                                    $responseArray['status'] = DATABASE_ERROR;
                                    $responseArray['message'] = 'No Jobs ' .
                                    'are running in this Queue of yours.';
                                }
                            } else {
                                $responseArray['status'] = DATABASE_ERROR;
                                $responseArray['message'] = 'No Jobs ' .
                                'are running in this Queue.';
                            }
                        }
                    }
                }
                break;
            case "reserved":
                $queueCommand = GjspCommandFiles::model()->find(
                    'name=:name',
                    array(
                    ':name' => 'sge_queue_based_usage_details'
                    )
                );
                $queueCommand = base64_decode($queueCommand->content);
                $responseStr = str_replace(
                    "@@queue@@",
                    trim($_POST['queue']),
                    $queueCommand
                );
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $fileName = '/tmp/queueCommand.sh';
                    if ($sshHost->writeFile($fileName, $responseStr, 755)) {
                        $cmd = "sh {$fileName};echo $?";
                        $response = REQUIRED::lastCommandExitStatus(
                            $sshHost->cmd($cmd)
                        );
                        if (!$response['status']) {
                            $responseArray['status'] = COMMAND_ERROR;
                            $responseArray['message'] = 'Problem with '.
                            'the command.';
                        } else {
                            if (isset($response['message'])
                                && !empty($response['message'])
                            ) {
                                $queueInfo = json_decode(
                                    $response['message'],
                                    true
                                );
                                foreach ($queueInfo as $key => $queue) {
                                    $usage = explode("/", $queue['usage']);
                                    $queueInfo[$key]['reserved'] = $usage[0];
                                    unset($queueInfo[$key]['usage']);
                                }
                                $responseArray['status'] = SUCCESS;
                                $responseArray['message'] = $queueInfo;
                            } else {
                                $responseArray['status'] = DATABASE_ERROR;
                                $responseArray['message'] = 'No Queues '.
                                'available in cluster';
                            }
                        }
                    }
                }
                break;
            case "free":
                $queueCommand = GjspCommandFiles::model()->find(
                    'name=:name',
                    array(
                    ':name' => 'sge_queue_based_usage_details'
                    )
                );
                $queueCommand = base64_decode($queueCommand->content);
                $responseStr = str_replace(
                    "@@queue@@",
                    trim($_POST['queue']),
                    $queueCommand
                );
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $fileName = '/tmp/queueCommand.sh';
                    if ($sshHost->writeFile(
                        $fileName,
                        $responseStr,
                        755
                    )
                    ) {
                        $cmd = "sh {$fileName};echo $?";
                        $response = REQUIRED::lastCommandExitStatus(
                            $sshHost->cmd($cmd)
                        );
                        if (!$response['status']) {
                            $responseArray['status'] = COMMAND_ERROR;
                            $responseArray['message'] = 'Problem '.
                            'with the command.';
                        } else {
                            if (isset($response['message'])
                                && !empty($response['message'])
                            ) {
                                $queueInfo = json_decode(
                                    $response['message'],
                                    true
                                );
                                foreach ($queueInfo as $key => $queue) {
                                    $usage = explode("/", $queue['usage']);
                                    $t = $usage[2] - $usage[1] - $usage[0];
                                    $queueInfo[$key]['free'] = $t;
                                    unset($queueInfo[$key]['usage']);
                                }
                                $responseArray['status'] = SUCCESS;
                                $responseArray['message'] = $queueInfo;
                            } else {
                                $responseArray['status'] = DATABASE_ERROR;
                                $responseArray['message'] = 'No Queues '.
                                'available in cluster';
                            }
                        }
                    }
                }
                break;
            case "total":
                $queueCommand = GjspCommandFiles::model()->find(
                    'name=:name',
                    array(
                    ':name' => 'sge_queue_based_usage_details'
                    )
                );
                $queueCommand = base64_decode($queueCommand->content);
                $responseStr = str_replace(
                    "@@queue@@",
                    trim($_POST['queue']),
                    $queueCommand
                );
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $fileName = '/tmp/queueCommand.sh';
                    if ($sshHost->writeFile($fileName, $responseStr, 755)) {
                        $cmd = "sh {$fileName};echo $?";
                        $response = REQUIRED::lastCommandExitStatus(
                            $sshHost->cmd($cmd)
                        );
                        if (!$response['status']) {
                            $responseArray['status'] = COMMAND_ERROR;
                            $responseArray['message'] = 'Problem '.
                            'with the command.';
                        } else {
                            if (isset($response['message'])
                                && !empty($response['message'])
                            ) {
                                $queueInfo = json_decode(
                                    $response['message'],
                                    true
                                );
                                foreach ($queueInfo as $key => $queue) {
                                    $usage = explode("/", $queue['usage']);
                                    $queueInfo[$key]['reserved'] = $usage[0];
                                    $queueInfo[$key]['used'] = $usage[1];
                                    $t = $usage[2] - $usage[1] - $usage[0];
                                    $queueInfo[$key]['free'] = $t;
                                    $queueInfo[$key]['total'] = $usage[2];
                                    unset($queueInfo[$key]['usage']);
                                }
                                $responseArray['status'] = SUCCESS;
                                $responseArray['message'] = $queueInfo;
                            } else {
                                $responseArray['status'] = DATABASE_ERROR;
                                $responseArray['message'] = 'No Queues '.
                                'available in cluster';
                            }
                        }
                    }
                }
                break;
            }
            $sshHost->disconnect();
        }
        echo json_encode($responseArray);
    }
    /**
     * Returns the user jobs
     *
     * @param Array $jobs Array of jobs
     *
     * @return Array Object array
     */
    private function _getUserJobs($jobs)
    {
        $userLogged = Yii::app()->user->name;
        foreach ($jobs as $key => $job) {
            $jObj = Job::model()->find(
                "job_id=:job_id",
                array(':job_id' => $job['jobid'])
            );
            if ($jObj && !empty($jObj->app_id)) {
                $app = Application::model()->find(
                    'id=' . $jObj->app_id
                );
                $jobs[$key]['application'] = $app->name;
            } else {
                $jobs[$key]['application'] = 'STDIN';
            }
            if (trim($jobs[$key]['state']) != "r") {
                unset($jobs[$key]);
            }
        }
        if (!in_array($userLogged, array('root', 'admin')) && !empty($jobs)) {
            foreach ($jobs as $key => $job) {
                if ($job['user'] !== $userLogged) {
                    unset($jobs[$key]);
                }
            }
            $jobs = array_values($jobs);
        }
        return $jobs;
    }
    /**
     * Returns the Host Information
     *
     * @return Array
     */
    public function actionGetHostInfo()
    {
        $responseArray['status'] = INVALID_REQUEST;
        $responseArray['message'] = "Invalid Request";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $user = GhpcsUser::model()->find("username='admin'");
            $userId = $user->id;
            $host = Yii::app()->params->GHPCS['masterserverip'];
            $sshHost = new GSsh(array('host' => $host));
            switch ($_POST['query']) {
            case "host":
                $nodeObject = Node::model()->find(
                    'name=:name', array(':name' => $_POST['host'])
                );
                if ($nodeObject) {
                    $nodeObject = json_decode($nodeObject->status, true);
                    // $status = $nodeObject['status'];
                    // $nodeObject = array_merge($nodeObject, $status);
                    foreach ($nodeObject as $key => $nodeAttr) {
                        if (!is_array($nodeAttr)  
                            && (is_null($nodeAttr)  
                            || trim($nodeAttr) == "")
                        ) {
                            $nodeObject[$key] = '<div class="label '.
                                'label-important">Not Set</div>';
                        }
                    }
                    if (isset($nodeObject['rectime'])) {
                        $nodeObject['rectime'] = date(
                            'Y-m-d H:i:s',
                            $nodeObject['rectime']
                        );
                    }
                    unset($nodeObject['status']);
                    $responseArray['status'] = SUCCESS;
                    $responseArray['message'] = $nodeObject;
                } else {
                    $responseArray['status'] = DATABASE_ERROR;
                    $responseArray['message'] = "Node({$_POST["host"]}) is not'.
                                ' available in this cluster";   
                }
                break;
            case "used":
                $hostCommand = GjspCommandFiles::model()->find(
                    'name=:name',
                    array(
                    ':name' => 'sge_queue_info_used_based_on_host'
                    )
                );
                $hostCommand = base64_decode($hostCommand->content);
                $hostCommand = str_replace(
                    "@@host@@",
                    trim($_POST['host']),
                    $hostCommand
                );
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $fileName = '/tmp/hostCommand.sh';
                    if ($sshHost->writeFile($fileName, $hostCommand, 755)) {
                        $cmd = "sh {$fileName};echo $?";
                        $response = REQUIRED::lastCommandExitStatus(
                            $sshHost->cmd($cmd)
                        );
                        if (!$response['status']) {
                            $responseArray['status'] = COMMAND_ERROR;
                            $responseArray['message'] = 'Problem '.
                            'with the command.';
                        } else {
                            if (isset($response['message'])
                                && !empty($response['message'])
                            ) {
                                $queueInfo = json_decode(
                                    $response['message'],
                                    true
                                );
                                $responseArray['status'] = SUCCESS;
                                $responseArray['message'] = $queueInfo;
                            } else {
                                $responseArray['status'] = DATABASE_ERROR;
                                $responseArray['message'] = 'No Usage Queue(s)'.
                                ' available in this host';
                            }
                        }
                    }
                }
                break;
            case "total":
                $hostCommand = GjspCommandFiles::model()->find(
                    'name=:name',
                    array(
                    ':name' => 'sge_queue_info_total_based_on_host'
                    )
                );
                $hostCommand = base64_decode($hostCommand->content);
                $hostCommand = str_replace(
                    "@@host@@",
                    trim($_POST['host']),
                    $hostCommand
                );
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $fileName = '/tmp/hostCommand.sh';
                    if ($sshHost->writeFile(
                        $fileName,
                        $hostCommand,
                        755
                    )
                    ) {
                        $cmd = "sh {$fileName};echo $?";
                        $response = REQUIRED::lastCommandExitStatus(
                            $sshHost->cmd($cmd)
                        );
                        if (!$response['status']) {
                            $responseArray['status'] = COMMAND_ERROR;
                            $responseArray['message'] = 'Problem '.
                            'with the command.';
                        } else {
                            if (isset($response['message'])
                                && !empty($response['message'])
                            ) {
                                $queueInfo = json_decode(
                                    $response['message'],
                                    true
                                );
                                $responseArray['status'] = SUCCESS;
                                $responseArray['message'] = $queueInfo;
                            } else {
                                $responseArray['status'] = DATABASE_ERROR;
                                $responseArray['message'] = 'No Queues '.
                                'available in this host';
                            }
                        }
                    }
                }
                break;
            case "free":
                $hostCommand = GjspCommandFiles::model()->find(
                    'name=:name',
                    array(
                    ':name' => 'sge_queue_info_free_based_on_host'
                    )
                );
                $hostCommand = base64_decode($hostCommand->content);
                $hostCommand = str_replace(
                    "@@host@@",
                    trim($_POST['host']),
                    $hostCommand
                );
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $fileName = '/tmp/hostCommand.sh';
                    if ($sshHost->writeFile(
                        $fileName,
                        $hostCommand,
                        755
                    )
                    ) {
                        $cmd = "sh {$fileName};echo $?";
                        $response = REQUIRED::lastCommandExitStatus(
                            $sshHost->cmd($cmd)
                        );
                        if (!$response['status']) {
                            $responseArray['status'] = COMMAND_ERROR;
                            $responseArray['message'] = 'Problem '.
                            'with the command.';
                        } else {
                            if (isset($response['message'])
                                && !empty($response['message'])
                            ) {
                                $queueInfo = json_decode(
                                    $response['message'],
                                    true
                                );
                                $responseArray['status'] = SUCCESS;
                                $responseArray['message'] = $queueInfo;
                            } else {
                                $responseArray['status'] = DATABASE_ERROR;
                                $responseArray['message'] = 'No Queues '.
                                'available in this host';
                            }
                        }
                    }
                }
                break;
            case "jobs":
                $hostCommand = GjspCommandFiles::model()->find(
                    'name=:name',
                    array(
                    ':name' => 'sge_job_info_based_on_host'
                    )
                );
                $hostCommand = base64_decode($hostCommand->content);
                $hostCommand = str_replace(
                    "@@host@@",
                    trim($_POST['host']),
                    $hostCommand
                );
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $fileName = '/tmp/hostCommand.sh';
                    if ($sshHost->writeFile($fileName, $hostCommand, 755)) {
                        $cmd = "sh {$fileName};echo $?";
                        $response = REQUIRED::lastCommandExitStatus(
                            $sshHost->cmd($cmd)
                        );
                        if (!$response['status']) {
                            $responseArray['status'] = COMMAND_ERROR;
                            $responseArray['message'] = 'Problem '.
                            'with the command.';
                        } else {
                            if (isset($response['message'])
                                && !empty($response['message'])
                            ) {
                                $jobInfo = json_decode(
                                    $response['message'],
                                    true
                                );
                                $jobArray = array();
                                foreach ($jobInfo as $key => $job) {
                                    $jobObj = Job::model()->find(
                                        'job_id=:job_id',
                                        array(':job_id' => $job['jobid'])
                                    );
                                    $jobInfo[$key]['application'] = 'STDIN';
                                    if ($jobObj) {
                                        $appObj = Application::model()->find(
                                            'id=:id',
                                            array(
                                            ':id' => $jobObj->app_id
                                            )
                                        );
                                        if ($appObj) {
                                            $t =  $appObj->name;
                                            $jobInfo[$key]['application'] = $t;
                                        }
                                    }
                                    array_push($jobArray, $jobInfo[$key]);
                                }
                                $responseArray['status'] = SUCCESS;
                                $responseArray['message'] = $jobArray;
                            } else {
                                $responseArray['status'] = DATABASE_ERROR;
                                $responseArray['message'] = 'No Queues '.
                                'available in this host';
                            }
                        }
                    }
                }
                break;
            }
            $sshHost->disconnect();
        }
        echo json_encode($responseArray);
    }
    /**
     * Export the jobs information using csv file
     *
     * @return NULL
     */
    public function actionExport() 
    {
        $orderedArray = array();
        Yii::import($this->module->id . ".controllers.TaskController");
        $jobs = Yii::app()->cache->get("activeJobs");
        $jobsObject = TaskController::getUserJobs($jobs);
        if ($jobsObject && is_array($jobsObject)) {
            foreach ($jobsObject as $k => $jobObject) {
                $status = $jobObject;
                $user = $status['UserId'];
                if (isset($status['exec_host'])) {
                    $tmpSts = $status['exec_host'];
                    $tmpSts = str_replace("{", "", $tmpSts);
                    $tmpSts = str_replace("}", "", $tmpSts);
                    $tmpSts = str_replace("\"", "", $tmpSts);
                    $tmpSts = str_replace(",", " | ", $tmpSts);
                    $status['exec_host'] = $tmpSts;
                }
                $jobDetail = array(
                    'id' => (int) $jobObject['JobId'],
                    'jobname' => $status['JobName'],
                    'user' => $user,
                    'queue' => $status['Partition'],
                    'submit_time' => $status['SubmitTime'],
                    'application' => $jobObject['application'],
                    'job_state' => $status['JobState'],
                    'priority' => $status['Priority'],
                    'slots' => isset($status['resources_used.ncpus']) ? 
                        $status['resources_used.ncpus'] : 0,
                    'exec_host' => isset($status['exec_host']) ?
                        $status['exec_host'] : ""
                );
                array_push($orderedArray, $jobDetail);
            }
        } 
        header('Content-type: application/csv');
        header(
            'Content-Disposition: attachment; filename="' .
            'report_'.date('YmdHis').'.csv"'
        );
        echo "Job Id,Job Name,User,Partition,".
        "Submit Tiume,Application,State,Priority,Slots,Execution Hosts\n";
        foreach ($orderedArray as $k => $v) {
            echo implode(",", $v)."\n";
        }
    }
    /**
     * List all licensed users
     *
     * @return NULL
     */
    public function actionListUsers()
    {
        $users = GjspUser::model()->findAll();
        $this->render('listusers', array('users' => $users));
    }
    /**
     * Remove given licensed user
     *
     * @param int $id Licensed User Id
     *
     * @return NULL
     */
    public function actionDelete($id)
    {
        $user = GjspUser::model()->find('id='.$id);
        if ($user) {
            $userName = $user->username;
            Job::model()->deleteAll(
                'submitted_by=:user',
                array(':user' => $userName)
            );
            if ($user->delete()) {
                Yii::app()->user->setFlash(
                    'success',
                    "User ({$userName}) deleted successfully."
                );
            } else {
                Yii::app()->user->setFlash(
                    'error',
                    "Unable to delete user ({$userName})."
                );
            }
        } else {
            Yii::app()->user->setFlash(
                'error',
                'Given user is not available.'
            );
        }
    }    
}

