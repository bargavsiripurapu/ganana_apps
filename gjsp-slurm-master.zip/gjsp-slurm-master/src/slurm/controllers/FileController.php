<?php
/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  TORQUE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * FileController class is using to access/manage filesystem of master node
 *
 * @category Job_Submission_Portal
 * @package  TORQUE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class FileController extends Controller
{
    /**
     * Displays the default page(index) UI
     *
     * @return null
     */
    public function actionIndex()
    {
        $this->layout = '//layouts/column2';
        $userLogged = Yii::app()->user->name;
        $this->render('index', array('user' => $userLogged));
    }

    // Uncomment the following methods and override them if needed
    /*
      public function filters()
      {
      // return the filter configuration for this controller, e.g.:
      return array(
      'inlineFilterName',
      array(
      'class'=>'path.to.FilterClass',
      'propertyName'=>'propertyValue',
      ),
      );
      }

      public function actions()
      {
      // return external action classes, e.g.:
      return array(
      'action1'=>'path.to.ActionClass',
      'action2'=>array(
      'class'=>'path.to.AnotherActionClass',
      'propertyName'=>'propertyValue',
      ),
      );
      }
     */
    //--------------------------------------------------------------------------
    /**
     * Access filesystem of home directory from master node
     *
     * @return null
     */
    public function actionFilesystem()
    {
        $responseArray['status'] = INVALID_REQUEST;
        $responseArray['message'] = "Invalid request. ".
        "Server cannot process your request.";
        if (isset($_POST)) {
            if ($this->isValidPath($_POST['path'])) {
                $host = Yii::app()->params->GHPCS['masterserverip'];
                $userId = Yii::app()->user->id;
                $user = Yii::app()->user->name;
                $sshHost = new GSsh(array('host' => $host));
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $fileSystem = $sshHost->readFileSystem($_POST['path']);
                    if (is_array($fileSystem)) {
                        $paths = explode('/', $_POST['path']);
                        unset($paths[0]);
                        $paths = array_values($paths);
                        $userLogged = Yii::app()->user->name;
                        if ($userLogged === "root") {
                            unset($paths[0]);
                            $paths = array_values($paths);
                        } else {
                            unset($paths[0]);
                            unset($paths[1]);
                            $paths = array_values($paths);
                        }
                        $parentDir = "";
                        if (count($paths) > 0) {
                            $parentDir = (isset(
                                $paths[count($paths) - 2]
                            ) ?
                            $paths[count($paths) - 2] :
                            (($userLogged === "root") ?
                            "/root" : "/home/$user")
                            );
                        }
                        $responseArray['status'] = SUCCESS;
                        $responseArray['message'] = "File system".
                        " accessed successfully.";
                        $responseArray['result'] = $this->renderPartial(
                            'file_list',
                            array(
                            'fileSystem' => $fileSystem,
                            'parent' => $parentDir
                            ),
                            true
                        );
                        $responseArray['path'] = $_POST['path'];
                    } else {
                        $responseArray['status'] = UNKNOWN_ERROR;
                        $responseArray['message'] = "Unable to access".
                        " the file system.".
                        " or Specified directory".
                        " doesn't have any file(s).";
                    }
                    $sshHost->disconnect();
                } else {
                    $responseArray['status'] = AUTHENTICATION_ERROR;
                    $responseArray['message'] = "Problem with".
                    " credentilas (or) unable connect".
                    " to master node.".
                    " Please relogin & try again.";
                }
            } else {
                $responseArray['status'] = UN_AUTH_ACCESS;
                $responseArray['message'] = "You are not".
                " authorised to perform this action.";
            }
        }
        echo str_replace("\r\n", "", json_encode($responseArray));
    }

    //--------------------------------------------------------------------------
    /**
     * Create directory in master node on requested path
     *
     * @return null
     */
    public function actionAdddir()
    {
        $responseArray['status'] = INVALID_REQUEST;
        $responseArray['message'] = "Invalid request.".
        " Server cannot process your request.";
        if (isset($_POST)) {
            if ($this->isValidPath($_POST['path'])) {
                $host = Yii::app()->params->GHPCS['masterserverip'];
                $userId = Yii::app()->user->id;
                $sshHost = new GSsh(array('host' => $host));
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $pathToDir = $_POST['path'];
                    $directory = $_POST['dir'];
                    $response = $sshHost->cmd(
                        "mkdir " .
                        $pathToDir . "/" .
                        $directory .
                        ";echo $?"
                    );
                    if ((int) $response === 0) {
                        $responseArray['status'] = SUCCESS;
                        $responseArray['message'] = "Directory ".
                        "$directory created successfully.";
                    } else {
                        $responseArray['status'] = COMMAND_ERROR;
                        $responseArray['message'] = "Unable to ".
                        "create $directory.".
                        " Please try again.";
                    }
                    $sshHost->disconnect();
                } else {
                    $responseArray['status'] = AUTHENTICATION_ERROR;
                    $responseArray['message'] = "Problem with".
                    " credentilas (or) unable connect".
                    " to master node.".
                    " Please relogin & try again.";
                }
            } else {
                $responseArray['status'] = UN_AUTH_ACCESS;
                $responseArray['message'] = "You are".
                " not authorised to perform this action.";
            }
        }
        echo json_encode($responseArray);
    }

    //--------------------------------------------------------------------------
    /**
     * Checks wether user can access specified file or not
     *
     * @param string $path path of the file/directory
     *
     * @return Boolean TRUE If valid otherwise FALSE
     */
    public function isValidPath($path)
    {
        $dirs = explode('/', $path);
        // var_dump($path);
        unset($dirs[0]);
        $dirs = array_values($dirs);
        // var_dump($dirs);exit;
        $user = Yii::app()->user->name;
        $compDir = false;
        if ($user === "root") {
            $compDir = (("/root" === "/" . $dirs[0]) ? true : false);
        } else {
            $compDir = (("/home/" .
            $user === "/" .
            $dirs[0] . "/" .
            $dirs[1]) ? true : false
            );
        }
        return $compDir;
    }

    //--------------------------------------------------------------------------
    /**
     * Download file from master node to client(browser)
     *
     * @return JSON response which contains file url
     */
    public function actionDownloadfile()
    {
        $responseArray['status'] = INVALID_REQUEST;
        $responseArray['message'] = "Invalid request.".
        " Server cannot process your request.";
        if (isset($_GET['remoteFile'])) {
            $remoteFile = $_GET['remoteFile'];
            if ($this->isValidPath($remoteFile)) {
                $host = Yii::app()->params->GHPCS['masterserverip'];
                $userId = Yii::app()->user->id;
                $sshHost = new GSsh(array('host' => $host));
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    if ($sshHost->fileExists($remoteFile)) {
                        if (($content = $sshHost->readFile($remoteFile)) === false) {
                            $responseArray['status'] = COMMAND_ERROR;
                            $responseArray['message'] = "Unable to".
                            " download file($remoteFile).".
                            " Please try again.";
                        } else {
                            $responseArray['content'] = $content;
                            $responseArray['status'] = SUCCESS;
                            $responseArray['message'] = "Your file".
                            "({$remoteFile}) is ready to download.";
                        }
                    } else {
                        $responseArray['status'] = UNKNOWN_ERROR;
                        $responseArray['message'] = "Your file".
                        "({$remoteFile}) is not available in file system.";
                    }
                } else {
                    $responseArray['status'] = AUTHENTICATION_ERROR;
                    $responseArray['message'] = "Problem with".
                    " credentilas (or) unable connect to master node.".
                    " Please relogin & try again.";
                }
            } else {
                $responseArray['status'] = UN_AUTH_ACCESS;
                $responseArray['message'] = "You are".
                " not authorised to perform this action.";
            }
        }
        $this->renderPartial(
            "download",
            array(
            'response' => $responseArray,
            'file' => ((isset($_GET['remoteFile'])) ? $_GET['remoteFile'] : "")
            )
        );
    }

    //--------------------------------------------------------------------------
    /**
     * Delete file in master node
     *
     * @return JSON Response true if deleted, otherwise false
     */
    public function actionDeletefile()
    {
        $responseArray['status'] = INVALID_REQUEST;
        $responseArray['message'] = "Invalid request.".
        " Server cannot process your request.";
        if (isset($_POST)) {
            if ($this->isValidPath($_POST['path'])) {
                $host = Yii::app()->params->GHPCS['masterserverip'];
                $userId = Yii::app()->user->id;
                $sshHost = new GSsh(array('host' => $host));
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $remoteFile = $_POST['remoteFile'];
                    if ($_POST['type'] === "file") {
                        $response = $sshHost->deleteFile(
                            $_POST['path'] . '/' .
                            $remoteFile
                        );
                    } else {
                        if ($sshHost->readFileSystem(
                            $_POST['path'] . '/' .
                            $remoteFile
                        )
                        ) {
                            $response = false;
                            $responseArray['status'] = COMMAND_ERROR;
                            $responseArray['message'] = "Unable to delete".
                            " $remoteFile directory.".
                            " It must be empty to delete.";
                        } else {
                            if ($sshHost->removeDir(
                                $_POST['path'] . '/' .
                                $remoteFile
                            )
                            ) {
                                $response = true;
                            } else {
                                $response = false;
                                $responseArray['status'] = COMMAND_ERROR;
                                $responseArray['message'] = "Unable to delete".
                                " $remoteFile directory.".
                                " Please try again.";
                            }
                        }
                    }
                    if ($response) {
                        $responseArray['status'] = SUCCESS;
                        $responseArray['message'] = "$remoteFile ".
                        "deleted successfully.";
                    }
                    $sshHost->disconnect();
                } else {
                    $responseArray['status'] = AUTHENTICATION_ERROR;
                    $responseArray['message'] = "Problem with".
                    " credentilas (or) unable connect to master node.".
                    " Please relogin & try again.";
                }
            } else {
                $responseArray['status'] = UN_AUTH_ACCESS;
                $responseArray['message'] = "You are not".
                " authorised to perform this action.";
            }
        }
        echo json_encode($responseArray);
    }

    //--------------------------------------------------------------------------
    /**
     * Rename file in masternode
     *
     * @return JSON Response true if renamed, otherwise false
     */
    public function actionRenamefile()
    {
        $responseArray['status'] = INVALID_REQUEST;
        $responseArray['message'] = "Invalid request.".
        " Server cannot process your request.";
        if (isset($_POST)) {
            if ($this->isValidPath($_POST['path'])) {
                $host = Yii::app()->params->GHPCS['masterserverip'];
                $userId = Yii::app()->user->id;
                $sshHost = new GSsh(array('host' => $host));
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $newFile = $_POST['newFile'];
                    $oldFile = $_POST['oldFile'];
                    $userLogged = Yii::app()->user->name;
                    $response = false;
                    if ($userLogged === "root") {
                        $cmd = "mv {$_POST['path']}/{$oldFile}".
                        " {$_POST['path']}/{$newFile};echo \$?";
                        $response = $sshHost->cmd($cmd);
                        $response = (((int) $response === 0) ? true : false);
                    } else {
                        $response = $sshHost->renameFile(
                            $_POST['path'] . '/' . $oldFile,
                            $_POST['path'] . '/' . $newFile
                        );
                    }
                    if ($response) {
                        $responseArray['status'] = SUCCESS;
                        $responseArray['message'] = "$oldFile ".
                        "to $newFile renamed successfully.";
                    } else {
                        $responseArray['status'] = COMMAND_ERROR;
                        $responseArray['message'] = "Unable to rename".
                        " $oldFile to $newFile.".
                        " Please try again.";
                    }
                    $sshHost->disconnect();
                } else {
                    $responseArray['status'] = AUTHENTICATION_ERROR;
                    $responseArray['message'] = "Problem with ".
                    "credentilas (or) unable connect to master node.".
                    " Please relogin & try again.";
                }
            } else {
                $responseArray['status'] = UN_AUTH_ACCESS;
                $responseArray['message'] = "You are not".
                " authorised to perform this action.";
            }
        }
        echo json_encode($responseArray);
    }

    //--------------------------------------------------------------------------
    /**
     * Uploading file from the client(browser) to masternode
     *
     * @return JSON Response true if uploads, otherwise false
     */
    public function actionUploadfile()
    {
        // var_dump("HIIIIIIIIII");exit;
        $responseArray['status'] = INVALID_REQUEST;
        $responseArray['message'] = "Invalid request.".
        " Server cannot process your request.";
        if (isset($_POST)) {
            if ($this->isValidPath($_POST['path'])) {
                $host = Yii::app()->params->GHPCS['masterserverip'];
                $userId = Yii::app()->user->id;
                $sshHost = new GSsh(array('host' => $host));
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $path = $_POST['path'];
                    $userLogged = Yii::app()->user->name;
		    // @codingStandardsIgnoreStart	
                    //                    $fileSizeObj = TorqueSetting::model()->find(
                    //                        "name='uploadMaxFileSize'"
                    //                    );
                    //                    if ($_FILES['fileLocation']['size'] <= $fileSizeObj->value) {
		    // @codingStandardsIgnoreEnd	
                    if ($_FILES['fileLocation']['size'] <= 20971520) {
                        if ($sshHost->fileExists(
                            $path . '/' . $_FILES['fileLocation']['name']
                        )
                        ) {
                            unlink($_FILES['fileLocation']['tmp_name']);
                            $responseArray['status'] = UNKNOWN_ERROR;
                            $responseArray['message'] = "Unable to upload file(".
                            "{$_FILES['fileLocation']['name']}),".
                            " which is already exists".
                            " in this directory({$path})";
                        } else {
                            if ($sshHost->sendFile(
                                $_FILES['fileLocation']['tmp_name'],
                                $path . '/' . $_FILES['fileLocation']['name']
                            )
                            ) {
                                unlink($_FILES['fileLocation']['tmp_name']);
                                $responseArray['status'] = SUCCESS;
                                $responseArray['message'] = "".
                                "{$_FILES['fileLocation']['name']} ".
                                "to {$path} uploaded successfully.";
                            } else {
                                unlink($_FILES['fileLocation']['tmp_name']);
                                $responseArray['status'] = COMMAND_ERROR;
                                $responseArray['message'] = "Unable to upload ".
                                "{$_FILES['fileLocation']['name']}".
                                " to {$path}. Please try again.";
                            }
                        }
                    } else {
                        unlink($_FILES['fileLocation']['tmp_name']);
                        $responseArray['status'] = UNKNOWN_ERROR;
                        $responseArray['message'] = "Unable to upload file(".
                        "{$_FILES['fileLocation']['name']}), ".
                        "its size is too much.";
                    }
                    $sshHost->disconnect();
                } else {
                    $responseArray['status'] = AUTHENTICATION_ERROR;
                    $responseArray['message'] = "Problem with credentials".
                    " (or) unable connect to master node.".
                    " Please relogin & try again.";
                }
            } else {
                $responseArray['status'] = UN_AUTH_ACCESS;
                $responseArray['message'] = "You are not".
                " authorised to perform this action.";
            }
        }
        $this->renderPartial(
            'upload',
            array(
            'response' => $responseArray,
            'path' => $_POST['path']
            )
        );
    }

    //--------------------------------------------------------------------------
    /**
     * Reading file from the master node
     *
     * @return JSON Response true if reads, otherwise false
     */
    public function actionReadfile()
    {
        $responseArray['status'] = INVALID_REQUEST;
        $responseArray['message'] = "Invalid request.".
        " Server cannot process your request.";
        if (isset($_POST)) {
            if ($this->isValidPath($_POST['path'])) {
                $host = Yii::app()->params->GHPCS['masterserverip'];
                $userId = Yii::app()->user->id;
                $sshHost = new GSsh(array('host' => $host));
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $path = $_POST['path'];
                    $userLogged = Yii::app()->user->name;
                    if (!$sshHost->fileExists($path . '/' . $_POST['remoteFile'])) {
                        $responseArray['status'] = UNKNOWN_ERROR;
                        $responseArray['message'] = "Requested ".
                        "file is not available in current directory.";
                    } else {
                        if (($content = $sshHost->readFile(
                            $path . '/' . $_POST['remoteFile']
                        )) === false
                        ) {
                            $responseArray['status'] = SUCCESS;
                            $responseArray['message'] = "{$_POST['remoteFile']}".
                            " is read successfully.";
                            $responseArray['content'] = $content;
                        } else {
                            $responseArray['status'] = COMMAND_ERROR;
                            $responseArray['message'] = "Unable to read".
                            " {$_POST['remoteFile']} from {$path}. ".
                            "Please try again.";
                        }
                    }
                    $sshHost->disconnect();
                } else {
                    $responseArray['status'] = AUTHENTICATION_ERROR;
                    $responseArray['message'] = "Problem with credentilas".
                    " (or) unable connect to master node.".
                    " Please relogin & try again.";
                }
            } else {
                $responseArray['status'] = UN_AUTH_ACCESS;
                $responseArray['message'] = "You are not".
                " authorised to perform this action.";
            }
        }
        echo json_encode($responseArray);
    }

    //--------------------------------------------------------------------------
    /**
     * Writing file content from client(browser)
     *
     * @return JSON Response true if writes, otherwise false
     */
    public function actionWritefile()
    {
        $responseArray['status'] = INVALID_REQUEST;
        $responseArray['message'] = "Invalid request.".
        " Server cannot process your request.";
        if (isset($_POST)) {
            if ($this->isValidPath($_POST['path'])) {
                $host = Yii::app()->params->GHPCS['masterserverip'];
                $userId = Yii::app()->user->id;
                $sshHost = new GSsh(array('host' => $host));
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    $path = $_POST['path'];
                    $userLogged = Yii::app()->user->name;
                    if (!$sshHost->fileExists($path . '/' . $_POST['remoteFile'])) {
                        $responseArray['status'] = UNKNOWN_ERROR;
                        $responseArray['message'] = "Requested ".
                        "file is not available in current directory.";
                    } else {
                        if (($content = $sshHost->writeFile(
                            $path . '/' . $_POST['remoteFile'],
                            $_POST['content']
                        )) === false
                        ) {
                            $responseArray['status'] = COMMAND_ERROR;
                            $responseArray['message'] = "Unable to write".
                            " {$_POST['remoteFile']} to".
                            " {$path}. Please try again.";
                        } else {
                            $responseArray['status'] = SUCCESS;
                            $responseArray['message'] = "{$_POST['remoteFile']}".
                            " is written successfully.";
                        }
                    }
                    $sshHost->disconnect();
                } else {
                    $responseArray['status'] = AUTHENTICATION_ERROR;
                    $responseArray['message'] = "Problem with credentilas".
                    " (or) unable connect to master node.i".
                    " Please relogin & try again.";
                }
            } else {
                $responseArray['status'] = UN_AUTH_ACCESS;
                $responseArray['message'] = "You are not".
                " authorised to perform this action.";
            }
        }
        echo json_encode($responseArray);
    }

    //--------------------------------------------------------------------------
    /**
     * Displays file editor page
     *
     * @return null
     */
    public function actionEdit()
    {
        $responseArray['status'] = INVALID_REQUEST;
        $responseArray['message'] = "Invalid request.".
        " Server cannot process your request".
        "(you cannot access this file.)";
        if (isset($_GET['file']) && $this->isValidPath($_GET['file'])) {
            $host = Yii::app()->params->GHPCS['masterserverip'];
            $userId = Yii::app()->user->id;
            $sshHost = new GSsh(array('host' => $host));
            if ($sshHost->getConnected() && $sshHost->authenticateAuto($userId)) {
                $content = $sshHost->readFile($_GET['file']);
                if ($content) {
                    $responseArray['status'] = SUCCESS;
                    $responseArray['message'] = $content;
                } else {
                    $responseArray['status'] = COMMAND_ERROR;
                    $responseArray['message'] = "Unable to read file.";
                }
            } else {
                $responseArray['status'] = AUTHENTICATION_ERROR;
                $responseArray['message'] = "Problem with credentilas (or)".
                " unable connect to master node.".
                " Please relogin & try again.";
            }
        }
        $this->render('edit', $responseArray);
    }
}

// End of the FileController class
// End of the FileController.php file
