<?php

/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  TORQUE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * Application Controller manages the application(s)
 *
 * @category Job_Submission_Portal
 * @package  TORQUE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class ApplicationController extends Controller
{

    /**
     * Specifies the layout of the controller
     *
     * @var string the default layout for the views.
     * Defaults to '//layouts/column2', meaning
     * using two-column layout. See 'protected/views/layouts/column2.php'
     */
    public $layout = '//layouts/column2';

    //--------------------------------------------------------------------------
    /**
     * Specifies filters of the controller
     *
     * @return array action filters
     */
    public function filters() 
    {
        return array(
            'accessControl', // perform access control for CRUD operations
                // 'postOnly + delete', // we only allow deletion via POST request
        );
    }
    /**
     * Executes before action if needed
     * 
     * @param Object $action Action Object
     *
     * @return NULL No Return
     */
    public function beforeAction($action) 
    {
        parent::beforeAction();
        if (in_array($action->getId(), array('importt', 'export'))) {
            foreach (Yii::app()->log->routes as $route) {
                if ($route instanceof CWebLogRoute) {
                    $route->enabled = false;
                }
            }
        }
        return true;
    }

    //--------------------------------------------------------------------------
    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     *
     * @return array access control rules
     */
    public function accessRules() 
    {
        return array(
            array(
                'allow',
                'actions' => array(
                    'index',
                    'create',
                    'update',
                    'buildform',
                    'formEditor',
                    'export',
                    'import',
                    'view',
                    'delete'
                ),
                'users' => array('admin','root')
            ),
            array('deny',
                'users' => array('*'),
            ),
        );
    }

    //--------------------------------------------------------------------------
    /**
     * Displays a particular model.
     *
     * @param integer $id the ID of the model to be displayed
     * 
     * @return null
     */
    public function actionView($id) 
    {
        $model = $this->loadModel($id);
        // $model->script = base64_decode($model->script);
        // $model->attributes = json_decode($model->attributes);
        // $model->details = base64_decode($model->details);
        
        $this->render(
            'view', array(
            'model' => $model,
            'flashes' => array(),
            'permissions' => AppPermission::model()->findAll('app_id=' . $id),
                )
        );
    }

    //--------------------------------------------------------------------------
    /**
     * Creates a new model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     *
     * @param Integer $id Use's specified application as template
     *
     * @return null
     */
    public function actionCreate($id=null) 
    {
        if (!$this->hasLicenceAvailibility()) {
            Yii::app()->user->setFlash(
                "error",
                "Licence count is exhausted.".
                "Please check the licence details."
            );
            Yii::app()->controller->redirect("index");
        }
        $this->layout = '//layouts/column1';
        $model = new Application;
        $flashes = array();
        // Uncomment the following line if AJAX validation is needed
        // $this->performAjaxValidation($model);
        $params = array();
        if ($_SERVER['REQUEST_METHOD'] === "POST") {
            if (isset($_POST['generateFormApplication'])) {
                $params = array();
                if (isset($_POST['generateFormApplication']['Name'])) {
                    $model->name = $_POST['generateFormApplication']['Name'];
                }
                if (isset($_POST['generateFormApplication']['Attributes'])) {
                    $model->attributes = base64_decode(
                        $_POST['generateFormApplication']['Attributes']
                    );
                }
                $model->save(false);
                $this->redirect(array('application/update/id/'.$model->id));
            } else {
                $params['from'] = 'appCreate';
                if ($this->assignAttributes(
                    $_POST['Application']['script'], 
                    $_POST['Application']['attributes']
                )
                ) {
                    $_POST['Application']['script'] = base64_encode(
                        htmlspecialchars($_POST['Application']['script'])
                    );
                    $attributes = str_replace(
                        "\r\n\t", "", $_POST['Application']['attributes']
                    );
                    $attributes = str_replace("\r\n", "", $attributes);
                    $attributes = str_replace("\n\t", "", $attributes);
                    $_POST['Application']['attributes'] = str_replace(
                        "\n", "", $attributes
                    );
                    if (isset($_POST['Application']['file_upload'])
                        && $_POST['Application']['file_upload']
                    ) {
                        $model->file_upload = true;
                    } else {
                        $model->file_upload = false;
                    }
                    if (isset($_POST['Application']['include_files'])
                        && $_POST['Application']['include_files']
                    ) {
                        $model->include_files = true;
                    } else {
                        $model->include_files = false;
                    }
                    $model->script = $_POST['Application']['script'];
                    $model->details = $_POST['Application']['details'];
                    $model->attributes = $_POST['Application']['attributes'];
                    $model->name = $_POST['Application']['name'];
                    if (isset($_POST['Application']['user_access'])  
                        && is_array($_POST['Application']['user_access'])  
                        && !empty($_POST['Application']['user_access'])
                    ) {
                        $model->user_access = json_encode(
                            $_POST['Application']['user_access']
                        );
                    }
                    if (isset($_POST['Application']['group_access'])  
                        && is_array($_POST['Application']['group_access'])  
                        && !empty($_POST['Application']['group_access'])
                    ) {
                        $model->group_access = json_encode(
                            $_POST['Application']['group_access']
                        );
                    }
                    if (isset($_POST['Application']['user_script_edit'])  
                        && is_array($_POST['Application']['user_script_edit'])  
                        && !empty($_POST['Application']['user_script_edit'])
                    ) {
                        $model->user_script_edit = json_encode(
                            $_POST['Application']['user_script_edit']
                        );
                    }
                    if (isset($_POST['Application']['group_script_edit'])  
                        && is_array($_POST['Application']['group_script_edit'])  
                        && !empty($_POST['Application']['group_script_edit'])
                    ) {
                        $model->group_script_edit = json_encode(
                            $_POST['Application']['group_script_edit']
                        );
                    }
                    $app = Application::model()->find(
                        'name=:name', array(":name" => $model->name)
                    );
                    if (count($app)==0) {
                        if ($model->save()) {
                            Yii::app()->user->setFlash(
                                'success', "<strong>{$model->name}</strong> " .
                                    "Application Installed successfully."
                            );
                            $this->redirect(
                                array(
                                        'view', 'id' => $model->id)
                            );
                        } else {
                            array_push(
                                $flashes, "<strong>Info</strong> " .
                                    "Unable to save data.Please try again."
                            );
                        }
                    } else {
                            $model->script = base64_decode($model->script);
                            array_push(
                                $flashes, "<strong>Error</strong> " .
                                "Application Name already used." .
                                "Please use another."
                            );
                    }
                } else {
                    array_push(
                        $flashes, "<strong>Invalid JSON</strong> " .
                            "Your attribute(s) and script are not matched."
                    );
                    $this->redirect(array('index'));
                }
            }
            // $this->redirect(array('index'));
            $this->render(
                'create', array(
                 'model' => $model,
                 'flashes' => $flashes,
                 'params' => $params,
                 'users' => REQUIRED::readSystemUsers(),
                 'groups' => UserGroup::model()->findAll(),
                 'copy' => is_null($id) ? false : true
                    )
            );
        } else {
            $params['from'] = 'appCreate';
            if (!is_null($id)) {
                $model = $this->loadModel($id);
                if (!$model) {
                    throw CHttpException('500', "Specified application not found.");
                }
                $model->script = base64_decode($model->script);
                $this->render(
                    'create', array(
                    'model' => $model,
                    'params' => $params,
                    'flashes' => array(),
                    'users' => REQUIRED::readSystemUsers(),
                    'groups' => UserGroup::model()->findAll(),
                    'copy' => is_null($id) ? false : true
                    )
                );
            
            } else {
                $defaultFields = array(
                array(
                    'type' => 'textBox',
                    'values' => false,
                    'name' => 'name',
                    'label' => 'Job Name',
                    'depend' => null,
                    'rules' => array(
                        'required' => true,
                        'email' => false,
                        'numerical' => false,
                        'match' => false,
                        'in' => false,
                        'lengths' => array(
                            'max' => 255,
                            'min' => false,
                            'is' => false,
                            'tooShort' => false,
                            'tooLong' => false
                        )
                    )
                ),
                array(
                    'type' => 'select',
                    'values' => array(
                'type' => "httpRequest",
                'url' => "**@@hosturl@@**/queue/getQueueList"
                    ),
                    'name' => 'queue',
                    'label' => 'Select Queue',
                    'depend' => null,
                    'rules' => array(
                        'required' => true,
                        'email' => false,
                        'numerical' => false,
                        'match' => false,
                        'in' => false,
                        'lengths' => false
                    )
                )
                );
                $this->render('formEditor', array('attributes' => $defaultFields));
            }
        }
    }
    /**
     * Checks wether application licence available or not
     *
     * @return Boolean
     */
    public function hasLicenceAvailibility() 
    {
        $license = LicenseParam::model()->find('id=1');
        $licenceArray = GjspUtils::checkKey(
            $license->licence,
            $license->publickey
        );
        $licCount = (int) $licenceArray['Application-Count'];
        $appCount = Application::model()->count();
        if ($licCount > $appCount) {
            return true;
        }
        return false;
    }
    //--------------------------------------------------------------------------
    /**
     * Updates a particular model.
     * If update is successful, the browser will be redirected to the 'view' page.
     *
     * @param integer $id the ID of the model to be updated
     *
     * @return null
     */
    public function actionUpdate($id) 
    {
        $this->layout = '//layouts/column1';
        $model = $this->loadModel($id);
        $flashes = array();
        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            if (isset($_POST['generateFormApplication'])) {
                $params = array();
                if (isset($_POST['generateFormApplication']['Name'])) {
                    $model->name = $_POST['generateFormApplication']['Name'];
                }
                if (isset($_POST['generateFormApplication']['Attributes'])) {
                    $model->attributes = base64_decode(
                        $_POST['generateFormApplication']['Attributes']
                    );
                    $model->save();
                }
                $params['from'] = 'formBuilder';
            } else if (isset($_POST['Application'])) {
                $permissionArray = array();
                if (isset($_POST['AppPermission'])) {
                    $uESAL = array();
                    $nUP = true;
                    if (isset($_POST['AppPermission']['user_edit_script'])  
                        && !empty($_POST['AppPermission']['user_edit_script'])
                    ) {
                        $uES = $_POST['AppPermission']['user_edit_script'];
                        foreach ($uES as $key => $value) {
                            array_push(
                                $permissionArray, array(
                                    'app_id' => $id,
                                    'type' => 'user',
                                    'target_id' => $value,
                                    'edit_script' => true,
                                    'access_application' => false
                                )
                            );
                            array_push($uESAL, $value);
                        }
                        $nUP = true;
                    } else {
                        $nUP = false;
                    }
                    if (isset($_POST['AppPermission']['user_access'])
                        && !empty($_POST['AppPermission']['user_access'])
                    ) {
                        $uAS = $_POST['AppPermission']['user_access'];
                        foreach ($uAS as $key => $value) {
                            if (!in_array($value, $uESAL)) {
                                array_push($uESAL, $value);
                                array_push(
                                    $permissionArray, array(
                                        'app_id' => $id,
                                        'type' => 'user',
                                        'target_id' => $value,
                                        'access_application' => true,
                                        'edit_script' => false
                                    )
                                );
                            } else {
                                $lI = count($permissionArray) - 1;
                                $permissionArray[$lI]['access_application'] = true;
                            }
                        }
                        $nUP = true;
                    } else {
                        $nUP = false;
                    }
                    if (!$nUP) {
                        AppPermission::model()->deleteAll(
                            'app_id=:app_id AND type=:type ',
                            array(
                                ':app_id' => $id,
                                ':type' => 'user',
                            )
                        );     
                    }
                    if (!empty($uESAL)) {
                        AppPermission::model()->deleteAll(
                            'app_id=:app_id AND type=:type '.
                            'AND target_id NOT IN('.
                            implode(",", $uESAL).')',
                            array(
                                ':app_id' => $id,
                                ':type' => 'user',
                            )
                        );
                    }
                    $gESAL = array();
                    $nGP = true;
                    if (isset($_POST['AppPermission']['group_edit_script'])  
                        && !empty($_POST['AppPermission']['group_edit_script'])
                    ) {
                        if (isset($_POST['AppPermission']['group_edit_script'])
                            && !empty($_POST['AppPermission']['group_edit_script'])
                        ) {
                            $gES = $_POST['AppPermission']['group_edit_script'];
                            foreach ($gES as $key => $value) {
                                array_push(
                                    $permissionArray, array(
                                    'app_id' => $id,
                                    'type' => 'group',
                                    'target_id' => $value,
                                    'edit_script' => true,
                                    'access_application' => false
                                    )
                                );
                                array_push($gESAL, $value);
                            }
                        }
                        $nGP = true;
                    } else {
                        $nGP = false;
                    }
                    if (isset($_POST['AppPermission']['group_access'])
                        && !empty($_POST['AppPermission']['group_access'])
                    ) {
                        $gAS = $_POST['AppPermission']['group_access'];
                        foreach ($gAS as $key => $value) {
                            if (!in_array($value, $gESAL)) {
                                array_push($gESAL, $value);
                                array_push(
                                    $permissionArray, array(
                                        'app_id' => $id,
                                        'type' => 'group',
                                        'target_id' => $value,
                                        'access_application' => true,
                                        'edit_script' => false
                                    )
                                );
                            } else {
                                $lI = count($permissionArray) - 1;
                                $permissionArray[$lI]['access_application'] = true;
                            }
                        }
                        $nGP = true;
                    } else {
                        $nGP = false;
                    }
                    if (!$nGP) {
                        AppPermission::model()->deleteAll(
                            'app_id=:app_id AND type=:type ',
                            array(
                                ':app_id' => $id,
                                ':type' => 'group',
                            )
                        );
                    }
                    if (!empty($gESAL)) {
                        AppPermission::model()->deleteAll(
                            'app_id=:app_id AND type=:type '.
                            'AND target_id NOT IN('.
                            implode(",", $gESAL).')',
                            array(
                                ':app_id' => $id,
                                ':type' => 'group',
                            )
                        );
                    }
                } else {
                    AppPermission::model()->deleteAll(
                        'app_id=:app_id',
                        array(':app_id' => $id)
                    );
                }
                $_POST['Application']['script'] = base64_encode(
                    htmlspecialchars($_POST['Application']['script'])
                );
                $attributes = str_replace(
                    "\r\n\t", "", $_POST['Application']['attributes']
                );
                $attributes = str_replace("\r\n", "", $attributes);
                $attributes = str_replace("\n\t", "", $attributes);
                $_POST['Application']['attributes'] = str_replace(
                    "\n", "", $attributes
                );
                if (isset($_POST['Application']['file_upload']) 
                    && $_POST['Application']['file_upload']
                ) {
                    $model->file_upload = true;
                } else {
                    $model->file_upload = false;
                }
                if (isset($_POST['Application']['include_files']) 
                    && $_POST['Application']['include_files']
                ) {
                    $model->include_files = true;
                } else {
                    $model->include_files = false;
                }
                $app = Application::model()->findAll(
                    'name=:name', array(":name" => $_POST['Application']['name'])
                );
                if (!$app || $app != null) {
                    $data = array(
                        'script' => $_POST['Application']['script'],
                        'attributes' => $_POST['Application']['attributes'],
                        'name' => $_POST['Application']['name'],
                        'details' => $_POST['Application']['details'],
                        'user_access' => !empty(
                            $_POST['Application']['user_access']
                        ) ? json_encode(
                            $_POST['Application']['user_access']
                        ) : null,
                        'group_access' => !empty(
                            $_POST['Application']['group_access']
                        ) ? json_encode(
                            $_POST['Application']['group_access']
                        ) : null,
                        'user_script_edit' => !empty(
                            $_POST['Application']['user_script_edit']
                        ) ? json_encode(
                            $_POST['Application']['user_script_edit']
                        ) : null,
                        'group_script_edit' => !empty(
                            $_POST['Application']['group_script_edit']
                        ) ? json_encode(
                            $_POST['Application']['group_script_edit']
                        ) : null,
                        'file_upload' => $model->file_upload,
                        'include_files' => $model->include_files
                    );
                    if ($model->updateAll($data, 'id=:id', array(':id' => $id))) {
                        if (!empty($permissionArray)) {
                            foreach ($permissionArray as $key => $value) {
                                $prePerm = AppPermission::model()->find(
                                    'app_id=:app_id AND type=:type' .
                                        ' AND target_id=:target_id', array(
                                    ':app_id' => $value['app_id'],
                                    ':type' => $value['type'],
                                    ':target_id' => $value['target_id']
                                        )
                                );
                                $data = $value;
                                if ($prePerm) {
                                    echo $prePerm->id . "<br />";
                                    $data['id'] = $prePerm->id;
                                    $permission = $prePerm;
                                } else {
                                    $permission = new AppPermission();
                                }
                                $permission->attributes = $data;
                                $permission->save();
                            }
                        }
                        Yii::app()->user->setFlash(
                            'success', 
                            "<strong>{$_POST['Application']['name']}</strong> " .
                                "Application details updated successfully."
                        );
                        $this->redirect(array('view', 'id' => $model->id));
                    } else {
                        array_push(
                            $flashes, "<strong> Info </strong> " .
                                "Unable to save the application details."
                        );
                    }
                } else {
                    array_push(
                        $flashes, "<strong> Info </strong> " .
                            "Application name already used. Please use another."
                    );
                }
            }
        }
        $this->render(
            'update', array(
            'model' => $model,
            'flashes' => $flashes,
            'users' => REQUIRED::readSystemUsers(),
            'groups' => UserGroup::model()->findAll(),
            'permissions' => AppPermission::model()->findAll('app_id=' . $id),
            'app_groups' => AppGroups::model()->findAll('app_id=' . $id)
                )
        );
    }

    //--------------------------------------------------------------------------
    /**
     * Deletes a particular model.
     * If deletion is successful, the browser will be redirected to the 'admin' page.
     *
     * @param integer $id the ID of the model to be deleted
     *
     * @return null
     */
    public function actionDelete($id) 
    {
        $data = $this->loadModel($id);
        Job::model()->deleteAll(
            'app_id=:app_id', array(
            ':app_id' => (int) $id
            )
        );
        if ($data->delete()) {
            Yii::app()->user->setFlash(
                "success", "Application ({$data->name}) " .
                    "uninstalled successfully."
            );
        } else {
            Yii::app()->user->setFlash(
                "error", "Unable to remove application ({$data->name})." .
                    "May be some jobs are still referenced with this application."
            );
             $this->redirect(array('index'));
        }
        // if AJAX request (triggered by deletion via 
        //admin grid view), we should not redirect the browser
        if (!isset($_GET['ajax']) || $state) {
            $this->redirect(
                isset(
                    $_POST['returnUrl']
                ) ? $_POST['returnUrl'] : array('index')
            );
        }
    }

    //--------------------------------------------------------------------------
    /**
     * Lists all models.
     *
     * @return null
     */
    public function actionIndex() 
    {
        $applicationDetails = Application::model()->findAll(
            array('order' => 'name')
        );
        $this->render(
            'index', array(
            'applicationDetails' => $applicationDetails,
            'flashes' => array()
                )
        );
    }

    //--------------------------------------------------------------------------
    /**
     * Manages all models.
     *
     * @return null
     */
    public function actionAdmin() 
    {
        $model = new Application('search');
        $model->unsetAttributes();  // clear any default values
        if (isset($_GET['Application'])) {
            $model->attributes = $_GET['Application'];
        }

        $this->render(
            'admin', array(
            'model' => $model,
                )
        );
    }

    //--------------------------------------------------------------------------
    /**
     * Returns the data model based on the primary key given in the GET variable.
     * If the data model is not found, an HTTP exception will be raised.
     *
     * @param integer $id the ID of the model to be loaded
     *
     * @return Application the loaded model
     *
     * @throws CHttpException
     */
    public function loadModel($id) 
    {
        $model = Application::model()->findByPk($id);
        if ($model === null) {
            throw new CHttpException(404, 'The requested page does not exist.');
        }
        return $model;
    }

    //--------------------------------------------------------------------------
    /**
     * Performs the AJAX validation.
     *
     * @param Application $model the model to be validated
     *
     * @return null
     */
    protected function performAjaxValidation($model) 
    {
        if (isset($_POST['ajax']) && $_POST['ajax'] === 'template-form') {
            echo CActiveForm::validate($model);
            Yii::app()->end();
        }
    }

    //--------------------------------------------------------------------------
    /**
     * Assigns attributes and details to the script template to generate 
     * required job submission script
     * 
     * @param String $script     Script template to generate
     * @param String $attributes Form template to render
     * @param String $char       Replace Character 
     *
     * @return TRUE if succefully assigns otherwise FALSE
     */
    public function assignAttributes($script, $attributes, $char = "@") 
    {
        $flag = true;
        $attributes = json_decode($attributes, true);
        $attrNames = array();
        if (is_array($attributes)) {
            foreach ($attributes as $attr) {
                array_push($attrNames, $attr['name']);
            }
            preg_match_all(
                "/\{$char}\{$char}[a-zA-z0-9]+\{$char}\{$char}/", 
                $script, 
                $scriptAttrNames
            );
            $scriptAttrNames = ((is_array(
                $scriptAttrNames && isset($scriptAttrNames[0])
            )) ? $scriptAttrNames[0] : array());
            if (is_array($scriptAttrNames)) {
                foreach ($scriptAttrNames as $attr) {
                    $attr = trim($attr, "@");
                    if (!in_array($attr, $attrNames)) {
                        $flag = false;
                        break;
                    }
                }
            }
        }
        return $flag;
    }

    //--------------------------------------------------------------------------
    /**
     * Generates HTML using JSON template of application
     * 
     * @param integer $id Specifies the application
     *
     * @return null
     */
    public function actionBuildform($id = null) 
    {
        $this->layout = '//layouts/column1';
        $params = array();
        if (!is_null($id)) {
            $applicationDetails = Application::model()->find('id=' . $id);
            $formObj = json_decode($applicationDetails->attributes);
            $params['formObj'] = $formObj;
        }
        $this->render('generateForm', $params);
    }

    //-------------------------------------------------------------------------
    /**
     * Display(s) the script with editor
     *
     * @param integer $id Specifies the application
     *
     * @return null
     */
    public function actionFormEditor($id = null) 
    {
        $this->layout = '//layouts/column1';
        $params = array();
        if (!is_null($id)) {
            $application = Application::model()->findByPk($id);
            if ($application) {
                $params['name'] = $application->name;
                $params['attributes'] = $application->attributes;
                $params['application'] = $id;
            }
        }
        $this->render('formEditor', $params);
    }

    //-----------------------------------------------------------------------
    /**
     * Generates file template of application to install anywhere
     *
     * @param integer $id Specifies the application
     *
     * @return null
     */
    public function actionExport($id = null) 
    {
        $this->layout = '//layouts/column1';
        if (!is_null($id)) {
            $application = Application::model()->findByPk($id);
            if ($application) {
                $appArray = array();
                $appArray['name'] = $application->name;
                $appArray['script'] = $application->script;
                $appArray['attributes'] = base64_encode($application->attributes);
                $appArray['details'] = base64_encode($application->details);
                $xml = new SimpleXMLElement('<application/>');
                $appArray = array_flip($appArray);
                array_walk_recursive($appArray, array($xml, 'addChild'));
                header('Content-type: text/xml');
                header(
                    'Content-Disposition: attachment; filename="' . 
                    $application->name . '.xml"'
                );
                $dom = dom_import_simplexml($xml)->ownerDocument;
                $dom->formatOutput = true;
                echo $dom->saveXML();
            } else {
                throw new Exception("No such application available", '404');
            }
        } else {
            throw new Exception("No such application available", '404');
        }
    }

    //-----------------------------------------------------------------------
    /**
     * Generates file template of application to install anywhere
     *
     * @return null
     */
    public function actionImport() 
    {
        $responseArray = array();
        $responseArray['status'] = INVALID_REQUEST;
        $responseArray['message'] = "Inavlid Request.";
        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            libxml_use_internal_errors(true);
            $xml = simplexml_load_file($_FILES["fileLocation"]["tmp_name"]);
            if ($xml === false) {
                $errorString = "";
                foreach (libxml_get_errors() as $error) {
                    $errorString .= $error->message.".";
                }
                Yii::app()->user->setFlash('error', $errorString);
            } else {
                $fileObj = json_decode(json_encode($xml), true);
                $applicationObj = new Application();
                $attributes = base64_decode($fileObj['attributes']); 
                $fileObj['attributes'] = str_replace(
                    "\r\n\t", "", 
                    $fileObj['attributes']
                );
                $attributes = str_replace("\r\n", "", $attributes);
                $attributes = str_replace("\n\t", "", $attributes);
                $fileObj['attributes'] = str_replace("\n", "", $attributes);
                $fileObj['details'] = base64_decode($fileObj['details']);
                $applicationObj->name = $fileObj['name'];
                $applicationObj->attributes = $fileObj['attributes'];
                $applicationObj->details = $fileObj['details'];
                $applicationObj->script = $fileObj['script'];
                $app = Application::model()->find(
                    'name=:name', array(":name" => $applicationObj->name)
                );
                if (!is_object($app)) {
                    if ($applicationObj->save()) {
                        $responseArray['status'] = SUCCESS;
                        $responseArray['message'] = "Application".
                        " installed successfully.";
                        Yii::app()->user->setFlash(
                            'success', 
                            "Application({$applicationObj->name}) ".
                            "Installed successfully."
                        );
                    } else {
                        $responseArray['status'] = DATABASE_ERROR;
                        $responseArray['message'] = "Database Error.".
                        " Application not installed.";
                        Yii::app()->user->setFlash(
                            "error",
                            $responseArray['message']
                        );
                    }
                } else {
                    $responseArray['status'] = UNKNOWN_ERROR;
                    $responseArray['message'] = "Application Name".
                    "({$applicationObj->name}) already used.".
                    "Please use another.";
                    Yii::app()->user->setFlash(
                        "error",
                        $responseArray['message']
                    );
                }
            }
        }
        $this->redirect(array('index'));
    }

}

// End of the ApplicationController Class
// End of the ApllicationController.php File
