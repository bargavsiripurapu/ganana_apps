<?php

/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  TORQUE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * AppGroup Controller manages the application groups
 *
 * @category Job_Submission_Portal
 * @package  TORQUE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

class AppGroupsController extends Controller
{

    /**
     * Var string the default layout for the views.
     * Defaults to '//layouts/column2', meaning
     * using two-column layout. See 'protected/views/layouts/column2.php'.
     */
    public $layout = '//layouts/column2';

    /**
     * Controller FILTERS
     *
     * @return array action filters
     */
    public function filters()
    {
        return array(
            'accessControl', // perform access control for CRUD operations
            'postOnly + delete', // we only allow deletion via POST request
        );
    }

    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     *
     * @return array access control rules
     */
    public function accessRules()
    {
        return array(
            array('allow',
                'actions' => array('index', 'view','create', 'update', 'delete'),
                'users' => array('admin', 'root'),
            ),
        );
    }

    /**
     * Displays a particular model.
     *
     * @param integer $id the ID of the model to be displayed
     *
     * @return null
     */
    public function actionView($id)
    {
        $model = $this->loadModel($id);
        if (is_null($model) || empty($model)) {
            throw new CHttpException(404, 'The requested page does not exist.');
        }
        $this->render(
            'view',
            array(
            'model' => $this->loadModel($id),
            )
        );
    }

    /**
     * Creates a new model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     *
     * @return null
     */
    public function actionCreate()
    {


        // Uncomment the following line if AJAX validation is needed
        // $this->performAjaxValidation($model);

        if (isset($_POST['AppGroups'])) {
            $model = $this->multipleInsert($_POST['AppGroups']);
            $this->redirect(array('view', 'id' => $model));
        }
        $applicationObj = Application::model()->findAll(array('order' => 'name'));
        $model = new AppGroups();
        $this->render(
            'create',
            array(
            'model' => $model,
            'applications' => $applicationObj
            )
        );
    }

    /**
     * Updates a particular model.
     * If update is successful, the browser will be redirected to the 'view' page.
     *
     * @param integer $id the ID of the model to be updated
     *
     * @return null
     */
    public function actionUpdate($id)
    {
        $model = $this->loadModel($id);

        // Uncomment the following line if AJAX validation is needed
        // $this->performAjaxValidation($model);

        if (isset($_POST['AppGroups'])) {
            if ($this->multipleUpdate($_POST['AppGroups'])) {
                $this->redirect(
                    array(
                       'view',
                        'id' => $_POST['AppGroups']['group_id']
                    )
                );
            }
        }
        $applicationObj = Application::model()->findAll(array('order' => 'name'));
        $params = array(
            'model' => $model,
            'applications' => $applicationObj,
            'group_id' => $id
        );
        $appGroup = array();
        foreach ($model as $key => $group) {
            array_push($appGroup, $group->app_id);
        }
        $params['appGroup'] = $appGroup;
        $this->render('update', $params);
    }

    /**
     * Deletes a particular model.
     * If deletion is successful, the browser will be redirected to the 'admin' page.
     *
     * @param integer $id the ID of the model to be deleted
     *
     * @return null
     */
    public function actionDelete($id)
    {
        // AppGroups::model()->find('group_id='.$id);
        if (AppGroups::model()->deleteAll(
            'group_id=:group_id',
            array(':group_id' => $id)
        )
        ) {
            Yii::app()->user->setFlash(
                'error',
                'Requested group deleted successfully.'
            );
        }
        // if AJAX request (triggered by deletion via admin grid view),
        // we should not redirect the browser
        if (!isset($_GET['ajax'])) {
            $this->redirect(
                isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin')
            );
        }
    }

    /**
     * Lists all models.
     *
     * @return null
     */
    public function actionIndex()
    {
        $model = AppGroups::model()->findAll(array('order' => 'group_id'));
        $outPutArray = array();
        foreach ($model as $key => $value) {
            $temp = array();
            $app = Application::model()->find('id=' . $value->app_id);
            $temp['id'] = $value->group_id;
            if (count($outPutArray) > 0
                && $outPutArray[count($outPutArray) - 1]['name'] == $value->name
            ) {
                $temp = $outPutArray[count($outPutArray) - 1];
            } else {
                $temp['name'] = $value->name;
            }
            if (isset($temp['app_id']) && !empty($temp['app_id'])) {
                $temp['app_id'] .= "," . $app->name;
                $outPutArray[count($outPutArray) - 1] = $temp;
            } else {
                $temp['app_id'] = $app->name;
                array_push($outPutArray, $temp);
            }
        }
        $this->render(
            'index',
            array(
            'model' => $outPutArray,
            )
        );
    }

    /**
     * Manages all models.
     *
     * @return null
     */
    public function actionAdmin()
    {
        $model = new AppGroups('search');
        $model->unsetAttributes();  // clear any default values
        if (isset($_GET['AppGroups'])) {
            $model->attributes = $_GET['AppGroups'];
        }

        $this->render(
            'admin',
            array(
            'model' => $model,
            )
        );
    }

    /**
     * Returns the data model based on the primary key given in the GET variable.
     * If the data model is not found, an HTTP exception will be raised.
     *
     * @param integer $id the ID of the model to be loaded
     *
     * @return AppGroups the loaded model
     *
     * @throws CHttpException
     */
    public function loadModel($id)
    {
        $model = null;
        if (!is_null($id) && !empty($id)) {
            $model = AppGroups::model()->findAll('group_id=' . $id);
        }
        if ($model === null) {
            throw new CHttpException(404, 'The requested page does not exist.');
        }
        // $model = AppGroups::model()->findAll(array('order' => 'name'),
        //'name=:name', array(':name' => $model->name));
        return $model;
    }

    /**
     * Performs the AJAX validation.
     *
     * @param AppGroups $model the model to be validated
     *
     * @return null
     */
    protected function performAjaxValidation($model)
    {
        if (isset($_POST['ajax']) && $_POST['ajax'] === 'app-groups-form') {
            echo CActiveForm::validate($model);
            Yii::app()->end();
        }
    }

    //--------------------------------------------------------------------------
    /**
     * Inserts multiple records(groups) at once
     *
     * @param Object $postObj to insert the multiple data
     *
     * @return true if inserts otherwise false
     */
    public function multipleInsert($postObj)
    {
        $groupTransaction = new AppGroups;
        $transaction = $groupTransaction->dbConnection->beginTransaction();
        $criteria = new CDbCriteria;
        $criteria->select = 'max(group_id) AS group_id';
        $criteria->group = 'group_id';
        $row = $groupTransaction->model()->find($criteria);
        $nextGroup = 1;
        if (count($row) > 0) {
            $nextGroup = (int) $row['group_id'] + 1;
        }
        $postObj['group_id'] = $nextGroup;
        $applicationIDs = $postObj['app_id'];
        try {
            foreach ($applicationIDs as $key => $appId) {
                $model = new AppGroups;
                $postObj['app_id'] = $appId;
                $model->attributes = $postObj;
                $model->save();
                unset($model);
            }
            $transaction->commit();
        } catch (Exception $e) {
            $transaction->rollback();
            return false;
        }
        return $nextGroup;
    }

    //--------------------------------------------------------------------------
    /**
     * Updates multiple records at once
     *
     * @param Object $postObj to update multiple data
     *
     * @return true if updates otherwise false
     */
    public function multipleUpdate($postObj)
    {
        $tempPostObj = $postObj;
        unset($tempPostObj['id']);
        $groupTransaction = new AppGroups;
        $transaction = $groupTransaction->dbConnection->beginTransaction();
        $appIds = $postObj['app_id'];
        $criteria = new CDbCriteria;
        try {
            $appIdsStr = '';
            foreach ($appIds as $key => $appId) {
                $model = $groupTransaction->model()->find(
                    'group_id=:group_id AND app_id=:app_id',
                    array(
                    ':group_id' => $postObj['group_id'],
                    ':app_id' => $appId
                    )
                );
                $appIdsStr .= $appId . ',';
                if (!$model) {
                    $tempPostObj['app_id'] = $appId;
                    $groupTransaction->attributes = $tempPostObj;
                    $groupTransaction->save();
                }
            }
            // $criteria->addNotInCondition('app_id', $appIds);

            $criteria->condition = "group_id=" .
            $postObj['group_id'] .
            (($appIdsStr != '') ?
            " AND app_id not in("
            . trim($appIdsStr, ",")
            . ")" : "");

            $groupTransaction->model()->deleteAll($criteria);
            $transaction->commit();
        } catch (Exception $e) {
            echo '<pre>';
            print_r($appIds);
            print_r($e);
            $transaction->rollback();
            exit;
            return false;
        }
        return true;
    }
}
// End of the AppGroupsController Class
// End of the AppGroupsController.php file
