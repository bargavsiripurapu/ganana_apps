<?php
/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * GjspUtils is helper class for Ganana Job Submission Portal Module Application
 * it consists multiple helper functions
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class GjspUtils
{
    /**
     * Read GJSPSLURM configurations from db and load into application variable
     *
     * @return NULL
     */
    public static function loadConfig() 
    {
        if (!isset(Yii::app()->params->GHPCS)) {
            GUtils::loadConfig();
        }
        $records = Config::model()->findAll();
        $config = array();
        foreach ($records as $record) {
            $config[$record->param] = $record->value;
        }
        if (!isset($config['submitHost'])) {
            $config['submitHost'] = Yii::app()->params->GHPCS['masterserverip'];
        }
        Yii::app()->params['GJSPSLURM'] = $config;
        $apps = Application::model()->count();
        $lic = LicenseParam::model()->find('id=1');
        if (!isset(Yii::app()->params->license)) {
            Yii::app()->params['license'] = self::checkKey(
                $lic->licence,
                $lic->publickey
            );
        }
        $license = Yii::app()->params->license;
        $loggedUser = Yii::app()->user->name;
        $config['users'] = array();
        $users = GjspUser::model()->findAll();
        if ($users && !empty($users)) {
            foreach ($users as $key => $user) {
                array_push($config['users'], $user->username); 
            }
        }
        $users = count($users);
        if (!in_array($loggedUser, array('root', 'admin'))) {
            if ($users < $license['User-Count'] 
                && !in_array($loggedUser, $config['users'])
            ) {
                $addUser = new GjspUser();
                $addUser->username = $loggedUser;
                if ($addUser->save()) {
                    array_push($config['users'], $loggedUser);
                } else {
                    Yii::app()->user->setFlash(
                        "error",
                        "System is unable to provide license to you. ".
                        "Please contact your administrator for the same."
                    );
                    Yii::app()->controller->redirect("/");
                }
            } else if (!in_array($loggedUser, $config['users'])) {
                Yii::app()->user->setFlash(
                    "error",
                    "You are not authorised to access the application. ".
                    "License count is exhausted, please contact your administrator."
                );
                Yii::app()->controller->redirect("/");
            }
        }
        Yii::app()->params['GJSPSLURM'] = $config;
        if (($apps > $license['Application-Count']) 
            || ($users > $license['User-Count'])
        ) {
            if (in_array($loggedUser, array('admin','root'))) {
                $message = 'License count mismatched with system. '.
                    'Please check your applications and users.';
                Yii::app()->user->setFlash("error", $message);
                if (Yii::app()->controller->id != 'licence') {
                    Yii::app()->controller->redirect(
                        array('licence/index')
                    ); 
                }
            } else {
                $message = 'Portal might be corrupted. '.
                    'Please contact your administrator.';
                Yii::app()->user->setFlash("error", $message);
                Yii::app()->controller->redirect(array('/'));
            }
            
        }
        self::environmentCheck();
    }

    /**
     * Set a GJSPSLURM configuration in db
     * 
     * @param string $param Parameter
     * @param string $value Value
     *
     * @return NULL 
     */
    public static function setConfig($param, $value) 
    {
        $record = Config::model()->find('param=:param', array(':param' => $param));
        if ($record !== null) {
            $record->value = $value;
            $record->save();
        } else {
            $record = new Config();
            $record->param = $param;
            $record->value = $value;
            $record->save();
        }
        self::loadConfig();
    }

    /**
     * Checks the scheduler Commands are loaded or not
     *
     * @return NULL
     */
    public static function environmentCheck()
    {
        $schedulerLoaded = Yii::app()->cache->get("schedulerLoaded");
        if ($schedulerLoaded === false) {
            $host = Yii::app()->params->GJSPSLURM['submitHost'];
            $user = GhpcsUser::model()->find("username='admin'");
            $userId = $user->id;
            $sshHost = new GSsh(array('host' => $host));
            $commands = include __DIR__."/../config/scheduler.php";
            if (!empty($commands) && is_array($commands)) {
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    foreach ($commands as $command) {
                        $response = REQUIRED::lastCommandExitStatus(
                            $sshHost->cmd('command -v '.$command.';echo $?')
                        );
                        if (!$response['status']) {
                            throw new CHttpException(
                                500, 
                                'Could not find the scedular command(s).'.
                                ' Please configure the enviroment properly.'
                            );
                        }
                    }
                    $sshHost->disconnect();
                    Yii::app()->cache->set("schedulerLoaded", true, 1800);
                } else {
                    throw new CHttpException(
                        500, 
                        'Unable to access the job submission ".
"host due to authentication problem.'
                    );
                }
            } else {
                throw new CHttpException(
                    500, 'Please load the list of scheduler commands.'
                );
            }
        }
        return; 
    }
    
    /**
     * Validate licence file
     *
     * @param string $license    licence content
     * @param string $public_key public key for validating licence.
     *
     * @return array licence components
     */
    function checkKey($license, $public_key)
    {
        $productName = 'GJSP Slurm';
        $lic_unreg = array(
            'Product-Name' => $productName,
            'Product-Version' => '2.x',
            'Registered-To' => 'Unregistered',
            'Issued-On' => '25-Aug-2015',
            'Expired-On' => '25-Aug-2099',
            'Application-Count' => '100',
            'Portal-ID' => 'Unregistered',
            'License-Key' => 'Unregistered',
            'User-Count' => '100',
        );
        $lic_component = GUtils::parseLicString($license);
        if ($lic_component === false) {
            return $lic_unreg;
        }
        // Check all keys are available
        $lic_reg = array();
        foreach ($lic_unreg as $key => $val) {
            if (!array_key_exists($key, $lic_component)) {
                return $lic_unreg;
            }
            $lic_reg[$key] = $lic_component[$key];
        }
        if ($productName !== $lic_component['Product-Name']) {
            return $lic_unreg;
        }
        $iv = 'Product-Name = ' . $lic_component['Product-Name'] . "\n" .
              'Product-Version = ' . $lic_component['Product-Version'] . "\n" .
              'Registered-To = ' . $lic_component['Registered-To'] . "\n" .
              'Issued-On = ' . $lic_component['Issued-On'] . "\n" .
              'Expired-On = ' . $lic_component['Expired-On'] . "\n" .
              'Application-Count = ' .$lic_component['Application-Count'] . "\n" .
              'User-Count = ' . $lic_component['User-Count'] . "\n" .
              'Portal-ID = ' . $lic_component['Portal-ID'];
        $signature = base64_decode($lic_component['License-Key']);
        $pubkeyid = openssl_get_publickey($public_key);
        $ok = openssl_verify($iv, $signature, $pubkeyid);
        openssl_free_key($pubkeyid);
        if ($ok === 1) {
            $portalId = Yii::app()->params->GJSPSLURM['portalid'];
            if (($portalId === $lic_component['Portal-ID'])
                || (substr($lic_component['Portal-ID'], 0, 4) === 'TEMP')
            ) {
                return $lic_reg;
            } else {
                return $lic_unreg;
            }
        } else {
            return $lic_unreg;
        }
    }
}
