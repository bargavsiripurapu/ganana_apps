<?php
/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * Loads all the required functions
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class REQUIRED
{

    /**
     * Converts Object To Array recursively
     * 
     * @param Object $obj Object
     *
     * @return Array
     */
    public static function objectToArray($obj) 
    {
        if (is_object($obj)) {
            $obj = (array) $obj;
        }
        if (is_array($obj)) {
            $new = array();
            foreach ($obj as $key => $val) {
                $new[$key] = self::objectToArray($val);
            }
        } else {
            $new = $obj;
        }
        return $new;
    }

    /**
     * Creates Table for XDetailView is alternate and improved version of 
     * CDetailView
     * 
     * @param Array  $data    Array of data
     * @param String $padding Padding to be given
     *
     * @return string
     */
    public static function createXDetailView($data, $padding = null) 
    {
        $tableStr = "";
        $count = 1;
        if (!is_null($data) && $data != "") {
            foreach ($data as $k => $v) {
                $tableTempStr = "";
                if (is_string($v)) {
                    $temp = explode(',', $v);
                    if (count($temp) > 1) {
                        $tempArr = array();
                        foreach ($temp as $t) {
                            $t = explode('=', $t);
                            if (isset($t[1])) {
                                $tempArr[$t[0]] = $t[1];
                            } else {
                                array_push($tempArr, $t[0]);
                            }
                        }
                        $v = $tempArr;
                    }
                    unset($temp);
                }
                if (is_array($v)) {
                    $v = self::createXDetailView($v);
                }
                if ((!is_array($v) && !is_object($v)) || $v == "" || $v == null) {
                    if (!is_integer($k)) {
                        $tableTempStr .= '<td class="th">' . 
                        ucwords(str_replace("_", " ", $k)) . "</td>" . "\n";
                    }
                    $isValueNull = (is_null($v) && 
                    $v !== 0 && $v != "") ? true : false;
                    $tableTempStr .= '<td>' . 
                    ($isValueNull ? 
                    '<span class="label label-important">Not Set</span>' : 
                    $v) . "</td>" . "\n";
                    $tableStr .= "<tr class=\"" . 
                    ($count % 2 == 0 ? "even" : 
                    "odd") . "\">\n" . $tableTempStr . "</tr>" . "\n";
                    $count++;
                }
            }
        }
        $tableStr = '<table ' . 
        (($padding !== null ) ? 'style="padding:' . $padding . ';" ' : 
        '') . ' class="table table-striped table-bordered table-hover">' . 
        "\n" . '<tbody>' . "\n" . $tableStr 
        . '</tbody>' . "\n" . '</table>' . "\n";
        return $tableStr;
    }

    /**
     * Replaces the key of array
     * 
     * @param Array  $array     Data of the array
     * @param String $sourceKey key need to change
     * @param String $targetKey new key
     *
     * @return NULL
     */
    public static function replaceKey(&$array, $sourceKey, $targetKey) 
    {
        $keys = array_keys($array);
        $index = array_search($sourceKey, $keys);
        if ($index !== false) {
            $keys[$index] = $targetKey;
            $array = array_combine($keys, $array);
        }
        // return $array;
    }
    /**
     * Sends Curl request
     * 
     * @param String $requestUrl Request URL
     *
     * @return String NULL        
     */ 
    public static function sendCurlRequest($requestUrl) 
    {
        // echo Yii::app()->createAbsoluteUrl('/g_jspge/' . $requestUrl);exit;
        // create curl resource
        //exit;
        $ch = curl_init();
        // set url
        curl_setopt(
            $ch, CURLOPT_URL, 
            Yii::app()->createAbsoluteUrl(
                '/g_jspge/' . 
                $requestUrl
            )
        );
        // return the transfer as a string
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // $output contains the output string
        $output = curl_exec($ch);
        // close curl resource to free up system resources
        curl_close($ch);
        echo Yii::app()->createAbsoluteUrl('/g_jspge/' . $requestUrl);
        //echo $output;exit;
        return $output;
    }
    /**
     * Returns Last Command Exit Status
     *
     * @param String $response Response Text to evealuate
     * 
     * @return Array $responseObj Evaluated response
     */ 
    public static function lastCommandExitStatus($response) 
    {
        $responseObj = array();
        $responseObj['status'] = false;
        if (empty($response) || is_null($response)) {
            return $responseObj;
        }
        $responseArr = explode("\n", $response);
        if (empty($responseArr) || is_null($responseArr)) {
            return $responseObj;
        }
        if ($responseArr[count($responseArr) - 1] == "") {
            unset($responseArr[count($responseArr) - 1]);
            $responseArr = array_filter($responseArr);
        }
        if (trim($responseArr[count($responseArr) - 1]) == "0") {
            unset($responseArr[count($responseArr) - 1]);
            $responseArr = array_filter($responseArr);
            if (count($responseArr) > 0) {
                $responseObj['message'] = str_replace(
                    "\r", 
                    "", implode("\n", $responseArr)
                );
            }
            $responseObj['status'] = true;
        } else {
            unset($responseArr[count($responseArr) - 1]);
            $responseArr = array_filter($responseArr);
            if (count($responseArr) > 0) {
                $responseObj['message'] = str_replace(
                    "\r", 
                    "", implode("\n", $responseArr)
                );
            }
            $responseObj['status'] = false;
        }
        return $responseObj;
    }
    /**
     * Converts string to binary
     * 
     * @param String $str String to be converted to Binary
     *
     * @return Integer $number Evaluated Number
     */
    public static function stringToBinary($str) 
    {
        $number = (int) $str;
        $measurement = substr($str, strlen("" . $number));
        switch ($measurement) {
        case "kb":
        case "kB":
        case "Kb":
        case "KB":
            return $number * 1024;
                break;
        case "mb":
        case "mB":
        case "Mb":
        case "MB":
            return $number * pow(1024, 2);
                break;
        case "gb":
        case "gB":
        case "Gb":
        case "GB":
            return $number * pow(1024, 3);
                break;
        case "tb":
        case "tB":
        case "Tb":
        case "TB":
            return $number * pow(1024, 4);
                break;
        case "pb":
        case "pB":
        case "Pb":
        case "PB":
            return $number * pow(1024, 5);
                break;
        case "eb":
        case "eB":
        case "Eb":
        case "EB":
            return $number * pow(1024, 6);
                break;
        case "zb":
        case "zB":
        case "Zb":
        case "ZB":
            return $number * pow(1024, 7);
                break;
        case "yb":
        case "yB":
        case "Yb":
        case "YB":
            return $number * pow(1024, 8);
                break;
        default:
            return $number;
                break;
        }
    }
    /**
     * Converts from Binary to String
     * 
     * @param Integer $number Number to be evalauated
     * 
     * @return String evaluated number
     */
    public static function binaryToString($number) 
    {
        $kb = 1000;
        $mb = $kb * 1000;
        $gb = $mb * 1000;
        $tb = $gb * 1000;
        $pb = $tb * 1000;
        $eb = $pb * 1000;
        $yb = $eb * 1000;
        $zb = $yb * 1000;
        switch ($number) {
        case ($number >= $kb && $number < $mb):
            return number_format(($number / 1024), 2) . "KB";
                break;
        case ($number >= $mb && $number < $gb):
            return number_format(($number / pow(1024, 2)), 2) . "MB";
                break;
        case ($number >= $gb && $number < $tb):
            return number_format(($number / pow(1024, 3)), 2) . "GB";
                break;
        case ($number >= $tb && $number < $pb):
            return number_format(($number / pow(1024, 4)), 2) . "TB";
                break;
        case ($number >= $pb && $number < $eb):
            return number_format(($number / pow(1024, 5)), 2) . "PB";
                break;
        case ($number >= $eb && $number < $yb):
            return number_format(($number / pow(1024, 6)), 2) . "EB";
                break;
        case ($number >= $yb && $number < $zb):
            return number_format(($number / pow(1024, 7)), 2) . "YB";
                break;
        case ($number >= $zb):
            return number_format(($number / pow(1024, 8)), 2) . "ZB";
                break;
        default :
            return $number . "Bytes";
                break;
        }
    }
    /**
     * Reads the system users
     * 
     * @param Boolean $reload Loads Again
     *
     * @return NULL
     */
    public static function readSystemUsers($reload = false) 
    {
        $usersArray = Yii::app()->cache->get("gjspge_users");
        if ($reload || $usersArray === false) {
            $cmd = 'getent passwd | '.
            'awk -v min=`cat /etc/login.defs | '.
            'grep "UID_MIN" | '.
            'awk -F " " \'{print $2;exit;}\'` -v max=`cat /etc/login.defs | '.
            'grep "UID_MAX" | '.
            'awk -F " " \'{print $2;exit;}\'` -F ":" \''.
            '{if($3>=min && $3<=max) print '.
            '"{\"name\":\""$1"\",\"uid\":\""$3"\"}"}\' | '.
            'sed \':a;N;$!ba;s/\n/,/g\' | '.
            'awk -F " " \'{print "["$1"]"}\';';
            $host = Yii::app()->params->GHPCS['masterserverip'];
            $user = GhpcsUser::model()->find("username='admin'");
            $userId = $user->id;
            $sshHost = new GSsh(array('host' => $host));
            $errorFlag = false;
            if ($sshHost->getConnected() && $sshHost->authenticateAuto($userId)) {
                $response = REQUIRED::lastCommandExitStatus(
                    $sshHost->cmd($cmd . 'echo $?')
                );
                $sshHost->disconnect();
                if (isset($response['status'])  
                    && $response['status']  
                    && isset($response['message'])
                ) {
                    $userJson = $response['message'];
                    try {
                        $usersArray = json_decode($userJson, true);
                        Yii::app()->cache->set("gjspge_users", $usersArray, 300);
                        return $usersArray;
                    } catch (Exception $e) {
                        throw new Exception("Invalid JSON Format");
                    }
                }
            }
            return array();
        }
        return $usersArray;
    }

    //--------------------------------------------------------------------------
    /**
     * Returns the system user id based on username
     *
     * @param String $userName User name of the system
     *
     * @return Integer
     */
    public static function getUserId($userName = null) 
    {
        if (is_null($userName)) {
            $userName = Yii::app()->user->name;
        }
        $systemUsers = REQUIRED::readSystemUsers();
        if (!empty($systemUsers) && !is_null($systemUsers)) {
            foreach ($systemUsers as $key => $userObj) {
                if ($userObj['name'] == $userName) {
                    return $userObj['uid'];
                }
                continue;
            }
        }
        return 1;
    }

    //--------------------------------------------------------------------------
    /**
     * Checks weather the user has permission to edit the application script
     *
     * @param Integer $appId  Application Identifier
     * @param Integer $userId User Identifier
     * @param String  $type   Permission type
     *
     * @return boolean
     */
    public static function hasAccess($appId, $userId, $type)
    {
        if ($userId == 1) {
            return false;
        }
        $allUserAccess = true;
        $allUserPermissions = AppPermission::model()->findAll(
            'app_id=:app_id AND type=:type '.
            'AND '.$type.'=:aa',
            array(
                ':app_id' => $appId,
                ':type' => 'user',
                ':aa' => true
            )
        );
        if (!empty($allUserPermissions)) {
            $allUserAccess = false;
        }
        $userAccess = true;
        $userPermissions = AppPermission::model()->find(
            'app_id=:app_id AND type=:type '.
            'AND target_id=:target_id '.
            'AND '.$type.'=:aa',
            array(
                ':app_id' => $appId,
                ':type' => 'user',
                ':target_id' => $userId,
                ':aa' => true
            )
        );
        if (!$userPermissions) {
            $userAccess = false;
        }
        $allGroupAccess = true;
        $allGroupPermissions = AppPermission::model()->findAll(
            'app_id=:app_id AND type=:type '.
                'AND '.$type.'=:aa ',
            array(
                    ':app_id' => $appId,
                    ':type' => 'group',
                    ':aa' => true
                )
        );
        if (!empty($allGroupPermissions)) {
            $allGroupAccess = false;
        } 
        $groupAccess = false;
        $userGroups = GroupUser::model()->findAll('user_id=' . $userId);
        if (!empty($userGroups)) {
            $groupList = array();
            foreach ($userGroups as $key => $groupObj) {
                array_push($groupList, $groupObj->group_id);
            }
            $groupPermissions = AppPermission::model()->findAll(
                'app_id=:app_id AND type=:type '.
                'AND '.$type.'=:aa ' .
                'AND target_id IN('.implode(",", $groupList).')',
                array(
                    ':app_id' => $appId,
                    ':type' => 'group',
                    ':aa' => true
                )
            );
            if (!empty($groupPermissions)) {
                $groupAccess = true;
            }
        }
        // if ($allUserAccess && $allGroupAccess) {
        //     return true;
        // }
        if ($userAccess) {
            return true;
        } 
        if ($groupAccess) {
            return true;
        }
        return false;
    } 
}
