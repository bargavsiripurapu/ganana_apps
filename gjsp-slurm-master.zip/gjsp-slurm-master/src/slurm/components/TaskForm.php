<?php
/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * TaskForm is custom validator class which manually validates the Task Form 
 * dynamically(means validating variables which are specified in database, based 
 * on their rules specified.)
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class TaskForm
{
    // @codingStandardsIgnoreStart
    public $_properties = array();
    private $rulesArr = array();
    private $labelArr = array();
    // @codingStandardsIgnoreEnd
    /**
     * Loads the constructor
     *
     * @param Array $attributes 
     * 
     * @return NULL
     */    
    public function __construct($attributes = array()) 
    {
        try {
            $props = array();
            foreach ($attributes as $k => $attr) {
                $props[$k] = $attr['name'];
                $name = $attr['name'];
                $this->_properties[$attr['name']] = "";
                $rules = $attr['rules'];
                $this->labelArr[$name] = $attr['label'];
                if ($rules['required']) {
                    array_push($this->rulesArr, array($attr['name'], 'required'));
                    array_push($this->rulesArr, array($attr['name'], 'nameval'));
                }
                if ($rules['lengths']) {
                    $subProps = array($attr['name'], 'length');
                    if (isset($rules['lengths']['max'])) {
                        $subProps['max'] = $rules['lengths']['max'];
                    }
                    if (isset($rules['lengths']['min'])) {
                        $subProps['min'] = $rules['lengths']['min'];
                    }
                    if (isset($rules['lengths']['is'])) {
                        $subProps['is'] = $rules['lengths']['is'];
                    }
                    if (isset($rules['lengths']['tooShort'])) {
                        $subProps['tooShort'] = $rules['lengths']['tooShort'];
                    }
                    if (isset($rules['lengths']['tooLong'])) {
                        $subProps['tooLong'] = $rules['lengths']['tooLong'];
                    }
                    array_push($this->rulesArr, $subProps);
                }
                if ($rules['numerical']) {
                    $subProps = array($attr['name'], 'numerical');
                    if (isset($rules['numerical']['max'])) {
                        $subProps['max'] = $rules['numerical']['max'];
                    }
                    if (isset($rules['numerical']['min'])) {
                        $subProps['min'] = $rules['numerical']['min'];
                    }
                    if (isset($rules['numerical']['integerOnly'])) {
                        $t = $rules['numerical']['integerOnly'];
                        $subProps['integerOnly'] = $t;
                    }
                    if (isset($rules['numerical']['allowEmpty'])) {
                        $subProps['allowEmpty'] = $rules['numerical']['allowEmpty'];
                    }
                    if (isset($rules['numerical']['tooBig'])) {
                        $subProps['tooBig'] = $rules['numerical']['tooBig'];
                    }
                    if (isset($rules['numerical']['tooSmall'])) {
                        $subProps['tooSmall'] = $rules['numerical']['tooSmall'];
                    }
                    array_push($this->rulesArr, $subProps);
                }
                if ($rules['email']) {
                    $subProps = array($attr['name'], 'email');
                    if (isset($rules['email']['pattern'])) {
                        $subProps['pattern'] = $rules['email']['pattern'];
                    }
                    array_push($this->rulesArr, $subProps);
                }
                if ($rules['match']) {
                    $subProps = array($attr['name'], 'match');
                    if (isset($rules['match']['not'])) {
                        $subProps['not'] = $rules['match']['not'];
                    }
                    if (isset($rules['match']['pattern'])) {
                        $subProps['pattern'] = $rules['match']['pattern'];
                    }
                    array_push($this->rulesArr, $subProps);
                }
                if ($rules['in']) {
                    $subProps = array($attr['name'], 'in');
                    if (isset($rules['in']['not'])) {
                        $subProps['not'] = $rules['in']['not'];
                    }
                    if (isset($rules['in']['range'])) {
                        $subProps['range'] = $rules['in']['range'];
                    }
                    array_push($this->rulesArr, $subProps);
                }
            }
        } catch (Exception $e) {
            print_r($e);
        }
    }
    /**
     * Validation function to validate the data
     * 
     * @param Array $data Data of array
     *
     * @return NULL
     */
    public function validate($data) 
    {
        $flag = true;
        foreach ($data as $k => $d) {
            $this->_properties[$k] = $d;
        }
        array_push($this->rulesArr, array('start_time_scheduler','greatertimenow'));
        $this->labelArr['start_time_scheduler'] = "Start Time";
        array_push($this->rulesArr, array('mail_alert_scheduler','email'));
        $this->labelArr['mail_alert_scheduler'] = "Mail Alert";
        foreach ($this->rulesArr as $index => $rule) {
            $varData = $this->_properties[$rule[0]];
            switch ($rule[1]) {
            case "greatertimenow": 
                if (isset($varData) && !empty($varData)) {
                    $dateTime = new DateTime($varData);
                    if ($dateTime->diff(new DateTime("now"))->format('%R') == '+') {
                        $flag = false;
                        Yii::app()->user->setFlash(
                            "error_required{$index}",
                            "<strong> Invalid Schedule Start Date and Time.</strong>"
                        );
                    }
                }
                break;
            case "required":
                if (isset($varData) && empty($varData)) {
                    $flag = false;
                    Yii::app()->user->setFlash(
                        "error_required{$index}", 
                        "<strong>{$this->labelArr[$rule[0]]}".
                        "</strong> should not be blank."
                    );
                }
                break;
            case "nameval":
                if (isset($varData) && preg_match('/\s/', $varData)) {
                    $flag = false;
                    Yii::app()->user->setFlash(
                        "error_required{$index}",
                        "<strong>{$this->labelArr[$rule[0]]}".
                        "</strong> should not contain space."
                    );
                }
                break;
            case "length":
                if (isset($rule['max'])  
                    && $rule['max']  
                    && strlen($varData) > $rule['max']
                ) {
                    $flag = false;
                    $message = "<strong>{$this->labelArr[$rule[0]]}</strong> ".
                    "should not be more than {$rule['max']} characters.";
                    if (isset($rule['tooLong']) && $rule['tooLong']) {
                        $message = $rule['tooLong'];
                    }
                    Yii::app()->user->setFlash("error_length{$index}", $message);
                }
                if (isset($rule['min'])  
                    && $rule['min']  
                    && strlen($varData) < $rule['min']
                ) {
                    $flag = false;
                    $message = "<strong>{$this->labelArr[$rule[0]]}</strong> ".
                    "should be more than {$rule['min']} characters.";
                    if (isset($rule['tooShort']) && $rule['tooShort']) {
                        $message = $rule['tooShort'];
                    }
                    Yii::app()->user->setFlash("error_length{$index}", $message);
                }
                if (isset($rule['is'])  
                    && $rule['is']  
                    && strlen($varData) !== $rule['is']
                ) {
                    $flag = false;
                    Yii::app()->user->setFlash(
                        "error_length{$index}", 
                        "<strong>{$this->labelArr[$rule[0]]}</strong> ".
                        "should be {$rule['min']} characters only."
                    );
                }
                break;
            case "numerical":
                if (isset($varData)  
                    && ((isset($rule['integerOnly'])  
                    && $rule['integerOnly']  
                    && (int) $varData === $varData)  
                    || (int) $varData === $varData  
                    || (float) $varData === $varData  
                    || (double) $varData === $varData)
                ) {
                    $flag = false;
                    Yii::app()->user->setFlash(
                        "error_numerical{$index}", 
                        "<strong>{$this->labelArr[$rule[0]]}</strong>".
                        " should be a numerical"
                    );
                }
                break;
            if (isset($varData)  
                && isset($rule['allowEmpty'])  
                && (!$rule['allowEmpty']  
                && !empty($varData))
            ) {
                $flag = false;
                Yii::app()->user->setFlash(
                    "error_numerical{$index}", 
                    "<strong>{$this->labelArr[$rule[0]]}</strong>".
                    " should be a non-empty value."
                );
            }
            if (isset($varData)  
                && isset($rule['max'])  
                && $rule['max']  
                && ($varData > $rule['max'])
            ) {
                $flag = false;
                $message = "<strong>{$this->labelArr[$rule[0]]}</strong>".
                " should be not more than {$rule['max']}";
                if (isset($rule['tooBig'])  
                    && $rule['tooBig']
                ) {
                    $message = $rule['tooBig'];
                }
                Yii::app()->user->setFlash(
                    "error_numerical{$index}", 
                    $message
                );
            }
            if (isset($varData)  
                && isset($rule['min'])  
                && $rule['min']  
                && ($varData < $rule['min'])
            ) {
                $flag = false;
                $message = "<strong>{$this->labelArr[$rule[0]]}</strong>".
                " should be not less than {$rule['min']}";
                if (isset($rule['tooSmall']) && $rule['tooSmall']) {
                    $message = $rule['tooSmall'];
                }
                Yii::app()->user->setFlash(
                    "error_numerical{$index}", $message
                );
            }
                    break;
            case "in":
                if (isset($varData)) {
                    if (isset($rule['range'])  
                        && $rule['range']  
                        && !in_array($varData, $rule['range'])
                    ) {
                        $flag = false;
                        Yii::app()->user->setFlash(
                            "error_in{$index}", 
                            "<strong>{$this->labelArr[$rule[0]]}</strong> ".
                            "should be in specified range(" . 
                            json_encode($rule['range']) . ")"
                        );
                    }
                    if (isset($rule['not'])  
                        && $rule['not']  
                        && !in_array($varData, $rule['not'])
                    ) {
                        $flag = false;
                        Yii::app()->user->setFlash(
                            "error_in{$index}", 
                            "<strong>{$this->labelArr[$rule[0]]}</strong>".
                            " should not be in specified range(" . 
                            json_encode($rule['not']) . ")"
                        );
                    }
                }
            case "email":
                if (isset($varData)  
                    && $varData  
                    && !filter_var($varData, FILTER_VALIDATE_EMAIL)
                ) {
                    $flag = false;
                    Yii::app()->user->setFlash(
                        "error_email{$index}", 
                        "<strong>{$this->labelArr[$rule[0]]}</strong> ".
                        "is an invalid email."
                    );
                } else {
                    $userObj = GhpcsUser::model()->find(
                        'username=:username', 
                        array(':username' => Yii::app()->user->name)
                    );
                    if (!is_null($userObj->email) 
                        && !empty($userObj->email) 
                        && $userObj->email !== $varData
                    ) {
                        Yii::app()->user->setFlash(
                            "error_email{$index}",
                            "<strong>{$this->labelArr[$rule[0]]}</strong>".
                             "is not matched with user profile email."
                        );
                    }
                }
                break;
            case "match":
                if (isset($varData)  
                    && isset($rule['pattern'])  
                    && $rule['pattern']  
                    && !preg_match($rule['pattern'], $varData)
                ) {
                    $flag = false;
                    Yii::app()->user->setFlash(
                        "error_email{$index}", 
                        "<strong>{$this->labelArr[$rule[0]]}</strong> ".
                        "is an invalid format."
                    );
                }
                if (isset($varData)  
                    && isset($rule['not'])  
                    && $rule['not']  
                    && preg_match($rule['not'], $varData)
                ) {
                    $flag = false;
                    Yii::app()->user->setFlash(
                        "error_email{$index}", 
                        "<strong>{$this->labelArr[$rule[0]]}</strong> ".
                        "is an invalid format."
                    );
                }
                break;
            default:
                $flag = ($flag) ? true : false;
                break;
            }
        }
        return $flag;
    }
    /**
     * Returns label names which are specified in 
     * 
     * @return NULL
     */
    public function labels() 
    {
        return $this->labelArr;
    }

}

// End of the TaskForm Class
// End of the TaskForm.php file
