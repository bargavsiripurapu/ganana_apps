<?php
/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * Creates the required menu for portal
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class TopNavMenu extends CComponent
{
    private $_menuAlerts = array();
    private $_addonMenus = array();
    /**
     * Loads the controller
     *
     * @param Array $menuAlerts Menu alerts if any
     *
     * @return NULL
     */  
    public function __construct($menuAlerts = array()) 
    {
        $this->_menuAlerts = $menuAlerts;
        $this->_addonMenus = self::_getAddons();
    }

    /**
     * Append addon menus in GHPCS Top Navigation
     *
     * @return array Addon Menu items
     */
    private function _getAddons() 
    {
        $addonmenu = array();
        $path = dirname(__FILE__) . '/../../../addon_menu/'
                . Yii::app()->controller->module->id;
        if (is_dir($path)) {
            $addons = scandir($path);
            foreach ($addons as $addon) {
                $file = $path . '/' . $addon;
                if (!is_dir($file) && file_exists($file)) {
                    $content = include $file;
                    if (is_array($content)) {
                        foreach ($content as $value) {
                            array_push($addonmenu, $value);
                        }
                    }
                }
            }
        }
        return $addonmenu;
    }
    /**
     * Returns the items from application, app groups
     *
     * @return Array
     */
    public function getItems() 
    {
        $controllerId = Yii::app()->controller->id;
        $actionId = Yii::app()->controller->action->id;
        $alertCount = count($this->_menuAlerts);
        $addonsCount = count($this->_addonMenus);
        $appDetails = Application::model()->findAll(array('order' => "name"));
        $applications = array();
        $appGroups = AppGroups::model()->findAll();
        $appGrouped = array();
        $tempGroupedApps = array();
        try {
            if (isset($appGroups) && is_array($appGroups)) {
                foreach ($appGroups as $key => $appGroup) {
                    if (!isset($appGrouped[$appGroup->name])) {
                        $appGrouped[$appGroup->name] = array();
                    }
                    array_push(
                        $appGrouped[$appGroup->name], 
                        Application::model()->findByPk($appGroup->app_id)
                    );
                    array_push($tempGroupedApps, $appGroup->app_id);
                }
                $appGrouped['Unknown'] = array();
                foreach ($appDetails as $key => $app) {
                    if (!in_array($app->id, $tempGroupedApps)) {
                        array_push($appGrouped['Unknown'], $app);
                    }
                }
            }
        } catch (Exception $e) {
            
        }
        $userId = REQUIRED::getUserId();
        $applicationTabs = array();
        $tempLinks = array();
        foreach ($appGrouped as $key => $appGroup) {
            $tempLink = array();
            foreach ($appGroup as $index => $app) {
                $link = array(
                    'label' => '<i class="fa fa-cube"></i> ' . $app->name,
                    'url' => Yii::app()->createUrl(
                        'g_slurm/task/index', 
                        array('id' => $app->id)
                    ),
                    'visible' => REQUIRED::hasAccess(
                        $app->id, $userId, 'access_application'
                    ),
                    'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                );
                if ($key !== 'Unknown') {
                    array_push($tempLink, $link);
                } else {
                    array_push($tempLinks, $link);
                }
            }
            if ($key !== 'Unknown') {
                array_push(
                    $tempLinks, array(
                    'label' => '<i class="fa fa-cubes"></i> ' . $key,
                    'url' => "#",
                    'itemOptions' => array(
                    'class' => 'dropdown dropdown-gsubmenu', 
                    'tabindex' => "-1"),
                    'linkOptions' => array(
                    'class' => 'dropdown-toggle', 
                    'data-toggle' => "dropdown"),
                    'items' => $tempLink
                    )
                );
            }
        }
        $applications = array(
            'label' => '<i class="fa fa-cubes"></i> Applications',
            'url' => '',
            'visible' => Yii::app()->user->name != 'root' && 
        !Yii::app()->user->checkAccess('manager') && 
        !Yii::app()->user->isGuest,
            'active' => $controllerId == 'file',
            'itemOptions' => array(
        'class' => 'dropdown', 
        'tabindex' => "-1"),
            'linkOptions' => array(
            'class' => 'dropdown-toggle', 
            'data-toggle' => "dropdown"),
            'items' => $tempLinks
        );
        return array(
            array('label' => '<i class="fa fa-dashboard"></i> Dashboard',
                'url' => array('dashboard/index'),
                'active' => $controllerId == 'dashboard' && $actionId == 'index',
            ),
            array('label' => '<i class="fa fa-tasks"></i> Monitoring',
                'url' => array(''),
                'active' => $controllerId == 'task' && in_array(
                    $actionId, array(
                    'running', 'pending', 'completed', 'holded')
                ),
                        'items' => array(
                        array(
                        'label' => '<i class="fa fa-circle-o-notch">'.
                '</i> Pending Jobs',
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                        'url' => array('task/pending')
                        ),
                        array(
                        'label' => '<i class="fa fa-spinner fa-pulse fa-fw">'.
                        '</i>Running Jobs',
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                        'url' => array('task/running')
                        ),
                        array(
                        'label' => '<i class="fa fa-spinner"></i> Holded Jos',
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                        'url' => array('task/holded')
                        ),
                        array(
                        'label' => '<i class="fa fa-list"></i> Completed Jobs',
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                        'url' => array('task/completed'),
                        ),),
                        'itemOptions' => array(
                        'class' => 'dropdown', 
                        'tabindex' => "-1"),
                        'linkOptions' => array(
                        'class' => 'dropdown-toggle', 
                        'data-toggle' => "dropdown"),
            ),
            $applications,
            array('label' => '<i class="fa fa-gears"></i> Manage',
                'url' => '',
                'active' => in_array(
                    $controllerId, array(
                    'node', 
                    'queue', 
                    'application',
                    'appGroups',
                    'settings',
                    'serverparams'
                    )
                ),
                'visible' => Yii::app()->user->checkAccess('manager'),
                'itemOptions' => array('class' => 'dropdown', 'tabindex' => "-1"),
                'linkOptions' => array(
                'class' => 'dropdown-toggle', 
                'data-toggle' => "dropdown"),
                'items' => array(
                    array('label' => '<i class="fa fa-server"></i> Nodes',
                        'url' => array('node/index'),
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                    ),
                    array('label' => '<i class="fa fa-ellipsis-h"></i> Queues',
                        'url' => array('queue/index'),
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                    ),
                    array('label' => '<i class="fa fa-cubes"></i> Applications',
                        'url' => array('application/index'),
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                    ),
                    array(
                        'label' => '<i class="fa fa-object-group"></i> App Groups',
                        'url' => array('appGroups/index'),
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                    ),
                    /*
                    array('label' => '<i class="fa fa-sliders"></i> 
                        Server Parameters',
                        'url' => array('serverparams/index'),
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                    ),*/
                    array(
                        'label' => '<i class="fa fa-gear"></i>'.' Settings',
                        'url' => array('settings/index'),
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}'),
                 )
                // 'active'=>$controllerId=='help',
            ),
            array(
            'label' => '<i class="icon-bell"></i> Alerts'.
            ' <span class="badge badge-important">' . 
            $alertCount . 
            '<i class="fa fa-sort-desc"></i>',                
            'url' => '#',
                'itemOptions' => array('class' => 'dropdown', 'tabindex' => "-1"),
                'linkOptions' => array(
            'class' => 'dropdown-toggle', 
            'data-toggle' => "dropdown"),
                'items' => $this->_menuAlerts,
                'visible' => $alertCount && !Yii::app()->user->isGuest,
            ),
            array(
                'label' => '<i class="fa fa-external-link-square"></i> Add-ons '
                . '<i class="fa fa-sort-desc"></i>',
                'url' => '#',
                'itemOptions' => array('class' => 'dropdown', 'tabindex' => '-1'),
                'linkOptions' => array(
                    'class' => 'dropdown-toggle',
                    'data-toggle' => 'dropdown'
                ),
                'items' => $this->_addonMenus,
                'visible' => $addonsCount && !Yii::app()->user->isGuest,
            ),
            array('label' => '<i class="fa fa-book"></i> Help',
                'url' => 'help/index',
                'itemOptions' => array('class' => 'dropdown', 'tabindex' => "-1"),
                'linkOptions' => array(
            'class' => 'dropdown-toggle', 
            'data-toggle' => "dropdown"),
                'items' => array(
                    array(
                'label' => '<i class="fa fa-question-circle"></i>'.
                ' Portal Help',
                        'url' => array('help/index'),
                    ),
                    array('label' => '<i class="fa fa-newspaper-o"></i>'.
                    ' About',
                        'url' => array('help/about'),
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                    ),
                ),
                'active' => $controllerId == 'help',
            ),
            array('label' => '<i class="fa fa-sign-in"></i> Login',
                'url' => array('/home/login'),
                'visible' => Yii::app()->user->isGuest,
            ),
            array(
            'label' => '<i class="fa fa-sign-out"></i> Logout (' . 
            Yii::app()->user->name . ')',
                'url' => array('/home/logout'),
                'visible' => !Yii::app()->user->isGuest,
            //'template'=>'| {menu}',
            ),
        );
    }

}
