<?php
 /**
  * CmModule File is the entry point to a module
  *
  * PHP version 5.3
  *
  * @category  Ganana
  * @package   GJSPSLURM
  * @author    Santosh Kumar Gupta <santosh.gupta@locuz.com>
  * @author    Rajesh Mayara <rajesh.mayara@locuz.com>
  * @copyright 2012 - 2016 Locuz Enterprise Solutions Ltd.
  * @license   Locuz Proprietary Licence
  * @link      http://www.locuz.com
  */
// @codingStandardsIgnoreStart
require_once('constants.php');
// @codingStandardsIgnoreEnd 
 /**
  * CmModule Class File
  *
  * All module configurations,hooks and initialisations are implemented.
  *
  * @method    init
  * @method    beforeControllerAction
  * @method    getAssetsUrl
  * @method    registerAssets
  * @category  Module
  * @package   GJSPSLURM
  * @author    Santosh Kumar Gupta <santosh.gupta@locuz.com>
  * @author    Rajesh Mayara <rajesh.mayara@locuz.com>
  * @copyright 2012 - 2016 Locuz Enterprise Solutions Ltd.
  * @license   Locuz Proprietary Licence
  * @link      http://www.locuz.com
  */

class SlurmModule extends CWebModule
{
 
    public $appName;
    public $db;
    private $_assetsUrl;
    private $_excludeAssests = array('webmate');
 
    /**
      * It's an entry point for module and also initialises the module components.
      *
      * @return array
      */
    public function init()
    {
        // you may place code here to customize the module or the application
        Yii::app()->setComponents(
            array(
            'errorHandler' => array(
            'errorAction' => $this->id . '/dashboard/error'))
        );
 
        // set GHPCS Module App configurations
        $params = include dirname(__FILE__) . '/config/main.php';
        foreach ($params as $property => $value) {
            $this->$property = $value;
        }
        $appName = Yii::app()->cache->get('GJSPSLURM_appname');
        if ($appName === false) {
            $iniPath = dirname(__FILE__) . '/app.ini';
            $ini = parse_ini_file($iniPath, true);
            $appName = (string) $ini['app']['fname'];
            Yii::app()->cache->set('GJSPSLURM_appname', $appName, 24 * 3600);
        }
        $this->appName = $appName;
        // import the module-level models and components
        $this->setImport(
            array(
                $this->id . '.models.*',
                $this->id . '.components.*',
            )
        );
        $this->getAssetsUrl();
    }
 
    /**
      * It's an hook for any controller action of this module.
      *
      * @param string $controller is the name of controller.
      * @param string $action     is the action.
      *
      * @return boolean
      */
    public function beforeControllerAction($controller, $action)
    {
        if (parent::beforeControllerAction($controller, $action)) {
            // this method is called before any module controller action is performed
            // you may place customized code here
            Yii::app()->controller->homeLink
                = array('/' . $this->id);
            Yii::app()->controller->homeLinkText
                = '<i class="fa fa-tachometer"></i> Dashboard';
            // load all GJSPSLURM configuration from db.
            GjspUtils::loadConfig();
            if (Yii::app()->params['GJSPSLURM']['agreement'] != 'Accepted'
                && (Yii::app()->controller->id !== 'dashboard')
            ) {
                Yii::app()->controller->redirect(array('dashboard/index'));
            }
            if (!in_array(Yii::app()->controller->id, $this->_excludeAssests)) {
                $this->registerAssets();
            }
            return true;
        } else {
            return false;
        }
    }
 
    /**
      * It's an hook for any controller action of this module.
      *
      * @return string
      */
    public function getAssetsUrl()
    {
        if (!isset($this->_assetsUrl)) {
            $this->_assetsUrl
                = Yii::app()
                ->getAssetManager()
                ->publish(Yii::getPathOfAlias($this->id . '.assets'));
        }
        return $this->_assetsUrl;
    }
 
    /**
      * Function registerAssets will register the css and js files
      *
      * @param string  @ $assettype   asset to register i.e css,js.
      * @param boolean @ $register    register or not.
      * @param string  @ $registerAll recursively register all assets.
      * @param string  @ $regfile     register single asset file. *
      *
      * @return boolean
      */
    public function registerAssets(
        $assettype = 'all',
        $register = true,
        $registerAll = true,
        $regfile = ""
    ) {
        if ($register) {
            $baseDir = $this->basePath . "/assets/";
            switch ($assettype) {
            case 'css':
                if ($registerAll) {
                    $path = $baseDir . 'css/';
                    if (is_dir($path)) {
                        $cssscripts = scandir($path);
                        foreach ($cssscripts as $cssscript) {
                            $file = $path . $cssscript;
                            // Don't use subdirectories (even "." and ".." are dirs)
                            if (!is_dir($file) && file_exists($file)) {
                                if (strpos($file, 'css') !== false) {
                                    $cssfile = $this->_assetsUrl . '/css/'
                                        . $cssscript;
                                    Yii::app()
                                        ->clientScript
                                        ->registerCssFile($cssfile);
                                }
                            }
                        }
                    }
                } else {
                    $file = $this->_assetsUrl . '/css/' . $regfile;
                    if (strpos($file, 'css') !== false) {
                        return Yii::app()->clientScript->registerCssFile($file);
                    }
                }
                break;
            case 'js':
                if ($registerAll) {
                    $path = $baseDir . 'js/';
                    if (is_dir($path)) {
                        $cssscripts = scandir($path);
                        foreach ($cssscripts as $cssscript) {
                            $file = $path . $cssscript;
                            // Don't use subdirectories (even "." and ".." are dirs)
                            if (!is_dir($file) && file_exists($file)) {
                                if (strpos($file, 'js') !== false) {
                                    $cssfile = $this->_assetsUrl . '/js/'
                                        . $cssscript;
                                    Yii::app()
                                        ->clientScript
                                        ->registerScriptFile($cssfile);
                                }
                            }
                        }
                    }
                } else {
                    $file = $this->_assetsUrl . '/js/' . $regfile;
                    if (strpos($file, 'js') !== false) {
                        return Yii::app()->clientScript->registerScriptFile($file);
                    }
                }
                break;
            case 'all':
                if (is_dir($baseDir)) {
                    $assets = scandir($baseDir);
                    foreach ($assets as $subdir) {
                        if ($subdir == 'css') {
                            $path = $baseDir . 'css/';
                            if (is_dir($path)) {
                                $cssscripts = scandir($path);
                                foreach ($cssscripts as $cssscript) {
                                    $file = $path . $cssscript;
                                    if (!is_dir($file) && file_exists($file)) {
                                        if (strpos($file, 'css') !== false) {
                                            $cssfile = $this->_assetsUrl
                                                . '/css/' . $cssscript;
                                            Yii::app()
                                                ->clientScript
                                                ->registerCssFile($cssfile);
                                        }
                                    }
                                }
                            }
                        }
                        if ($subdir == 'js') {
                            $path = $baseDir . 'js/';
                            if (is_dir($path)) {
                                $cssscripts = scandir($path);
                                foreach ($cssscripts as $cssscript) {
                                    $file = $path . $cssscript;
                                    if (!is_dir($file) && file_exists($file)) {
                                        if (strpos($file, 'js') !== false) {
                                            $cssfile = $this->_assetsUrl
                                                . '/js/' . $cssscript;
                                            Yii::app()
                                                ->clientScript
                                                ->registerScriptFile($cssfile);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            default :
                break;
            }
        }
        return true;
    }
}
