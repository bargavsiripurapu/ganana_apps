<?php

/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * HoststateCommand automates the host state info to database
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class HoststateCommand extends CConsoleCommand
{

    /**
     * Starts execution of Accounting Command 
     *
     * @param Array $args Reads arguments from command line if any
     * 
     * @return NULL 
     */
    public function run($args) 
    {
        GUtils::loadConfig();
        $config = Yii::app()->params['GHPCS'];
        $host = $config['controllerip'];
        $url = 'http://' . $host . '/index.php/g_slurm/host/state';
        $commandFileObj = GjspCommandFiles::model()->find(
            'name=:name', array(':name' => 'node_ping_state')
        );
        $host = $config['masterserverip'];
        $user = GhpcsUser::model()->find("username='admin'");
        $userId = $user->id;
        CrawlerController::updateNodeInfo();
        print_r($commandFileObj);die;
        $pingCommand = base64_decode($commandFileObj->content);
        $pingCommand = str_replace("\r", "", $pingCommand);
        $pingCommand = str_replace("@@url@@", $url, $pingCommand);
        $sshHost = new GSsh(array('host' => $host));
        if ($sshHost->getConnected() && $sshHost->authenticateAuto($userId)) {
            $fileName = '/tmp/pingnode.sh';
            if ($sshHost->writeFile($fileName, $pingCommand, 755)) {
                $cmd = 'cd /tmp;qconf -sel | ' .
                        'awk -F " " \'{gsub(" ","",$1);' .
                        'system("sh ' . $fileName . ' "$1" &")}\'';
                var_dump(
                    $sshHost->shellCmd(
                        array(
                        $cmd
                        )
                    )
                );
            }
            $sshHost->disconnect();
        }
    }

}
