<?php

/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * AccountingCommand automates the job accounting info to database
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class AccountingCommand extends CConsoleCommand
{

    /**
     * Starts execution of Accounting Command 
     *
     * @param Array $args Reads arguments from command line if any
     * 
     * @return NULL 
     */
    public function run($args) 
    {
        GUtils::loadConfig();
        $config = Yii::app()->params['GHPCS'];
        $host = $config['masterserverip'];
        $user = GhpcsUser::model()->find("username='admin'");
        $userId = $user->id;
        $sshHost = new GSsh(array('host' => $host));
        $setFlag = true;
        if ($sshHost->getConnected() && $sshHost->authenticateAuto($userId)) {
            $cmd = "c2FjY3QgLS1mb3JtYXQ9Sm9iSUQgLS1ub2hlYWRlciB8IHNlZCAnOmE7TjskIW".
                   "JhO3MvXG4vLC9nJyB8IHNlZCAncy9cc1wrLy9nJyB8IGF3ayAgLUYgIlx0IiAn".
                   "e3ByaW50ICJbIiQwIl0ifSc=";
            $cmd = base64_decode($cmd).';echo $?';
            $response = REQUIRED::lastCommandExitStatus($sshHost->cmd($cmd));
            if ($response['status'] && isset($response['message'])) {
                $allAccJobs = json_decode($response['message']);
                if (count($allAccJobs)>0) {
                    $notAccJobs = array();
                    $jobs = Job::model()->findAll(
                        'is_accounted IS NOT true'
                    );
                    if (!empty($jobs)) {
                        foreach ($jobs as $key => $job) {
                            array_push($notAccJobs, $job->job_id);
                        }
                        $comNotAccJobs = array_intersect($allAccJobs, $notAccJobs);
                        $cmdStr = "";
                        foreach ($comNotAccJobs as $key => $job) {
                            $cmd = base64_decode(
                                "c2FjY3QgLWogQEBqb2JfaWRAQCAtLWZv".
                                "cm1hdD0iQUxMIiAtUCB8IGF3ayAtdiBoZWFkZXI9IiIgLXYgb".
                                "3V0cHV0PSIiIC1GICJ8IiAne2lmKE5SPT0xKXtoZWFkZXI9JD".
                                "A7fWVsc2V7c3BsaXQoaGVhZGVyLHRhaCwifCIpO3NwbGl0KCQ".
                                "wLHRhdiwifCIpO291dHB1dD0ieyI7Zm9yKGkgaW4gdGFoKXtp".
                                "Zih0YXZbaV09PSIiKXt0YXZbaV09Ik5BIjt9O291dHB1dD1vd".
                                "XRwdXQiXCIidGFoW2ldIlwiOlwiInRhdltpXSJcIiwiO307Z3".
                                "N1YigiLCQiLCIiLG91dHB1dCk7b3V0cHV0PW91dHB1dCJ9Ijt".
                                "9O3ByaW50IG91dHB1dH0nIHwgc2VkICcvXiQvZCc7"
                            );
                            $cmdStr .= str_replace("@@job_id@@", $job, $cmd);
                        }
                        $cmdStr .= 'echo $?';
                        $response = REQUIRED::lastCommandExitStatus(
                            $sshHost->cmd($cmdStr)
                        );
                        if ($response['status'] && isset($response['message'])) {
                            $jobs = explode(
                                "\n",
                                str_replace("\r", "", $response['message'])
                            );
                            foreach ($jobs as $key => $job) {
                                $jobObj = json_decode($job, true);
                                $dbJob = Job::model()->find(
                                    'job_id=:job_id',
                                    array(':job_id' => $jobObj['JobID'])
                                );
                                $dbJob->submitted_by = $jobObj['User'];
                                $dbJob->is_accounted = true;
                                $dbJob->is_active = false;
                                $dbJob->last_updated =  date("Y-m-d H:i:s");
                                $dbJob->status = $job;
                                if ($dbJob->save(false)) {
                                    $cmd = base64_encode(
                                        "Y2F0IC92YXIvbG9nL3NsdXJtL2FjY291bnRpbmcg".
                                        "IHwgYXdrIC1GICIgIiAne2lmKCQxPT1AQGpvYl9p".
                                        "ZEBAKXtwcmludCBOUn19JyB8IHNlZCAnOmE7Tjsk".
                                        "IWJhO3MvXG4vLC9nJyB8IGF3ayAtRiAiXHQiICd7".
                                        "cHJpbnQgIlsiJDEiXSJ9Jw=="
                                    ).';echo $?';
                                    $cmd = str_replace(
                                        "@@job_id@@",
                                        $jobObj['JobID'],
                                        $cmd
                                    );
                                    $response = REQUIRED::lastCommandExitStatus(
                                        $sshHost->cmd($cmd)
                                    );
                                    if ($response['status'] 
                                        && isset($response['message'])
                                    ) {
                                        $lines = json_decode(
                                            $response['message'],
                                            true
                                        );
                                        $deleteStr = implode(";", $lines);
                                        $deleteStr = str_replace(
                                            ";",
                                            "d;",
                                            $deleteStr
                                        )."d";
                                        $cmd = "sed -i '{$deleteStr}' ".
                                            "/var/log/slurm/accounting;echo \$?";
                                        $sshHost->cmd($cmd);
                                    }
                                }
                            }
                        }
                    }
                    
                }
            }
            $sshHost->disconnect();
        }
    }
}
?>
