<?php
/**
 * This is the GHPCS Module application configuration.
 *
 * PHP version 5.3
 *
 * @category  Ganana
 * @package   GJSPGE
 * @author    Santosh Kumar Gupta <santosh.gupta@locuz.com>
 * @copyright 2012 - 2016 Locuz Enterprise Solutions Ltd.
 * @license   Locuz Proprietary License
 * @link      http://www.locuz.com
 */

// This is the GHPCS Module application configuration.
return array(
    'defaultController'=>'dashboard',
    // database settings are configured in database.php
    'db'=>include dirname(__FILE__).DIRECTORY_SEPARATOR.'database.php',
);


