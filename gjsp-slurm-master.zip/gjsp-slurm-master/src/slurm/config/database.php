<?php
/**
 * This is the GHPCS Module App database connection configuration.
 *
 * PHP version 5
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

return array(
    'class' => 'CDbConnection',
    'connectionString' => 'pgsql:dbname=gjspslurmdb',
    'emulatePrepare' => false,
    'username' => 'gjspslurm',
    'password' => 'gjspslurm123',
    'charset' => 'utf8',
);
