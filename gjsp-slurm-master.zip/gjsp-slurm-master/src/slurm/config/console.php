<?php
/**
 * This is the configuration for yiic console application.
 * Any writable CConsoleApplication properties can be configured here.
 *
 * PHP version 5
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
return array(
    'basePath' => dirname(__FILE__) . '/../../../ghpcs/protected',
    'runtimePath' => dirname(__FILE__) . '/../../../ghpcs/runtime',
    'name' => 'Ganana Job Submission Portal Console Application',
    // autoloading model and component classes
    'import' => array(
        'application.models.*',
        'application.apps.slurm.controllers.*',
        'application.components.*',
        'application.apps.slurm.models.*',
        'application.apps.slurm.components.*',
    ),
    // preloading 'log' component
    'preload' => array('log'),
    // application components
    'components' => array(
        // database settings are configured in database.php
        'db' => include dirname(__FILE__) . '/database.php',
        'log' => array(
            'class' => 'CLogRouter',
            'routes' => array(
                array(
                    'class' => 'CFileLogRoute',
                    'levels' => 'error, warning',
                ),
            ),
        ),
        'cache' => array(
            'class' => 'system.caching.CFileCache',
            'keyPrefix' => 'hostState',
        ),
        // uncomment the following to enable URLs in path-format
        'urlManager' => array(
            'class' => 'yii.web.UrlManager',
            'scriptUrl' => 'https://192.168.100.100'
        ),
    ),
    'commandMap' => array(
        'migrate' => array(
            'class' => 'system.cli.commands.MigrateCommand',
            'migrationPath' => 'application.apps.slurm.migrations',
            'connectionID' => 'db',
        ),
        //'accounting' => array(
        //'class' => 'application.apps.slurm.commands.AccountingCommand',
        //            'connectionID' => 'db',
        //        )
    ),
    'commandPath' => dirname(__FILE__) . '/../commands',
);
