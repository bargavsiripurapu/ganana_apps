# Contribute to Ganana Job Submission Portal

Any Locuz authorized contributor can contribute to Ganana Job Submission Portal
(GJSP). We would like to make contributing as easy as possible. This guide
details how to contribute to GJSP in a way that is efficient for everyone.

## Contributor license agreement

This project is bound to Locuz proprietary license agreement between Locuz and
every individual contributor (developer or tester). By submitting code, issues
or any reports as an individual you agree to the license agreement.

## Security vulnerability disclosure

Please report suspected security vulnerabilities in private to the project
owner or project manager.
Please do **NOT** create publicly viewable issues for suspected security
vulnerabilities.

## Closing policy for issues and merge requests

Issues and merge requests not in line with the guidelines listed in this
document may be closed without notice.

Issues and merge requests should be documented and should explain the purpose
of it.

## Issue tracker

Found any problem in GJSP, need to fix something or want some new feature to be
added in GJSP, you should start with creating a new issue in the project issue
tracker.

When submitting an issue please conform to the issue submission guidelines
listed below.

If it happens that you know the solution to an existing bug, please first
open the issue in order to keep track of it and then open the relevant merge
request that potentially fixes it.

### Feature proposals

To create a feature proposal for GJSP, open an issue on the project issue
tracker.

In order to help track the feature proposals, we have created a
`feature proposal` label.

Please keep feature proposals as small and simple as possible, complex ones
might be edited to make them small and simple.

For any major changes in the design, it can be helpful to create a mockup first.
If you want to create something yourself, consider opening an issue first to
discuss whether it is interesting to include this in GJSP.

### Issue tracker guidelines

Search the issue tracker for similar entries before submitting your own, there's
a good chance somebody else had the same issue or feature proposal. Show your
support with an award emoji and/or join the discussion.

Please submit bugs using the following template in the issue description area.
The text in the parenthesis is there to help you with what to include. Omit it
when submitting the actual issue. You can copy-paste it and then edit as you
see fit.

```
## Summary

(Summarize your issue in one sentence - what goes wrong, what did you expect to
happen)

## Steps to reproduce

(How one can reproduce the issue - this is very important)

## Expected behavior

(What you should see instead)

## Relevant logs and/or screenshots

(Paste any relevant logs - please use code blocks (```) to format console output,
logs, and code as it's very hard to read otherwise.)

## Output of checks

## Possible fixes

(If you can, link to the line of code that might be responsible for the problem)

```

### Issue weight

Issue weight allows us to get an idea of the amount of work required to solve
one or multiple issues. This makes it possible to schedule work more accurately.

You are encouraged to set the weight of any issue. Following the guidelines
below will make it easy to manage this, without unnecessary overhead.

1. Set weight for any issue at the earliest possible convenience
1. If you don't agree with a set weight, discuss with other developers until
   consensus is reached about the weight
1. Issue weights are an abstract measurement of complexity of the issue. Do not
   relate issue weight directly to time.
1. Something that has a weight of 1 (or no weight) is really small and simple.
   Something that is 9 is rewriting a large fundamental part of GJSP, which might
   lead to many hard problems to solve. Changing some text in GJSP is probably 1,
   adding a new feature maybe 4 or 5, big features 7-9.
1. If something is very large, it should probably be split up in multiple
   issues or chunks. You can simply not set the weight of a parent issue and set
   weights to children issues.

## Merge requests

Welcoming merge requests with fixes and improvements to GJSP code,
tests, and/or documentation.

If you want to add a new feature that is not labeled it is best to first create
a feedback issue (if there isn't one already) and leave a comment asking for it
to be merged.

### Merge request guidelines

If you can, please submit a merge request with the fix or improvements. The
workflow to make a merge request is as follows:

1. Fork the project into your personal space on ditlab.locuz.com
1. Create a feature branch
1. Write code
1. Add your changes to the CHANGELOG
1. If you have multiple commits please combine them into one commit by
   squashing them
1. Push the commit(s) to your fork
1. Submit a merge request (MR) to the master branch
1. The MR title should describe the change you want to make
1. The MR description should give a motive for your change and the method you
   used to achieve it
1. Link any relevant issues in the merge request description and leave a comment
   on them with a link back to the MR
1. Be prepared to answer questions and incorporate feedback after your MR
    submission

### Merge request description format

Please submit merge requests using the following template in the merge request
description area. Copy-paste it to retain the markdown format.

```
## What does this MR do?

## Are there points in the code the reviewer needs to double check?

## Why was this MR needed?

## What are the relevant issue numbers?

## Screenshots (if relevant)
```

### Contribution acceptance criteria

1. The change is as small as possible
1. Include proper tests and make all tests pass (unless it contains a test
   exposing a bug in existing code)
1. If you suspect a failing CI build is unrelated to your contribution, you may
   try and restart the failing CI job or ask the project owner/manager to fix
   the aforementioned failing test
1. Your MR initially contains a single commit (please use `git rebase -i` to
   squash commits)
1. Your changes can merge without problems (if not please merge `master`, never
   rebase commits pushed to the remote server)
1. Does not break any existing functionality
1. Fixes one specific issue or implements one specific feature (do not combine
   things, send separate merge requests if needed)
1. Keeps the GJSP code base clean and well structured
1. Changes after submitting the merge request should be in separate commits
   (no squashing). If necessary, you will be asked to squash when the review is
   over, before merging.
1. It conforms to the style guides and the following:
    - If your change touches a line that does not follow the style, modify the
      entire line to follow it. This prevents linting tools from generating
      warnings.
    - Do not touch neighbouring lines. As an exception, automatic mass
      refactoring modifications may leave style non-compliant.

## Style guides

GJSP follow PHP PEAR code style standard. You should check your code by running
`make qa` command in your local repository before pusing it to the remote
repository. Code style is checked using PHP Code Sniffer utility. Make sure you
have installed in your system.
