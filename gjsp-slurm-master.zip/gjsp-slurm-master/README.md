# Ganana Job Submission Portal for Grid Engine
Ganana Job Submission Portal for Grid Engine is a plug-in application for
Ganana HPC Suite Framework. GJSP uses the same authentication mechanism and UI
theme provided by the base Ganana HPC Suite Framework.

## About Ganana Job Submission Portal for Grid Engine

Ganana Job Submission Portal for Grid Engine or GJSPGE is a Ganana HPC Suite
application for submitting, managing and monitoring High Performance Computing
(HPC) jobs in a Grid Engine based batch queuing system.

### History

Ganana Job Submission Portal project was started in mid of 2011 at Locuz
Enterprise Solution Ltd. in Bangalore, India. Initially it was designed as a
standalone application which depended on multiple external libraries and
software stacks.

In mid 2015 Ganana Job Submission Portal joined the Ganana HPC Suite family and
it was redesigned in Ganana HPC Suite Framework.

The first working proof of concept was released in mid 2016 with a complete new
features, user interface and user experience.
