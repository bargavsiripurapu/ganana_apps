#!/bin/bash
app=$1
tar -xvzf cmp-aws.tar.gz
mv gs $app
appc=`echo $app |  sed 's/\([a-z]\)\([a-zA-Z0-9]*\)/\u\1\2/g'`
appUtils=$appc"Utils"
appu=`echo $app | tr '[:lower:]' '[:upper:]'`
mv $app/GsModule.php $app/$appc"Module.php"
mv $app/components/GsUtils.php $app/components/$appUtils".php"
grep -rnw "GsUtils" $app/ | cut -d ':' -f 1 | uniq | awk -v appUtils=$appUtils -F " " '{print("sed -i \"s/GsUtils/"appUtils"/g\" "$1)}' | bash
grep -rn "Ggs" $app/ | cut -d ':' -f 1 | uniq | awk -v app=$app -F " " '{print("sed -i \"s/Ggs/G"app"/g\" "$1)}' | bash
grep -rnw "ggsDb" $app/ | cut -d ':' -f 1 | uniq | awk -v appc=$app"Db" -F " " '{print("sed -i \"s/ggsDb/g"appc"/g\" "$1)}' | bash
grep -rnw "GS" $app/ | cut -d ':' -f 1 | uniq | awk -v appu=$appu -F " " '{print("sed -i \"s/GS/"appu"/g\" "$1)}' | bash
grep -rn "ggs_" $app/ | cut -d ':' -f 1 | uniq | awk -v app=$app -F " " '{print("sed -i \"s/ggs_/g"app"_/g\" "$1)}' | bash
grep -rnw "gs" $app/ | cut -d ':' -f 1 | uniq | awk -v app=$app -F " " 'NR>1{print("sed -i \"s/gs/"app"/g\" "$1)}' | bash
grep -rn "GsModule" $app/ | cut -d ':' -f 1 | uniq | awk -v appc=$appc -F " " '{print("sed -i \"s/GsModule/"appc"Module/g\" "$1)}' | bash
mv $app/app.ini.tmpl $app/app.ini
echo "sed -i 's/shrtname/$app/g' $app/app.ini" | bash
echo "sed -i 's/anumber/$2/g' $app/app.ini" | bash
echo "sed -i 's/aname/$3/g' $app/app.ini" | bash
echo "sed -i 's/ggs/g"$app"/g' $app/config/database.php" | bash
find $app/ -name "Ggs*" | awk -v app=$app -F " " '{old=$1;gsub("Ggs","G"app,$1);print "mv "old" "$1}' | bash
grep -rnw $appu"sh" $app/ | cut -d ':' -f 1 | uniq | awk -v appu=$appu -F " " '{print("sed -i \"s/"appu"sh/GSsh/g\" "$1)}' | bash
mv $app ../
sudo docker exec -t ganana_controller bash -c "/data_vol/webapp/ghpcs_apps/$app/yiic migrate --interactive=0 up"
echo "*/5     *       *       *       *       root    /data_vol/webapp/ghpcs_apps/"$app"/yiic cloud vpc" >> /opt/locuz/ganana/vol/conf/cron/cron.d/"g"$app
echo "*/5     *       *       *       *       root    /data_vol/webapp/ghpcs_apps/"$app"/yiic cloud subnet" >> /opt/locuz/ganana/vol/conf/cron/cron.d/"g"$app
echo "*/5     *       *       *       *       root    /data_vol/webapp/ghpcs_apps/"$app"/yiic cloud instance" >> /opt/locuz/ganana/vol/conf/cron/cron.d/"g"$app
echo "sudo docker exec -t ganana_controller bash -c 'cp -f /data_vol/conf/cron/cron.d/g"$app" /etc/cron.d/'" | bash
sudo docker exec -t ganana_controller bash -c "/etc/init.d/crond restart"
