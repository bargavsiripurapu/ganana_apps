/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *  
 * @author Rajesh Mayara <rajesh.mayara@locuz.com> 
 */
var inputFileCounter = 0;
var BASE_URL = 'https://10.129.150.26:8443';
$(document).ready(
    function () {
        var requestURL = 'queue/getQueueList';
    
        $('body').on(
            'click', '.remove-file', function () {
                $(this).closest('tr').remove();
                return false;
            }
        );
        $('body').on(
            'click', '.add-file', function () {

                var html = '<tr>' +
                '<td>' +
                '<input id="TaskForm_inputFile' + inputFileCounter + '" type="text" size="40" maxlength="256" name="TaskForm[inputFile][]" readonly="raedonly">' +
                '</td>' +
                '<td>' +
                '<button type="button" name="browse" id="browse' + inputFileCounter + '" class="btn btn-info browse" role="button" title="Open directory browser"><span class="fa fa-folder-open"></span></button>' +
                '</td>' +
                '<td>' +
                '<button class="btn btn-danger remove-file" title="Remove"><i class="fa fa-times"></i></button>' +
                '</td>' +
                '</tr>';
                $('#file-item-container').append(html);
                inputFileCounter++;
                return false;
            }
        );
        $('.add-file').trigger('click');
        var closestID = "";

        var loadBrowser = function () {
            $('#filebrowser').fileTree(
                {'script': ['../../../browser/getlist?dironly=0&remote=1'], 'root': '/', 'folderEvent': 'click', 'expandSpeed': 200, 'collapseSpeed': 200, 'multiFolder': false, 'loadMessage': 'Loading File Browser'}, function (f) {
                    $("#filedirpath").val(f);
                    $("#btnselect").show();
                }, function (d) {
                    $("#filedirpath").val(d);
                    $("#btnselect").hide();
                }
            );
        }
        $('body').on(
            'click', '.browse', function () {
                closestID = $(this).closest('tr').find('td:eq(0)').find('input').attr('id');
                loadBrowser();
                $("#filedirpath").val('/');
                $("#filedirdialog").dialog("open");
            }
        );
        $('#filedirdialog').dialog(
            {
                'title': 'Select File',
                'autoOpen': false,
                'modal': true,
                'minWidth': 500,
                'minHeight': 400,
                'buttons': {
                    'Select': {
                        'text': 'Select',
                        'id': 'btnselect',
                        'style': 'display:none;',
                        'click': function () {
                            $('#' + closestID).val($("#filedirpath").val());
                            $('#' + closestID).attr('title', $("#filedirpath").val());
                            $(this).dialog("close");
                        }
                    },
                    'Cancel': {'text': 'Cancel', 'id': 'btncancel', 'click': function () {
                        $(this).dialog("close");
                    }
                    }
                },
                'create': function () {
                    loadBrowser();
                    $("#btnselect").button({icons: {primary: "fa fa-check"}});
                    $("#btncancel").button({icons: {primary: "fa fa-close"}});
                }
            }
        );

    }
);
