<?php
/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * AppAlerts set the available alerts in the application.
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class AppAlerts extends CComponent
{
    private $_alerts=array();
    /**
     * Loads the constructor
     * 
     * @return NULL
     */
    public function __construct()
    {
        // Create badge if master server ip is not set in GHPCS
        if (trim(Yii::app()->params['GHPCS']['masterserverip'])==='') {
            $url=array('/setting/index');
            $alert=GUtils::BADGE(
                'GHPCS Parameter Missing', 
                $url, 0, 'important', 'icon-cog'
            );
            array_push($this->_alerts, $alert);
        }
    }
    /**
     * Return the alerts if any
     * 
     * @return Array alerts
     */
    public function getAlerts()
    {
        return $this->_alerts;
    }
}
