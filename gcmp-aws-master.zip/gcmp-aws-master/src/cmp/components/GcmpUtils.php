<?php
/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * GjspUtils is helper class for Ganana Job Submission Portal Module Application
 * it consists multiple helper functions
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class GcmpUtils
{
    public static $cdbPrefix = "gcmp_";
    public static $shortName = "cmp";
    public static $accountName = "";
    public static $accountNumber = "";
    public static $awsAccessKey = "";
    public static $awsSecretKey = "";
    public static $awsPrefix = "";
    /**
     * Read GCMP configurations from db and load into application variable
     *
     * @return NULL
     */
    public static function loadConfig() 
    {
        if (!isset(Yii::app()->params->GHPCS)) {
            GUtils::loadConfig();
        }
        $records = Config::model()->findAll();
        $config = array();
        foreach ($records as $record) {
            $config[$record->param] = $record->value;
        }
        if (!isset($config['submitHost'])) {
            $config['submitHost'] = Yii::app()->params->GHPCS['masterserverip'];
        }
        $config['users'] = array();
        // $users = GcmpUser::model()->findAll();
        // if ($users && !empty($users)) {
        //     foreach ($users as $key => $user) {
        //         array_push($config['users'], $user->username); 
        //     }
        // }
        Yii::app()->params['GCMP'] = $config;
        self::environmentCheck();
        $sn = GcmpUtils::$shortName;
        $cmd = "SELECT * FROM gcmp_account WHERE short_name = '".$sn."'";
        $model = self::gcmpDb()->createCommand($cmd)->queryAll();
        if (isset($model) && !empty($model)) {
            self::$awsAccessKey = $model[0]['access_key'];
            self::$awsSecretKey = $model[0]['secret_key'];
            self::$accountName = $model[0]['name'];
            self::$accountNumber = $model[0]['account_number'];
            self::$awsPrefix = "AWS_ACCESS_KEY_ID=".self::$awsAccessKey.
            " AWS_SECRET_ACCESS_KEY=".self::$awsSecretKey." ";
        }
        Yii::app()->params['GCMP']=$config;
        if (php_sapi_name() != "cli"  
            && !Yii::app()->request->isAjaxRequest
        ) {
            $portalActivity = GcmpPortalActivity::model()->find("id=1");
            if (empty($portalActivity)) {
                $portalActivity = new GcmpPortalActivity;
                $portalActivity->id = 1;
                $portalActivity->last_loaded = date('Y-m-d H:i:s');
                $portalActivity->save();
            } else {
                $portalActivity->id = 1;
                $portalActivity->last_loaded = date('Y-m-d H:i:s');
                $portalActivity->save();
            }
        }
    }

    /**
     * Set a GCMP configuration in db
     * 
     * @param string $param Parameter
     * @param string $value Value
     *
     * @return NULL 
     */
    public static function setConfig($param, $value) 
    {
        $record = Config::model()->find('param=:param', array(':param' => $param));
        if ($record !== null) {
            $record->value = $value;
            $record->save();
        } else {
            $record = new Config();
            $record->param = $param;
            $record->value = $value;
            $record->save();
        }
        self::loadConfig();
    }

    /**
     * Checks the scheduler Commands are loaded or not
     *
     * @return NULL
     */
    public static function environmentCheck()
    {
        $schedulerLoaded = Yii::app()->cache->get("schedulerLoaded");
        if ($schedulerLoaded === false) {
            $host = Yii::app()->params->GCMP['submitHost'];
            $user = GhpcsUser::model()->find("username='admin'");
            $userId = $user->id;
            $sshHost = new GSsh(array('host' => $host));
            $commands = include __DIR__."/../config/requirements.php";
            if (!empty($commands) && is_array($commands)) {
                if ($sshHost->getConnected()
                    && $sshHost->authenticateAuto($userId)
                ) {
                    foreach ($commands as $command) {
                        $response = REQUIRED::lastCommandExitStatus(
                            $sshHost->cmd('command -v '.$command.';echo $?')
                        );
                        if (!$response['status']) {
                            // throw new CHttpException(
                            //     500, 
                            //     'Could not find the scedular command(s).'.
                            //     ' Please configure the enviroment properly.'
                            // );
                        }
                    }
                    $sshHost->disconnect();
                    Yii::app()->cache->set("schedulerLoaded", true, 1800);
                } else {
                    throw new CHttpException(
                        500, 
                        'Unable to access the job submission ".
"host due to authentication problem.'
                    );
                }
            } else {
                throw new CHttpException(
                    500, 'Please load the list of scheduler commands.'
                );
            }
        }
        return; 
    }
    
    /**
     * Validate licence file
     *
     * @param string $license    licence content
     * @param string $public_key public key for validating licence.
     *
     * @return array licence components
     */
    function checkKey($license, $public_key)
    {
        $productName = 'GJSP Grid Engine';
        $lic_unreg = array(
            'Product-Name' => $productName,
            'Product-Version' => '2.x',
            'Registered-To' => 'Unregistered',
            'Issued-On' => '25-Aug-2015',
            'Expired-On' => '25-Aug-2099',
            'Application-Count' => '1',
            'Portal-ID' => 'Unregistered',
            'License-Key' => 'Unregistered',
            'User-Count' => '1',
        );
        $lic_component = GUtils::parseLicString($license);
        if ($lic_component === false) {
            return $lic_unreg;
        }
        // Check all keys are available
        $lic_reg = array();
        foreach ($lic_unreg as $key => $val) {
            if (!array_key_exists($key, $lic_component)) {
                return $lic_unreg;
            }
            $lic_reg[$key] = $lic_component[$key];
        }
        if ($productName !== $lic_component['Product-Name']) {
            return $lic_unreg;
        }
        $iv = 'Product-Name = ' . $lic_component['Product-Name'] . "\n" .
              'Product-Version = ' . $lic_component['Product-Version'] . "\n" .
              'Registered-To = ' . $lic_component['Registered-To'] . "\n" .
              'Issued-On = ' . $lic_component['Issued-On'] . "\n" .
              'Expired-On = ' . $lic_component['Expired-On'] . "\n" .
              'Application-Count = ' .$lic_component['Application-Count'] . "\n" .
              'User-Count = ' . $lic_component['User-Count'] . "\n" .
              'Portal-ID = ' . $lic_component['Portal-ID'];
        $signature = base64_decode($lic_component['License-Key']);
        $pubkeyid = openssl_get_publickey($public_key);
        $ok = openssl_verify($iv, $signature, $pubkeyid);
        openssl_free_key($pubkeyid);
        if ($ok === 1) {
            $portalId = Yii::app()->params->GCMP['portalid'];
            if (($portalId === $lic_component['Portal-ID'])
                || (substr($lic_component['Portal-ID'], 0, 4) === 'TEMP')
            ) {
                return $lic_reg;
            } else {
                return $lic_unreg;
            }
        } else {
            return $lic_unreg;
        }
    }

    /**
     * DB connection
     *
     * @return string
     */
    public static function gcmpDb() 
    {
        $database = include dirname(__FILE__) . '/../config/database.php';
        $gcmpDb = new CDbConnection(
            $database['connectionString'], 
            $database['username'], 
            $database['password']
        );
        $gcmpDb->active=true;
        return $gcmpDb;
    }

    /**
     * Return list
     *
     * @return Data
     */
    public static function jspslurmDb() 
    {
        if (file_exists(dirname(__FILE__) . '/../../slurm/config/database.php')) {
            $database = include dirname(__FILE__) .
             '/../../slurm/config/database.php';
            $jspslurmDb = new CDbConnection(
                $database['connectionString'],
                $database['username'],
                $database['password']
            );
            $jspslurmDb->active=true;
            return $jspslurmDb;
        } else {
            return false;
        }
    }

    //This
    /**
     * Return list
     *
     * @return Data
     */
    public static function getPermissionType()
    {
        return array(
        'action'=>'Action',
        'region'=>'Region',
        'application'=>'Application',
        'iamRole'=>'IAM Role Permissions'
        );
    }

    /**
     * Return list
     *
     * @return Data
     */
    public static function getPermissionTypeRegion()
    {
        return array(
        'vpc'=>'VPC',
        'keypair'=>'KeyPair',
        'ami'=>'AMIs'
        );
    }

    /**
     * Return list
     *
     * @return Data
     */
    public static function getAllActions()
    {
        return array(
        'vpc'=>'1',
        'subnet'=>'2',
        'instance'=>'3'
        );
    }

    /**
     * Return list
     * 
     * @param string $userId userId
     *
     * @return Data
     */
    public static function getGcmpRoleId($userId)
    {
        $query = "SELECT role_id FROM gcmp_user WHERE id::int=".$userId;
        $data = self::gcmpDb()->createCommand($query)->queryAll();
        return $data[0]['role_id'];
    }

    /**
     * Return list
     *
     * @return Data
     */
    public static function getGcmpRoles()
    {
        $query = "SELECT * FROM gcmp_role WHERE id not in(1)";
        $data = self::gcmpDb()->createCommand($query)->queryAll();
        return CHtml::listData($data, 'id', 'name');
    }

    /**
     * Return list
     *
     * @return Data
     */
    public static function getRegions()
    {
        $roleId = self::getGcmpRoleId(Yii::app()->user->id);
        if ($roleId ==1) {
            $query = "SELECT name,display_name FROM ".
            self::$cdbPrefix."region";
        } else {
            $query = "SELECT r.name,r.display_name FROM ".
            self::$cdbPrefix."role_permission rp".
            " JOIN ".self::$cdbPrefix."region r ON rp.permission_id::int=r.id".
            " WHERE rp.role_id='".$roleId."' AND rp.type='region'";
        }
        $data = self::gcmpDb()->createCommand($query)->queryAll();
        return $data;
    }

    /**
     * Return list
     *
     * @return Data
     */
    public static function getActions()
    {
        $roleId = self::getGcmpRoleId(Yii::app()->user->id);
        if ($roleId ==1) {
            $query = "SELECT id,name FROM ".
            self::$cdbPrefix."action";
        } else {
            $query = "SELECT r.id,r.name FROM ".
            self::$cdbPrefix."role_permission rp".
            " JOIN ".self::$cdbPrefix.
            "action r ON rp.permission_id::int=r.id".
            " WHERE rp.role_id='".$roleId."' AND rp.type='action'";
        }
        $data = self::gcmpDb()->createCommand($query)->queryAll();
        return $data;
    }

    /**
     * Return list
     *
     * @return Data
     */
    public static function getApplications()
    {
        $roleId = self::getGcmpRoleId(Yii::app()->user->id);
        if ($roleId ==1) {
            $query = "SELECT name,script FROM ".
            self::$cdbPrefix."application";
        } else {
            $query = "SELECT a.name,a.script FROM ".self::$cdbPrefix.
            "role_permission rp JOIN ".self::$cdbPrefix.
            "application a ON rp.permission_id::int=a.id WHERE".
            " rp.role_id='".$roleId."' AND rp.type='application'";
        }
        $data = self::gcmpDb()->createCommand($query)->queryAll();
        return $data;
    }

    /**
     * Return list
     *
     * @return Data
     */
    public static function getIamRole()
    {
        $host = Yii::app()->params->GCMP['submitHost'];
        $sshHost = new GSsh(array('host' => $host));
        $sshHost->getConnected();
        $sshHost->authenticateAuto(1);

        $roleId = self::getGcmpRoleId(Yii::app()->user->id);
        if ($roleId ==1) {
            $data = json_decode(
                $sshHost->cmd(
                    GcmpUtils::$awsPrefix.
                    "aws iam list-instance-profiles --query".
                    " \"InstanceProfiles[].Roles[].RoleName\""
                ), true
            );
            $permission_id = array();
            foreach ($data as $key => $value) {
                $permission_id[$key]['permission_id'] = $value;
            }
            return $permission_id;
        } else {
            $query = "SELECT permission_id FROM ".self::$cdbPrefix."role_permission".
            " WHERE role_id='".$roleId."' AND type='iamRole'";
            $data = self::gcmpDb()->createCommand($query)->queryAll();
            return $data;
        }
    }

    /**
     * Return list
     * 
     * @param string $region region
     *
     * @return Data
     */
    public static function getKeypair($region)
    {
        $host = Yii::app()->params->GCMP['submitHost'];
        $sshHost = new GSsh(array('host' => $host));
        $sshHost->getConnected();
        $sshHost->authenticateAuto(1);

        $roleId = self::getGcmpRoleId(Yii::app()->user->id);
        if ($roleId ==1) {
            $keypairs = json_decode(
                $sshHost->cmd(
                    GcmpUtils::$awsPrefix.
                    "aws ec2 describe-key-pairs --region ".$region
                ), true
            );
            $data = $keypairs['KeyPairs'];
            $permission_id = array();
            foreach ($data as $key => $value) {
                $permission_id[$key]['permission_id'] = $value["KeyName"];
            }
            return $permission_id;
        } else {
            $query = "SELECT permission_id FROM ".self::$cdbPrefix.
            "role_permission_rg".
            " WHERE role_id='".$roleId.
            "' AND type='keypair' AND region='".$region."'";
            $data = self::gcmpDb()->createCommand($query)->queryAll();
            return $data;
        }
    }

    /**
     * Return list
     * 
     * @param string $region region
     *
     * @return Data
     */
    public static function getVpc($region)
    {
        $roleId = self::getGcmpRoleId(Yii::app()->user->id);
        if ($roleId ==1) {
            $query = "SELECT vpc_id as permission_id,vpc_name".
            " as display_name FROM ".self::$cdbPrefix."vpc where region='".
            $region."' and is_deleted=FALSE";
        } else {
            $query = "SELECT permission_id,display_name FROM ".
            self::$cdbPrefix."role_permission_rg".
            " WHERE role_id='".$roleId."' AND type='vpc' AND region='".
            $region."'";
        }
        $data = self::gcmpDb()->createCommand($query)->queryAll();
        return $data;
    }

    /**
     * Return list
     * 
     * @param string $region region
     *
     * @return Data
     */
    public static function getAmi($region)
    {
        $roleId = self::getGcmpRoleId(Yii::app()->user->id);
        if ($roleId ==1) {
            $query = "SELECT ami_id,ami_name FROM ".
            self::$cdbPrefix."ami where region='".$region."'";
        } else {
            $query = "SELECT ami.ami_id, ami.ami_name FROM ".self::$cdbPrefix.
            "role_permission_rg as p".
            " JOIN ".self::$cdbPrefix."ami as ami ON p.permission_id=ami.ami_id".
            "  WHERE p.role_id='".$roleId."' AND p.type='ami' AND p.region='".
            $region."'";
        }
        $data = self::gcmpDb()->createCommand($query)->queryAll();
        return $data;
    }

    /**
     * Return list
     *
     * @return Data
     */
    public static function checkVpcPermission()
    {
        $allActions = GcmpUtils::getAllActions();
        $actionPermissions = GcmpUtils::getActions();
        $actionPermissionsIds = array();
        foreach ($actionPermissions as $key => $value) {
            array_push($actionPermissionsIds, $value['id']);
        }
        $roleId = self::getGcmpRoleId(Yii::app()->user->id);
        if (in_array($allActions['vpc'], $actionPermissionsIds)
            || $roleId == 1
        ) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Return list
     *
     * @return Data
     */
    public static function checkSubnetPermission()
    {
        $allActions = GcmpUtils::getAllActions();
        $actionPermissions = GcmpUtils::getActions();
        $actionPermissionsIds = array();
        foreach ($actionPermissions as $key => $value) {
            array_push($actionPermissionsIds, $value['id']);
        }
        $roleId = self::getGcmpRoleId(Yii::app()->user->id);
        if (in_array($allActions['subnet'], $actionPermissionsIds) 
            || $roleId == 1
        ) {
            return true;
        } else {
            return false;
        }
    }

     /**
      * Return list
      *
      * @return Data
      */
    public static function checkInstancePermission()
    {
        $allActions = GcmpUtils::getAllActions();
        $actionPermissions = GcmpUtils::getActions();
        $actionPermissionsIds = array();
        foreach ($actionPermissions as $key => $value) {
            array_push($actionPermissionsIds, $value['id']);
        }
        $roleId = self::getGcmpRoleId(Yii::app()->user->id);
        if (in_array($allActions['instance'], $actionPermissionsIds) 
            || $roleId == 1
        ) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Return list
     *
     * @return Data
     */
    public static function checkManager()
    {
        $roleId = self::getGcmpRoleId(Yii::app()->user->id);
        if ($roleId == 1) {
            return true;
        } else {
            return false;
        }
    }
}
