<?php
/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  GCMP
 * @author   Anirudh Gurumurthi <anirudh.gurumurthi@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * Creates the required menu for portal
 *
 * @category Job_Submission_Portal
 * @package  GCMP
 * @author   Anirudh Gurumurthi <anirudh.gurumurthi@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class TopNavMenu extends CComponent
{
    private $_menuAlerts = array();
    private $_addonMenus = array();
    /**
     * Loads the controller
     *
     * @param Array $menuAlerts Menu alerts if any
     *
     * @return NULL
     */  
    public function __construct($menuAlerts = array()) 
    {
        $this->_menuAlerts = $menuAlerts;
        $this->_addonMenus = self::_getAddons();
    }

    /**
     * Append addon menus in GHPCS Top Navigation
     *
     * @return array Addon Menu items
     */
    private function _getAddons() 
    {
        $addonmenu = array();
        $path = dirname(__FILE__) . '/../../../addon_menu/'
                . Yii::app()->controller->module->id;
        if (is_dir($path)) {
            $addons = scandir($path);
            foreach ($addons as $addon) {
                $file = $path . '/' . $addon;
                if (!is_dir($file) && file_exists($file)) {
                    $content = include $file;
                    if (is_array($content)) {
                        foreach ($content as $value) {
                            array_push($addonmenu, $value);
                        }
                    }
                }
            }
        }
        return $addonmenu;
    }
    /**
     * Returns the items from application, app groups
     *
     * @return Array
     */
    public function getItems() 
    {
        $controllerId = Yii::app()->controller->id;
        $actionId = Yii::app()->controller->action->id;
        $alertCount = count($this->_menuAlerts);
        $addonsCount = count($this->_addonMenus);
        return array(
            array('label' => '<i class="fa fa-dashboard"></i> Dashboard',
                'url' => array('dashboard/index'),
                'active' => $controllerId == 'dashboard' && $actionId == 'index',
            ),
            array(
                'label'=>'<i class="fa fa-th-large"></i> Accounts',
                'url'=>array('account/index'),
                'active'=>$controllerId=='account' && $actionId=='index',
                 'visible'=>Yii::app()->user->checkAccess('admin'),
            ),
            // array(
            //     'label'=>'<i class="fa fa-th-large"></i> Accounts',
            //     'url'=>array('account/assignAccount'),
            //     'active'=>$controllerId=='account' && $actionId=='index',
            //      'visible'=>!Yii::app()->user->checkAccess('admin'),
            // ),
            array(
                'label'=>'<i class="fa fa-universal-access"></i> Roles',
                'url'=>array('role/index'),
                'active'=>$controllerId=='role' && $actionId=='index',
                'visible'=>Yii::app()->user->checkAccess('admin'),
            ),
            array(
                'label'=>'<i class="fa fa-users"></i> Users',
                'url'=>array('user/index'),
                'active'=>$controllerId=='user' && $actionId=='index',
                'visible'=>Yii::app()->user->checkAccess('admin'),
            ),
            array('label' => '<i class="fa fa-tasks"></i> Permissions',
                'url' => array(''),
                'active' => $controllerId == 'permission' && in_array(
                    $actionId, array(
                    'running', 'pending', 'completed', 'holded')
                ),
                'visible'=>GcmpUtils::checkManager(),
                        'items' => array(
                        array(
                        'label' => '<i class="fa fa-tasks">'.
                '</i> Role Permissions',
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                        'url' => array('permission/modulePermissions')
                        ),
                        array(
                        'label' => '<i class="fa fa-tasks">'.
                        '</i> Role Permissions base on Region',
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                        'url' => array('permission/vpcPermissions')
                        ),
                        ),
                        'itemOptions' => array(
                        'class' => 'dropdown', 
                        'tabindex' => "-1"),
                        'linkOptions' => array(
                        'class' => 'dropdown-toggle', 
                        'data-toggle' => "dropdown"),
            ),
             array('label' => '<i class="fa fa-tasks"></i> Resources',
                'url' => array(''),
                'active' => $controllerId == 'permission' && in_array(
                    $actionId, array(
                    'running', 'pending', 'completed', 'holded')
                ),
                        'items' => array(
                        array(
                        'label' => '<i class="fa fa-tasks">'.
                '</i> Add Resources',
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                        'url' => array('region/index'),
                        'visible'=>GcmpUtils::checkManager(),
                        ),
                        array(
                        'label' => '<i class="fa fa-tasks">'.
                        '</i> Assign Resources',
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                        'url' => array('permission/index'),
                        'visible'=>GcmpUtils::checkManager(),
                        ),
                        array(
                        'label' => '<i class="fa fa-tasks">'.
                        '</i> VPC',
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                        'url' => array('resources/listVpc'),
                        'visible'=> GcmpUtils::checkVpcPermission(),
                        ),
                        array(
                        'label' => '<i class="fa fa-tasks">'.
                        '</i> Subnets',
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                        'url' => array('resources/listSubnet'),
                        'visible'=> GcmpUtils::checkSubnetPermission(),
                        ),
                        array(
                        'label' => '<i class="fa fa-tasks">'.
                        '</i> Instance',
                        'template' => '<hr style="margin:5px 10px 4px;">{menu}',
                        'url' => array('resources/listInstance'),
                        'visible'=> GcmpUtils::checkInstancePermission(),
                        ),
                        ),
                        'itemOptions' => array(
                        'class' => 'dropdown', 
                        'tabindex' => "-1"),
                        'linkOptions' => array(
                        'class' => 'dropdown-toggle', 
                        'data-toggle' => "dropdown"),
            ),
            array('label' => '<i class="fa fa-sign-in"></i> Login',
                'url' => array('/home/login'),
                'visible' => Yii::app()->user->isGuest,
            ),
            array(
            'label' => '<i class="fa fa-sign-out"></i> Logout (' . 
            Yii::app()->user->name . ')',
                'url' => array('/home/logout'),
                'visible' => !Yii::app()->user->isGuest,
            //'template'=>'| {menu}',
            ),
        );
    }

}
