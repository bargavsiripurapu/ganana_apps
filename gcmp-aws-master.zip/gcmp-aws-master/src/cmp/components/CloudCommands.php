<?php

/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category GCMP
 * @package  GCMP
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @author   Anirudh Gurumurthi <anirudh.gurumurthi@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * Cloud automates the job accounting info to database
 *
 * @category GCMP
 * @package  GCMP
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @author   Anirudh Gurumurthi <anirudh.gurumurthi@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class CloudCommands
{

    /**
     * Starts execution of Cloud Command 
     * 
     * @param string $args check vpc subnet intsnace.
     *
     * @return NULL 
     */
    public static function run($args=null) 
    {
        
        switch ($args) {
        case 'vpc':
            self::vpc();
            break;
        case 'subnet':
            self::subnet();
            break;
        case 'instance':
            self::instance();
            break; 
        }
    }

    /**
     * Starts execution of VPC Command 
     * 
     * @param string $region region data.
     *
     * @return NULL 
     */
    public static function vpc($region=null) 
    {   
        $host = Yii::app()->params->GCMP['submitHost'];
        $sshHost = new GSsh(array('host' => $host));
        $sshHost->getConnected();
        $sshHost->authenticateAuto(1);
        if ($region==null) {
            $regions = GcmpRegion::model()->findAll();
        } else {
            $regions = GcmpRegion::model()->findAll("name='".$region."'");
        }
        $vpcIds = array();
        //This is foreach for Regions
        foreach ($regions as $key => $value) {
            $cmd = GcmpUtils::$awsPrefix."aws ec2 describe-vpcs --region ".
            $value->name;
            $vpcData = json_decode($sshHost->cmd($cmd), true);
            $vpcList = $vpcData['Vpcs'];
            //This foreach for All VPCs
            if (isset($vpcList)) {
                foreach ($vpcList as $keyVPC => $valueVPC) {
                    array_push($vpcIds, $valueVPC['VpcId']);
                    $query = "SELECT * FROM gcmp_vpc WHERE vpc_id='".
                    $valueVPC['VpcId']."'";
                    $data = GcmpUtils::gcmpDb()->createCommand($query)->queryAll();
                    if (empty($data)) {
                        $model = new GcmpVpc();
                        $model->vpc_id = $valueVPC['VpcId'];
                        if (isset($valueVPC['Tags'])) {
                            foreach ($valueVPC['Tags'] as $tags) {
                                if ($tags['Key']=="Name") {
                                    $model->vpc_name = $tags['Value'];
                                }
                            } 
                        } else {
                            $model->vpc_name = "";
                        }
                        $model->cidr_block = $valueVPC['CidrBlock'];
                        $model->region = $value->name;
                        $model->info = json_encode($valueVPC, true);
                        $model->save();
                    } else {
                        $record = GcmpVpc::model()->findByPk($data[0]['id']);
                        if (isset($valueVPC['Tags'])) {
                            foreach ($valueVPC['Tags'] as $tags) {
                                if ($tags['Key']=="Name") {
                                    $record->vpc_name = $tags['Value'];
                                }
                            } 
                        } else {
                            $record->vpc_name = "";
                        }
                        $record->cidr_block = $valueVPC['CidrBlock'];
                        $record->region = $value->name;
                        $record->info = json_encode($valueVPC, true);
                        $record->save();
                    }
                }
            }
        }
        if ($region==null) {
            $tableVps = GcmpVpc::model()->findAll();
        } else {
            $tableVps = GcmpVpc::model()->findAll("region='".$region."'");
        }
        $tableVpsIds = array();
        foreach ($tableVps as $vpcs) {
            array_push($tableVpsIds, $vpcs->vpc_id);
        }
        $diffData = array_diff($tableVpsIds, $vpcIds);
        if (isset($diffData)) {
            foreach ($diffData as $keyFinal => $valueFinal) {
                $queryDel = "UPDATE gcmp_vpc SET is_deleted=TRUE".
                " WHERE vpc_id='".$valueFinal."'";
                GcmpUtils::gcmpDb()->createCommand($queryDel)->execute();
            }
        }

    }

    /**
     * Starts execution of VPC Command 
     * 
     * @param string $region region data.
     *
     * @return NULL 
     */
    public static function subnet($region=null) 
    {   
        $host = Yii::app()->params->GCMP['submitHost'];
        $sshHost = new GSsh(array('host' => $host));
        $sshHost->getConnected();
        $sshHost->authenticateAuto(1);
        if ($region==null) {
            $regions = GcmpRegion::model()->findAll();
        } else {
            $regions = GcmpRegion::model()->findAll("name='".$region."'");
        }
        $subnetIds = array();
        //This is foreach for Regions
        foreach ($regions as $key => $value) {
            $cmd = GcmpUtils::$awsPrefix."aws ec2 describe-vpcs --region ".
            $value->name;
            $vpcData = json_decode($sshHost->cmd($cmd), true);
            $vpcList = $vpcData['Vpcs'];
            //This foreach for All Subnets
            if (isset($vpcList)) {
                foreach ($vpcList as $keyVPC => $valueVPC) {
                    $cmd = GcmpUtils::$awsPrefix."aws ec2 describe-subnets".
                    " --filters \"Name=vpc-id,Values=".
                    $valueVPC["VpcId"]."\" --region ".$value->name;
                    $subnetData = json_decode($sshHost->cmd($cmd), true);
                    $subnetList = $subnetData['Subnets'];
                    //This foreach for All Subnets
                    if (isset($subnetList)) {
                        foreach ($subnetList as $keySubnet => $valueSubnet) {
                            array_push($subnetIds, $valueSubnet["SubnetId"]);
                            $query = "SELECT * FROM gcmp_subnet WHERE subnet_id='".
                            $valueSubnet["SubnetId"]."'";
                            $data = GcmpUtils::gcmpDb()->createCommand(
                                $query
                            )->queryAll();
                            if (empty($data)) {
                                        $model = new GcmpSubnet();
                                        $model->subnet_id = $valueSubnet["SubnetId"];
                                if (isset($valueSubnet['Tags'])) {
                                    foreach ($valueSubnet['Tags'] as $tags) {
                                        if ($tags['Key']=="Name") {
                                            $model->subnet_name = $tags['Value'];
                                        }
                                    } 
                                } else {
                                    $model->subnet_name = "";
                                }
                                $model->cidr_block = $valueSubnet['CidrBlock'];
                                $model->region = $value->name;
                                $model->vpc_id = $valueVPC["VpcId"];
                                $model->info = json_encode($valueSubnet, true);
                                $model->save();
                            } else {
                                        $pkId = $data[0]['id'];
                                    $record = GcmpSubnet::model()->findByPk($pkId);
                                if (isset($valueSubnet['Tags'])) {
                                    foreach ($valueSubnet['Tags'] as $tags) {
                                        if ($tags['Key']=="Name") {
                                            $model->subnet_name = $tags['Value'];
                                        }
                                    } 
                                } else {
                                    $model->subnet_name = "";
                                }
                                $record->cidr_block = $valueSubnet['CidrBlock'];
                                $record->region = $value->name;
                                $record->vpc_id = $valueVPC["VpcId"];
                                $record->info = json_encode($valueSubnet, true);
                                $record->save();
                            }
                    
                        }
                    }
                }
            }
        }
        if ($region==null) {
            $tableSubnet = GcmpSubnet::model()->findAll();
        } else {
            $tableSubnet = GcmpSubnet::model()->findAll(("region='".$region."'"));
        }
        $tableSubnetIds = array();
        foreach ($tableSubnet as $subnet) {
            array_push($tableSubnetIds, $subnet->subnet_id);
        }
        $diffData = array_diff($tableSubnetIds, $subnetIds);
        if (isset($diffData)) {
            foreach ($diffData as $keyFinal => $valueFinal) {
                $queryDel = "UPDATE gcmp_subnet SET is_deleted=TRUE WHERE".
                " subnet_id='".$valueFinal."'";
                GcmpUtils::gcmpDb()->createCommand($queryDel)->execute();
            }
        }

    }

    /**
     * Starts execution of VPC Command 
     * 
     * @param string $region region data.
     *
     * @return NULL 
     */
    public static function instance($region=null) 
    {   
        $host = Yii::app()->params->GCMP['submitHost'];
        $sshHost = new GSsh(array('host' => $host));
        $sshHost->getConnected();
        $sshHost->authenticateAuto(1);
        if ($region==null) {
            $regions = GcmpRegion::model()->findAll();
        } else {
            $regions = GcmpRegion::model()->findAll("name='".$region."'");
        }
        $instanceIds = array();
        //This is foreach for Regions
        $runnigInstances = 0;
        foreach ($regions as $key => $value) {
            $cmd = GcmpUtils::$awsPrefix."aws ec2 describe-instances --region ".
            $value->name;
            $instanceData = json_decode($sshHost->cmd($cmd), true);
            $instanceList = $instanceData['Reservations'];
            //This foreach for All VPCs
            if (isset($instanceList)) {
                foreach ($instanceList as $keyInstance => $valinstc) {
                    array_push(
                        $instanceIds, 
                        $valinstc['Instances'][0]['InstanceId']
                    );
                    if ($valinstc['Instances'][0]['State']['Name'] == "running") {
                        $runnigInstances = $runnigInstances+1;
                    }
                    $query = "SELECT * FROM gcmp_instance WHERE instance_id='".
                    $valinstc['Instances'][0]['InstanceId']."'";
                    $data = GcmpUtils::gcmpDb()->createCommand($query)->queryAll();
                    if (empty($data)) {
                        $model = new GcmpInstance();
                        $iniId = $valinstc['Instances'][0]['InstanceId'];
                        $model->instance_id = $iniId;
                        if (isset($valinstc['Instances'][0]['Tags'])) {
                            foreach ($valinstc['Instances'][0]['Tags'] as $tags) {
                                if ($tags['Key']=="Name") {
                                    $model->instance_name = $tags['Value'];
                                }
                            } 
                        } else {
                            $model->instance_name = "";
                        }
                        $pubIP = $valinstc['Instances'][0];
                        $pubIP = isset($pubIP['PublicIpAddress']) ? 
                        $pubIP['PublicIpAddress'] : '';
                        $priIP = $valinstc['Instances'][0];
                        $priIP = isset($priIP['PrivateIpAddress']) ? 
                        $priIP['PrivateIpAddress'] : '';
                        $model->public_ip = $pubIP;
                        $model->private_ip = $priIP;
                        $vpcID = isset($valinstc['Instances'][0]['VpcId']) ?
                         $valinstc['Instances'][0]['VpcId'] : '';
                        $model->vpc_id = $vpcID;
                        $state = $valinstc['Instances'][0]["State"]["Name"];
                        $model->instance_state = $state;
                        $model->region = $value->name;
                        $model->info = json_encode($valinstc['Instances'][0], true);
                        $model->save();
                    } else {
                        $record = GcmpInstance::model()->findByPk($data[0]['id']);
                        if (isset($valinstc['Instances'][0]['Tags'])) {
                            foreach ($valinstc['Instances'][0]['Tags'] as $tags) {
                                if ($tags['Key']=="Name") {
                                    $record->instance_name = $tags['Value'];
                                }
                            } 
                        } else {
                            $record->instance_name = "";
                        }
                        $pubIP = $valinstc['Instances'][0];
                        $pubIP = isset($pubIP['PublicIpAddress']) ? 
                        $pubIP['PublicIpAddress'] : '';
                        $priIP = $valinstc['Instances'][0];
                        $priIP = isset($priIP['PrivateIpAddress']) ? 
                        $priIP['PrivateIpAddress'] : '';
                        $record->public_ip = $pubIP;
                        $record->private_ip = $priIP;
                        $vpcID = isset($valinstc['Instances'][0]['VpcId']) ? 
                         $valinstc['Instances'][0]['VpcId'] : '';
                        $record->vpc_id = $vpcID;
                        $state = $valinstc['Instances'][0]["State"]["Name"];
                        $record->instance_state = $state;
                        $record->region = $value->name;
                        $record->info = json_encode($valinstc['Instances'][0], true);
                        $record->save();
                    }
                }
            }
        }
        
        $dshbrdQry = "SELECT * FROM gcmp_dashboard WHERE account_number='".
                    GcmpUtils::$accountNumber."'";
        $dataDashboard = GcmpUtils::gcmpDb()->createCommand($dshbrdQry)->queryAll();
        if (empty($dataDashboard)) {
            $dashboardQuery = "INSERT INTO gcmp_dashboard (account_number,".
            "account_name,running) VALUES ('".GcmpUtils::$accountNumber."','".
            GcmpUtils::$accountName."',".$runnigInstances.")";
        } else {
            $dashboardQuery = "UPDATE gcmp_dashboard SET running = ".
            $runnigInstances." WHERE account_number = '".
            GcmpUtils::$accountNumber."'";
        }
        GcmpUtils::gcmpDb()->createCommand($dashboardQuery)->execute();
        if ($region==null) {
            $tableInstance = GcmpInstance::model()->findAll();
        } else {
            $tableInstance = GcmpInstance::model()->findAll(
                ("region='".
                $region."'")
            );
        }
        $tableInstanceIds = array();
        foreach ($tableInstance as $instance) {
            array_push($tableInstanceIds, $instance->instance_id);
        }
        $diffData = array_diff($tableInstanceIds, $instanceIds);
        if (isset($diffData)) {
            foreach ($diffData as $keyFinal => $valueFinal) {
                $queryDel = "UPDATE gcmp_instance  SET is_deleted=TRUE WHERE".
                " instance_id='".$valueFinal."'";
                GcmpUtils::gcmpDb()->createCommand($queryDel)->execute();
            }
        }

    }

    /**
     * Starts execution of VPC Command 
     * 
     * @param string $region region data.
     *
     * @return NULL 
     */
    public static function ami($region=null) 
    {   
        $host = Yii::app()->params->GCMP['submitHost'];
        $sshHost = new GSsh(array('host' => $host));
        $sshHost->getConnected();
        $sshHost->authenticateAuto(1);
        if ($region==null) {
            $regions = GcmpRegion::model()->findAll();
        } else {
            $regions = GcmpRegion::model()->findAll("name='".$region."'");
        }
        $amiIds = array();
        //This is foreach for Regions
        foreach ($regions as $key => $value) {

            $amis = json_decode(
                $sshHost->cmd(
                    GcmpUtils::$awsPrefix.
                    "aws ec2 describe-images --owners amazon --filters".
                    " 'Name=name,Values=amzn2-ami-hvm-2.0.????????.?".
                    "-x86_64-gp2' 'Name=state,Values=available' --query ".
                    "'Images[*].[ImageId,Description]' --region ".
                    $value->name
                ), true
            );
       
            $amis1 = json_decode(
                $sshHost->cmd(
                    GcmpUtils::$awsPrefix.
                    "aws ec2 describe-images --owners amazon ".
                    "--filters 'Name=name,Values=amzn-ami-hvm-????.".
                    "??.?.????????-x86_64-gp2' 'Name=state,Values=available' ".
                    "--query 'Images[*].[ImageId,Description]' --region ".
                    $value->name
                ), true
            );
            $amisList = array();
            if (isset($amis) || isset($amis1)) {
                $amisList = array_merge($amis, $amis1);
            }

            $amis2 = json_decode(
                $sshHost->cmd(
                    GcmpUtils::$awsPrefix.
                    "aws ec2 describe-images --owners 099720109477  ".
                    "--filters 'Name=name,Values=ubuntu/images/hvm-ssd/".
                    "ubuntu-xenial-16.04-amd64-server-????????' ".
                    "'Name=state,Values=available' --query ".
                    "'Images[*].[ImageId,Description]' --region ".
                    $value->name
                ), true
            );
            if (isset($amis2)) {
                 $amisList = array_merge($amisList, $amis2);
            }

            $amis3 = json_decode(
                $sshHost->cmd(
                    GcmpUtils::$awsPrefix.
                    "aws ec2 describe-images --owners 309956199498  ".
                    "--filters 'Name=name,Values=RHEL-7.5_HVM_GA*' ".
                    "'Name=state,Values=available' --query ".
                    "'Images[*].[ImageId,Description]' --region ".
                    $value->name
                ), true
            );
            if (isset($amis3)) {
                 $amisList = array_merge($amisList, $amis3);
            }
            $amis4 = json_decode(
                $sshHost->cmd(
                    GcmpUtils::$awsPrefix.
                    "aws ec2 describe-images --owners amazon --filters ".
                    "'Name=name,Values=suse-sles-15-v????????-hvm-ssd-x86_64' ".
                    "'Name=state,Values=available' --query ".
                    "'Images[*].[ImageId,Description]' --region ".
                    $value->name
                ), true
            );
            if (isset($amis4)) {
                 $amisList = array_merge($amisList, $amis4);
            }

            //This foreach for All VPCs
            if (isset($amisList)) {
                foreach ($amisList as $keyAMI => $valueAMI) {
                    array_push($amiIds, $valueAMI[0]);
                    $query = "SELECT * FROM gcmp_ami WHERE ami_id='".
                    $valueAMI[0]."'";
                    $data = GcmpUtils::gcmpDb()->createCommand($query)->queryAll();
                    if (empty($data)) {
                        $model = new GcmpAmi();
                        $model->ami_id = $valueAMI[0];
                        $model->ami_name = $valueAMI[1];
                        $model->region = $value->name;
                        $model->save();
                    } else {
                        $record = GcmpAmi::model()->findByPk($data[0]['id']);
                        $record->ami_id = $valueAMI[0];
                        $record->ami_name = $valueAMI[1];
                        $record->region = $value->name;
                        $record->save();
                    }
                }
            }
        }
        if ($region==null) {
            $tableAmi = GcmpAmi::model()->findAll();
        } else {
            $tableAmi = GcmpAmi::model()->findAll("region='".$region."'");
        }
        $tableAmiIds = array();
        foreach ($tableAmi as $ami) {
            array_push($tableAmiIds, $ami->ami_id);
        }
        $diffData = array_diff($tableAmiIds, $amiIds);
        if (isset($diffData)) {
            foreach ($diffData as $keyFinal => $valueFinal) {
                $queryDel = "DELETE FROM gcmp_ami WHERE ami_id='".$valueFinal."'";
                GcmpUtils::gcmpDb()->createCommand($queryDel)->execute();
            }
        }
    }
}
?>
