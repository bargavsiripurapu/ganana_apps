<?php
/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * GjspUtils is helper class for Ganana Job Submission Portal Module Application
 * it consists multiple helper functions
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class AwsTerraform
{
    /**
     * Read GCMP configurations from db and load into application variable
     *
     * @param string $region region data.
     *
     * @return NULL
     */
    public static function loadAws($region) 
    {
        $aws = "
                  provider \"aws\" {
                    version = \"~> 2.0\"
                    access_key = \"".GcmpUtils::$awsAccessKey."\"
                    secret_key = \"".GcmpUtils::$awsSecretKey."\"
                    region     = \"".$region."\"
                  }";
        return $aws;
    }

    /**
     * Returns Instance Template
     *
     * @param string $post post data.
     *
     * @return template
     */
    public static function getVpcTemplate($post)
    {
        $host = Yii::app()->params->GCMP['submitHost'];
        $sshHost = new GSsh(array('host' => $host));
        $sshHost->getConnected();
        $sshHost->authenticateAuto(1);
        $zonesCmd = GcmpUtils::$awsPrefix. "aws ec2 describe-availability-zones".
        " --query \"AvailabilityZones[].ZoneName\" --region".$post['region'];

          $availabilityZones = json_decode($sshHost->cmd($zonesCmd), true);
            // create the VPC
            $template = self::loadAws($post['region']).PHP_EOL."
            resource \"aws_vpc\" \"My_VPC1\" {
              cidr_block           = \"".$post['vpcCIDRblock']."\"
              instance_tenancy     = \"".$post['instanceTenancy']."\"
              enable_dns_support   = \"".$post['dnsSupport']."\"
              enable_dns_hostnames = \"".$post['dnsHostNames']."\"
            tags = {
                Name = \"".$post['vpcName']."\"
            }
            } 

            # Create the Security Group
            resource \"aws_security_group\" \"publicAccessSecurityGroup\" {
              vpc_id       = aws_vpc.My_VPC1.id
              name         = \"My VPC Security Group\"
              description  = \"My VPC Security Group\"
               
              # allow egress of all ports
              ingress  {
                from_port   = 22
                to_port     = 22
                protocol    = \"tcp\"
                cidr_blocks = [\"0.0.0.0/0\"]
              }
            tags = {
               Name = \"sshPublicSecurityGroup\"
               Description = \"My VPC Security Group\"
            }
            }
             # end resource

            # Create the Internet Gateway
            resource \"aws_internet_gateway\" \"My_VPC_GW\" {
             vpc_id = aws_vpc.My_VPC1.id
            tags = {
                    Name = \"Ganana Internet Gateway\"
            }
            } 
            # end resource

            # Create the Route Table
            resource \"aws_route_table\" \"My_VPC_route_table\" {
             vpc_id = aws_vpc.My_VPC1.id
            tags = {
                    Name = \"Ganana Route Table\"
            }
            }
            # end resource

            resource \"aws_subnet\" \"Public_Subnet\" {
              vpc_id                  = aws_vpc.My_VPC1.id
              cidr_block              = \"10.0.1.0/24\"
              map_public_ip_on_launch = \"true\"
              availability_zone       = \"$availabilityZones[0]\"
            tags = {
               Name = \"Public_Subnet\"
            }
            }

            # Associate the Route Table with the Subnet
            resource \"aws_route_table_association\" \"VPC_association\" {
              subnet_id      = aws_subnet.Public_Subnet.id
              route_table_id = aws_route_table.My_VPC_route_table.id
            } 
            # end resource

            ";
        $dir = date("Ymdhis.", time())."vpc";
        $rootDir="/opt/terraform";
        $template = base64_encode($template);
        $commands= "sudo mkdir -p $rootDir/$dir;".
        "sudo chmod 777 $rootDir/$dir;sudo echo '".
        $template."'| base64 --decode >> $rootDir/$dir/$dir.tf";
        $sshHost->cmd($commands);
        $init = "cd $rootDir/$dir/;sudo terraform init;".
        "sudo terraform plan -out ganana.plan;";
        $sshHost->cmd($init);
        $plan = "cd $rootDir/$dir/;sudo terraform apply ganana.plan";
        $show = "cd $rootDir/$dir/;sudo terraform show | grep -rnw id |".
        " grep \"vpc-\" | awk -F \":\" '{print $4}'";
        $sshHost->cmd($plan);
        $result = $sshHost->cmd($show);
        $model = new GcmpTerraformScript;
        $model->name = $post['vpcName'];
        $model->script = $template;
        $model->user_name = Yii::app()->user->name;
        $model->type = "VPC";
        $model->save();
        $result = trim($result);
        $result = trim($result, ",");
        return trim($result, '"');
    }

    /**
     * Returns Instance Template
     *
     * @param string $post post data.
     *
     * @return template
     */
    public static function getSubnetTemplate($post)
    {
        $host = Yii::app()->params->GCMP['submitHost'];
        $sshHost = new GSsh(array('host' => $host));
        $sshHost->getConnected();
        $sshHost->authenticateAuto(1);
        $template = self::loadAws($post['region']).PHP_EOL;
        $subnetType = $post['subnetType'];
        $subnetCIDR = $post['subnetCIDR'];
        $availabilityZone = $post['availabilityZone'];
        $subnetName = $post['subnetName'];
        if (count($subnetType) == count($subnetCIDR)) {

            for ($i=0;$i<count($subnetType); $i++) {
                if ($subnetType[$i] == "Public") {
                    $publicIP = "true";
                } else if ($subnetType[$i] == "Private") {
                    $publicIP = "false";
                }
                $template = $template.PHP_EOL."
          resource \"aws_subnet\" \"My_VPC_Subnet".($i+1)."\" {
            vpc_id                  = \"".$post['vpcId']."\"
            cidr_block              = \"".$subnetCIDR[$i]."\"
            map_public_ip_on_launch = \"".$publicIP."\"
            availability_zone       = \"".$availabilityZone[$i]."\"
          tags = {
             Name = \"".$subnetName[$i]."\"
          }
          } 
          ";
                // end subnet
            }
        }
        $dir = date("Ymdhis.", time())."subnet";
        $rootDir="/opt/terraform";
        $template = base64_encode($template);
        $commands= "sudo mkdir -p $rootDir/$dir;".
        "sudo chmod 777 $rootDir/$dir;sudo echo '".
        $template."'| base64 --decode >> $rootDir/$dir/$dir.tf";
        $sshHost->cmd($commands);
        $init = "cd $rootDir/$dir/;sudo terraform init;".
        "sudo terraform plan -out ganana.plan;";
        $sshHost->cmd($init);
        $plan = "cd $rootDir/$dir/;sudo terraform apply ganana.plan";
        $show = "cd $rootDir/$dir/;sudo terraform show | grep -rnw id |".
        " cut -d ':' -f 4 | sed -n '2'p";
        $sshHost->cmd($plan);
        $result = $sshHost->cmd($show);
        $model = new GcmpTerraformScript;
        $model->name = $post['subnetName'];
        $model->script = $template;
        $model->user_name = Yii::app()->user->name;
        $model->type = "Subnet";
        $model->save();
        $result = trim($result);
        $result = trim($result, ",");
        return trim($result, '"');
    }

    /**
     * Returns Instance Template
     *
     * @param string $post post data.
     *
     * @return template
     */
    public static function getInstanceTemplate($post)
    {
        $host = Yii::app()->params->GCMP['submitHost'];
        $sshHost = new GSsh(array('host' => $host));
        $sshHost->getConnected();
        $sshHost->authenticateAuto(1);

        $noOfInstances = $post['noOfInstances'];
        $template = self::loadAws($post['region']).PHP_EOL;
        for ($k=0;$k<$noOfInstances;$k++) {
            $template = $template.PHP_EOL."
              resource \"aws_instance\" \"instance".($k+1)."\" {
                  ami = \"".$post['ami']."\"
                  instance_type = \"".$post['instanceType']."\"

                  # VPC 
                  subnet_id = \"".$post['subnetId']."\"

                  # the Public SSH key
                  key_name = \"".$post['keypair']."\"

                  #instance name
                  tags    = {
                    Name  = \"".$post['instanceName']."\"
                  }
                  
                  #the user data 
                  user_data_base64 = \"".base64_encode($post['application'])."\"

                  #the iam_instance_profile
                  iam_instance_profile = \"".$post['iamRole']."\"

                  #vpc_security_group_ids 

                  vpc_security_group_ids = [\"".$post['securityGroup']."\"]

              }
              ";
        }
            // end Instance
        $dir = date("Ymdhis.", time())."instance";
        $rootDir="/opt/terraform";
        $template = base64_encode($template);
        $commands= "sudo mkdir -p $rootDir/$dir;".
        "sudo chmod 777 $rootDir/$dir;sudo echo '".
        $template."'| base64 --decode >> $rootDir/$dir/$dir.tf";
        $sshHost->cmd($commands);
        $init = "cd $rootDir/$dir/;sudo terraform init;".
        "sudo terraform plan -out ganana.plan;";
        $sshHost->cmd($init);
        $plan = "cd $rootDir/$dir/;sudo terraform apply ganana.plan";
        $show = "cd $rootDir/$dir/;sudo terraform show | grep -rnw id |".
        " cut -d ':' -f 4 | sed -n '2'p";
        $sshHost->cmd($plan);
        $result = $sshHost->cmd($show);
        $model = new GcmpTerraformScript;
        $model->name = "Instance";
        $model->script = $template;
        $model->user_name = Yii::app()->user->name;
        $model->type = "Instance";
        $model->save();
        $result = trim($result);
        $result = trim($result, ",");
        return trim($result, '"');

    }

}
