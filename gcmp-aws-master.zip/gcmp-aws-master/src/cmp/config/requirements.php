<?php
/**
 * This is the SGE Scheduler list of commands
 *
 * PHP version 5.3
 *
 * @category  Ganana
 * @package   GSGE
 * @author    Santosh Kumar Gupta <santosh.gupta@locuz.com>
 * @copyright 2012 - 2016 Locuz Enterprise Solutions Ltd.
 * @license   Locuz Proprietary License
 * @link      http://www.locuz.com
 */

// This is the GHPCS Module application configuration.
    return array(
        'qconf',
        'qstat',
        'qhold',
        'qrls',
        'qdel',
        'qhost',
        'qacct',
        'qsub'
    );
    ?>
