<?php

/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category GCMP
 * @package  GCMP
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @author   Anirudh Gurumurthi <anirudh.gurumurthi@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * Cloud automates the job accounting info to database
 *
 * @category GCMP
 * @package  GCMP
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @author   Anirudh Gurumurthi <anirudh.gurumurthi@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class CloudCommand extends CConsoleCommand
{

    /**
     * Starts execution of VPC Command
     *
     * @param string $args Parameter
     *
     * @return NULL
     */
    public function run($args = null) 
    {
        GcmpUtils::loadConfig();
        $portalActivity = GcmpPortalActivity::model()->find("id=1");
        if (empty($portalActivity)) {
            CloudCommands::vpc();
            CloudCommands::subnet();
            CloudCommands::instance();
            CloudCommands::region();
        } else {
            if ((time() - strtotime($portalActivity->last_loaded)) < 300) {
                switch ($args[0]) {
                case 'vpc':
                    CloudCommands::vpc();
                    break;
                case 'subnet':
                    CloudCommands::subnet();
                    break;
                case 'instance':
                    CloudCommands::instance();
                    break;
                case 'ami':
                    CloudCommands::ami();
                    break;
                case 'region':
                    CloudCommands::region();
                    break;
                }
            } else {
                echo "No activity from last 5 minutes";
            }
        }
    }

}
?>
