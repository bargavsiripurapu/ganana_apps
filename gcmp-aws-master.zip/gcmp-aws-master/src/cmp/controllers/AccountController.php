<?php
/**
 * GCMP controllers
 *
 * PHP version 5.3
 *
 * @category Ganana
 * @package  GCMP
 * @author   Anirudh Gurumurthi <anirudh.gurumurthi@locuz.com>
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  Locuz Proprietary License
 * @link     http://www.locuz.com
 */

/**
 * User controller
 * Manage Users
 *
 * @category Controller
 * @package  GCMP
 * @author   Anirudh Gurumurthi <anirudh.gurumurthi@locuz.com>
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  Locuz Proprietary License
 * @link     http://www.locuz.com
 */
class AccountController extends Controller
{
    /**
     * Specify the application alert generation rules
     * This method is used by beforeAction
     *
     * @return array alert generation rules
     */
    public function alertRules()
    {
        return array(
            'actions'=>array('index', 'view', 'update', 'role', 'password')
        );
    }

    /**
     * Default view layout
     *
     * @var string the default layout for the views. Defaults to '//layouts/column2',
     * meaning using two-column layout. See 'protected/views/layouts/column2.php'.
     */
    public $layout='//layouts/column2';

    /**
     * Access control filters
     *
     * @return array action filters
     */
    public function filters()
    {
        return array(
            'accessControl', // perform access control for CRUD operations
            'postOnly + delete', // we only allow deletion via POST request
        );
    }
    /**
     * Executes before action if needed
     * 
     * @param Object $action Action Object
     *
     * @return NULL No Return
     */
    public function beforeAction($action) 
    {
        parent::beforeAction();
        if (in_array($action->getId(), array('importt', 'export'))) {
            foreach (Yii::app()->log->routes as $route) {
                if ($route instanceof CWebLogRoute) {
                    $route->enabled = false;
                }
            }
        }
        return true;
    }

    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     *
     * @return array access control rules
     */
    public function accessRules()
    {
        return array(
            array(
                // allow authenticated user to perform 'view' and 'update' actions
                'allow',
                'actions'=>array('index','view','update','add','assignAccount',
                    'removeAccount'),
                'users'=>array('@'),
            ),
            array(
                // allow admin role to perform 'index' and 'delete' actions
                'allow',
                'actions'=>array('delete','role','password'),
                'roles'=>array('admin'),
            ),
            array('deny',  // deny all users
                'users'=>array('*'),
            ),
        );
    }

    /**
     * Index action
     *
     * @return @see Yii document
     */
    public function actionIndex()
    {
        if (!Yii::app()->user->checkAccess('admin')) {
            $this->redirect(array('view','id'=>Yii::app()->user->id));
        }
        $model=new GcmpAccount('search');
        $model->unsetAttributes();  // clear any default values
        if (isset($_GET['GcmpAccount'])) {
            $model->attributes=$_GET['GcmpAccount'];
        }
        $this->render('index', array('model'=>$model,));
    }

    /**
     * Returns the data model based on the primary key given in the GET variable.
     * If the data model is not found, an HTTP exception will be raised.
     *
     * @param integer $id the ID of the model to be loaded
     *
     * @throws CHttpException
     *
     * @return User the loaded model
     */
    public function loadModel($id)
    {
        $model=GcmpAccount::model()->findByPk($id);
        if ($model===null) {
            throw new CHttpException(404, 'The requested page does not exist.');
        }
        return $model;
    }

    /**
     * Displays a particular model.
     *
     * Creating 
     *
     * @return @see Yii documentation
     */
    public function actionAdd()
    {
        $host = Yii::app()->params->GCMP['submitHost'];
        $sshHost = new GSsh(array('host' => $host));
        $sshHost->getConnected();
        $sshHost->authenticateAuto(1);

        $model = new GcmpAccount();
        if (!Yii::app()->user->checkAccess('updateSelfInfo', array('User'=>$model))
            && !Yii::app()->user->checkAccess('admin')
        ) {
            throw new CHttpException(
                403, 
                'You are not authorized to perform this action'
            );
        }
        if (isset($_POST['GcmpAccount'])) {
            $cloud = $_POST['cloud'];
            $model->attributes=$_POST['GcmpAccount'];
            $model->manager_id=1;
            if ($model->validate()) {
                if ($cloud == "aws") {
                      $response = $this->_validateAWSAccount($model, "added");
                      // $model->save();
                } else if ($cloud == "oracle") {
                    $profile = $_POST['profile'];
                    $model->profile_name=$profile;
                    $profileData = $sshHost->cmd(
                        'while IFS= read -r line;'.
                        ' do echo "$line<<"; done <  /root/.oci/config'
                    );    
                    $profileData = explode("<<", $profileData);
                    $profileDataLines = array();
                    foreach ($profileData as $key => $value) {
                        if ($value == $profile) {
                            array_push(
                                $profileDataLines, 
                                trim($profileData[$key+1])
                            );
                            array_push(
                                $profileDataLines, 
                                trim($profileData[$key+2])
                            );
                            array_push(
                                $profileDataLines, 
                                trim($profileData[$key+3])
                            );
                            array_push(
                                $profileDataLines, 
                                trim($profileData[$key+4])
                            );
                            array_push(
                                $profileDataLines, 
                                trim($profileData[$key+5])
                            );
                        }
                    }
                    $profileInfo = array();
                    foreach ($profileDataLines as $keyLines => $valueLines) {
                               $splitVal = explode("=", $valueLines);
                               $profileInfo[$splitVal[0]] = $splitVal[1];
                    }
                    $profileInfo = json_encode($profileInfo);
                    $model->profile_info=$profileInfo;
                    $response = $this->_validateOracleAccount($model, "added");
                    $model->cloud_id=2;
                    $model->save();
                        
                }
                Yii::app()->user->setFlash(
                    $response[0],
                    $response[1]
                );
                /*
                if ($response[0] == "success") {

                    $host = Yii::app()->params->GCMP['submitHost'];
                    $sshHost = new GSsh(array('host' => $host));
                    $sshHost->getConnected();
                    $sshHost->authenticateAuto(1);
                    $dbCommand = "RFJPUCBEQVRBQkFTRSBJRiBFWElTVFMgZGJuYW1lOw0KQ1J".
                    "FQVRFIERBVEFCQVNFIGRibmFtZSBXSVRIIEVOQ09ESU5HPSdVVEYtOCc7DQp".
                    "DUkVBVEUgVVNFUiBkYnVzZXI7DQpBTFRFUiBVU0VSIGRidXNlciBXSVRIIFBB".
                    "U1NXT1JEICdkYnBhc3N3ZCcgTk9DUkVBVEVEQiBOT0NSRUFURVVTRVI7DQpBT".
                    "FRFUiBEQVRBQkFTRSBkYm5hbWUgT1dORVIgVE8gZGJ1c2VyOw0KR1JBTlQgQU".
                    "xMIFBSSVZJTEVHRVMgT04gREFUQUJBU0UgZGJuYW1lIFRPIGRidXNlcjsNCg==";
                    $dbCommand = base64_decode($dbCommand);
                    $shrtNm = $model->short_name;
                    $dbCommand = str_replace("dbname", "g".$shrtNm."db", $dbCommand);
                    $dbCommand=str_replace("dbuser", "g".$shrtNm, $dbCommand);
                    $replaceVar = "g".$shrtNm."123";
                    $dbCommand=str_replace("dbpasswd", $replaceVar, $dbCommand);
                    $sqlFile = "/data_vol/webapp/ghpcs_apps/cmp/".
                    $model->short_name.".sql";
                    fopen($sqlFile, "w");
                    file_put_contents($sqlFile, $dbCommand);
                    $dbCommand = "ZG9ja2VyIGV4ZWMgLXQgZ2FuYW5hX2NvbnRyb2xsZXIgYm".
                    "FzaCAtYyAnc3UgLSBwb3N0Z3JlcyAtYyAicHNxbCAtZiBmaWxlbmFtZSIn";
                    $dbCommand = base64_decode($dbCommand);
                    $dbCommand = str_replace("filename", $sqlFile, $dbCommand);
                    $dataSql = $sshHost->cmd("sudo ".$dbCommand);

                    unlink($sqlFile);
                    $cmd = "cd /opt/locuz/ganana/vol/webapp/ghpcs_apps/cmp/;".
                    "bash -x account_install.sh ".
                    $model->short_name." ".$model->account_number." \"".
                    $model->name."\"";
                    $sshHost->cmd($cmd);
                    $queryModule = "INSERT INTO ghpcs_module".
                    " (name,is_sub_module) VALUES ('".
                    $_POST['GcmpAccount']['short_name']."',true)";
                    Yii::app()->authDb->createCommand($queryModule)->execute();
                    $qMId = "SELECT id FROM ghpcs_module WHERE name='".
                    $_POST['GcmpAccount']['short_name']."'";
                    $modData = Yii::app()->authDb->createCommand($qMId)->queryAll();
                    $lastModuleId = $modData[0]['id'];
                    $qrModPer = "INSERT INTO ghpcs_module_permissions".
                    " (module_id,user_id) VALUES ('".$lastModuleId."','".
                    $_POST['user']."')";
                    Yii::app()->authDb->createCommand($qrModPer)->execute();
                    $this->redirect(array('view', 'id'=>$model->id));
                }
                */
            }
        }
        //    $oracleCmd = "grep -Po '\[\K[^]]*' /root/.oci/config | ".
        // "sed ':a;N;$!ba;s/\\\n/,/g' | awk -F "."\\\t"." '{print \"[\"$0\"]\"}'";
        // $oracleProfiles = $sshHost->cmd($oracleCmd);
        // if (!empty($oracleProfiles)) {
        //     $oracleProfiles = explode(',', $oracleProfiles);
        // }
        $this->render(
            'add',
            array(
                'model'=>$model,
                //'oracleProfiles'=>$oracleProfiles
            )
        );
    }

    /**
     * Displays a particular model.
     *
     * @param integer $id the ID of the model to be displayed
     *
     * @return @see Yii documentation
     */
    public function actionView($id)
    {
        $model=$this->loadModel($id);
        if (!Yii::app()->user->checkAccess('updateSelfInfo', array('User'=>$model))
            && !Yii::app()->user->checkAccess('admin')
        ) {
            throw new CHttpException(
                403,
                'You are not authorized to perform this action'
            );
        }
        $this->render(
            'view',
            array(
                'model'=>$model,
            )
        );
    }

    /**
     * Updates a particular model.
     * If update is successful, the browser will be redirected to the 'view' page.
     *
     * @param integer $id the ID of the model to be updated
     *
     * @return @see Yii document
     */
    public function actionUpdate($id)
    {
        $model=$this->loadModel($id);

        // Uncomment the following line if AJAX validation is needed
        // $this->performAjaxValidation($model);

        if (!Yii::app()->user->checkAccess('updateSelfInfo', array('User'=>$model))
            && !Yii::app()->user->checkAccess('admin')
        ) {
            throw new CHttpException(
                403,
                'You are not authorized to perform this action'
            );
        }
        if (isset($_POST['GcmpAccount'])) {
            $manager_id = $model->manager_id;
            $model->attributes=$_POST['GcmpAccount'];
            if ($model->validate()) {
                      $response = $this->_validateAWSAccount($model, "updated");
                      // $model->save();
                Yii::app()->user->setFlash(
                    $response[0],
                    $response[1]
                );
                if ($response[0] == "success") {
                    $qMId = "SELECT id FROM ghpcs_module WHERE name='".
                    $_POST['GcmpAccount']['short_name']."'";
                    $modData = Yii::app()->authDb->createCommand($qMId)->queryAll();
                    $lastModuleId = $modData[0]['id'];
                    $qrModPer = "UPDATE ghpcs_module_permissions".
                    " SET user_id='".$_POST['user']."' WHERE module_id='".
                    $lastModuleId."' AND user_id='".$manager_id."'";
                    $users = Yii::app()->authDb->createCommand($qrModPer)->execute();
                       $this->redirect(array('view', 'id'=>$model->id));
                }
            }
        }

        $this->render(
            'update',
            array(
                'model'=>$model,
            )
        );
    }

    /**
     * Deletes a particular model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     *
     * @param integer $id the ID of the model to be deleted
     *
     * @return @see Yii documentation
     */
    public function actionDelete($id)
    {
            $model=$this->loadModel($id);
            $user=$model->name;
            $id=$model->id;
            $model->delete();
        if (!isset($_GET['ajax'])) {
            Yii::app()->user->setFlash(
                'success',
                'User <strong><i>' . $user . '</i></strong> deleted successfully'
            );
        } else {
            echo GUtils::FLASH(
                'success',
                'User <strong><i>' . $user . '</i></strong> deleted successfully'
            );
        } 

        // if AJAX request (triggered by deletion via index grid view),
        // we should not redirect the browser
        if (!isset($_GET['ajax'])) {
            $this->redirect(
                isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('index')
            );
        }
    }
    /**
     * Validates a particular account.
     *
     * @param object $model  the object of the account model
     * @param object $action the object of the account model
     *
     * @return @see Yii documentation
     */
    private function _validateAWSAccount($model,$action) 
    {
        $host = Yii::app()->params->GHPCS['masterserverip'];
        $sshHost = new GSsh(array('host' => $host));
        $state = "success";
        $message = "Account <strong><i>" . $model->name.
        "</i></strong> ".$action." sucessfully.";
        if ($sshHost->getConnected() && $sshHost->authenticateAuto(1)) {
               $access = $model->access_key;
               $secret = $model->secret_key;
               $account = $model->account_number;
               $cmd  = "AWS_ACCESS_KEY_ID=".$access." AWS_SECRET_ACCESS_KEY=".
             $secret." aws sts get-caller-identity --output text | ".
             "cut -f 1;\necho $?";
               $cmd = $sshHost->cmd($cmd);
               $response = explode("\n", $cmd);
            if (isset($response[1]) && (trim($response[1]) == "0")) {
                if (trim($response[0]) == $account) {
                    $model->cloud_id=1;
                    $model->short_name="cmp";
                    $model->save();
                } else {
                       $state = "error";
                       $message = "Account number <strong>".$model->account_number.
                       "</strong> is mismatch with".
                       " given access key and secret keys.".
                       " Please provide valid access key and secret key or ".
                       "valid account number.";
                }
            } else {
                $state = "error";
                $message = "Invalid response. Something goes wrong. ".
                "Please restart ganana and try again.";
            }
        } else {
               $state = "error";
            $message = "Unable to connect to host. ".
            "Please check network Settings.";
        }
        $retObj = Array($state, $message);
        return $retObj;
    }

    /**
     * Validates a particular account.
     *
     * @param object $model  the object of the account model
     * @param object $action the object of the account model
     *
     * @return @see Yii documentation
     */
    private function _validateOracleAccount($model,$action) 
    {
        // $host = Yii::app()->params->GHPCS['masterserverip'];
        // $sshHost = new GSsh(array('host' => $host));
        // $state = "success";
        // $message = "Account <strong><i>" . $model->name.
        // "</i></strong> ".$action." sucessfully.";
        // if ($sshHost->getConnected() && $sshHost->authenticateAuto(1)) {
        //        $access = $model->access_key;
        //        $secret = $model->secret_key;
        //        $account = $model->account_number;
        //        $cmd  = "AWS_ACCESS_KEY_ID=".$access." AWS_SECRET_ACCESS_KEY=".
        //      $secret." aws sts get-caller-identity --output text | ".
        //      "cut -f 1;\necho $?";
        //        $cmd = $sshHost->cmd($cmd);
        //        $response = explode("\n", $cmd);
        //     if (isset($response[1]) && (trim($response[1]) == "0")) {
        //         if (trim($response[0]) == $account) {
        //             $model->save();
        //         } else {
        //                $state = "error";
        //                $message = "Account number <strong>".
        //                  $model->account_number.
        //                "</strong> is mismatch with".
        //                " given access key and secret keys.".
        //                " Please provide valid access key and secret key or ".
        //                "valid account number.";
        //         }
        //     } else {
        //         $state = "error";
        //         $message = "Invalid response. Something goes wrong. ".
        //         "Please restart ganana and try again.";
        //     }
        // } else {
        //        $state = "error";
        //     $message = "Unable to connect to host. ".
        //     "Please check network Settings.";
        // }
        // $retObj = Array($state, $message);
        $retObj = Array("success","Oracle validation");
        return $retObj;
    }

    /**
     * Assign Module action
     *
     * @return @see Yii document
     */
    public function actionAssignAccount()
    {
        if (Yii::app()->request->isPostRequest) {
            $modulePermissions = new GhpcsModulePermissions();
            $module = GhpcsModule::model()->find("name='".$_POST['module']."'");
            $modulePermissions->module_id = $module['id'];
            $modulePermissions->user_id = $_POST['user'];
            $perCon = "user_id=".$_POST['user'].
            " and module_id=".$module['id'];
            $permissionsExists = GhpcsModulePermissions::model()->find($perCon);
            if (count($permissionsExists) > 0) {
                Yii::app()->user->setFlash(
                    'error',
                    'Module already assigned'
                );
            } else {
                if ($modulePermissions->validate() 
                    && $modulePermissions->save()
                ) {
                    Yii::app()->user->setFlash(
                        'success',
                        'Module Assigned successfully'
                    );
                } else {
                    Yii::app()->user->setFlash(
                        'error',
                        'Module not assigned'
                    );
                }
            }
            $this->redirect('assignAccount');
        }
        $query = "SELECT id,username FROM gcmp_user WHERE role_id NOT IN (1)";
        $users = GcmpUtils::gcmpDb()->createCommand($query)->queryAll();
        // $accountsCon = "manager_id=".Yii::app()->user->id;
        $accounts = GcmpAccount::model()->findAll();
        // $snames = "";
        // foreach ($accounts as $key => $value) {
        //     $snames .= ",'".$value['short_name']."'";
        // }
        // $snames = trim($snames, ",");
        $query = "SELECT m.name,m.id,mp.user_id FROM ghpcs_module m".
        " JOIN ghpcs_module_permissions mp".
        " ON mp.module_id=m.id ;";
        $permissions = Yii::app()->authDb->createCommand($query)->queryAll();
        $this->render(
            'assignAccount', 
            array(
                'users'=>$users,
                'modules'=>$accounts,
                'permissions'=>$permissions,
            )
        );
    }

    /**
     * Remove Module action
     *
     * @return @see Yii document 
     */
    public function actionRemoveAccount() 
    {
        if (isset($_POST['user_id']) && isset($_POST['module_id'])) {
            $delete = "DELETE FROM ghpcs_module_permissions".
                    " WHERE module_id=".$_POST['module_id'].
                    " AND user_id=".$_POST['user_id'];
            if (Yii::app()->authDb->createCommand($delete)->execute()) {
                Yii::app()->user->setFlash(
                    'success',
                    'Module Removed successfully'
                );
            } else {
                Yii::app()->user->setFlash(
                    'error',
                    'Module not Removed'
                );
            }
        }
    }
}
