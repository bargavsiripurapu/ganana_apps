<?php

/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  GCMP
 * @author   Anirudh Gurumurthi <anirudh.gurumurthi@locuz.com>
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */

/**
 * Dashboard Controller gives the information about torque cluster's server
 *
 * @category Job_Submission_Portal
 * @package  GCMP
 * @author   Anirudh Gurumurthi <anirudh.gurumurthi@locuz.com>
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
class DashboardController extends Controller
{

    

    /**
     * Specifies filters of the controller which requires
     *
     * @return array action filters
     */
    public function filters()
    {
        return array(
            'accessControl', // perform access control
        );
    }

    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     *
     * @return array access control rules
     */
    public function accessRules()
    {
        return array(
            array('allow', // allow everyone to perform 'error' action
                'actions' => array('error'),
                'users' => array('*'),
            ),
        );
        //     array('allow', // allow authenticated user to perform 'index' actions
        //         'actions' => array(
        //             'index',
        //             'getQueueInfo',
        //             'getHostInfo',
        //             'showchart',
        //         ),
        //         'users' => array('@'),
        //     ),
        //     array(
        //         'allow',
        //         'actions' => array('export','listUsers','delete'),
        //         'users' => array('admin','root'),
        //     ),
        //     array('deny', // deny all users
        //         'users' => array('*'),
        //     ),
        // );
    }

    /**
     * Gives the information about the cluster
     *
     * @return null
     */
    public function actionIndex()
    {
        // $model=new GcmpDashboard('search');
        // $model->unsetAttributes();  // clear any default values
        // if (isset($_GET['GcmpAccount'])) {
        //     $model->attributes=$_GET['GcmpAccount'];
        // }
        // $this->render('index', array('model'=>$model,));
        $accounts = GcmpAccount::model()->findAll();
        if (empty($accounts)) {
            Yii::app()->user->setFlash(
                'error',
                'Please add an account'
            );
            $this->redirect(array('account/add'));
        }

        $userId = Yii::app()->user->id;
        $roleId = GcmpUtils::getGcmpRoleId($userId);
        if ($roleId == 1) {
            $vpcList = GcmpVpc::model()->findAll("is_deleted=FALSE");
            $instanceList = GcmpInstance::model()->findAll("is_deleted=FALSE");
        } else {
            $condtion = "created_by='".$userId."'  and is_deleted=FALSE";
            $vpcList = GcmpVpc::model()->findAll($condtion);
            $condtion = "created_by='".$userId."' and is_deleted=FALSE";
            $instanceList = GcmpInstance::model()->findAll($condtion);
        }
        $this->render(
            'index', array(
                'vpcList'=>$vpcList,
                'instanceList'=>$instanceList,
             )
        );
            
    }

    /**
     * This is the action to handle external exceptions.
     *
     * @return null
     */
    public function actionError()
    {
        if ($error = Yii::app()->errorHandler->error) {
            if (Yii::app()->request->isAjaxRequest) {
                echo $error['message'];
            } else {
                $this->render('//home/error', $error);
            }
        }
    }
    /**
     * This is the action to handle external exceptions.
     *
     * @return null
     */
    public function actionStartInstance()
    {
        $host = Yii::app()->params->GCMP['submitHost'];
        $sshHost = new GSsh(array('host' => $host));
        $sshHost->getConnected();
        $sshHost->authenticateAuto(1);
        if (isset($_POST['instanceId']) && !empty($_POST['instanceId'])) {
            $cmd = GcmpUtils::$awsPrefix."aws ec2 start-instances --instance-ids ".
            $_POST['instanceId'];
            $sshHost->cmd($cmd);
            CloudCommands::instance();
        }
    }

    /**
     * This is the action to handle external exceptions.
     *
     * @return null
     */
    public function actionStopInstance()
    {
        $host = Yii::app()->params->GCMP['submitHost'];
        $sshHost = new GSsh(array('host' => $host));
        $sshHost->getConnected();
        $sshHost->authenticateAuto(1);
        if (isset($_POST['instanceId']) && !empty($_POST['instanceId'])) {
            $cmd = GcmpUtils::$awsPrefix."aws ec2 stop-instances --instance-ids ".
            $_POST['instanceId'];
            $sshHost->cmd($cmd);
            CloudCommands::instance();
        }
    }

    /**
     * This is the action to handle external exceptions.
     *
     * @return null
     */
    public function actionTertminateInstance()
    {
        $host = Yii::app()->params->GCMP['submitHost'];
        $sshHost = new GSsh(array('host' => $host));
        $sshHost->getConnected();
        $sshHost->authenticateAuto(1);
        if (isset($_POST['instanceId']) && !empty($_POST['instanceId'])) {
            $cmd = GcmpUtils::$awsPrefix."aws ec2 terminate-instances".
            " --instance-ids ".$_POST['instanceId'];
            $sshHost->cmd($cmd);
            CloudCommands::instance();
        }
    }
    
    
}

