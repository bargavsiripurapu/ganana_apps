<?php
/**
 * GHPCS controllers
 *
 * PHP version 5.3
 *
 * @category  Ganana
 * @package   GHPCS
 * @author    Santosh Kumar Gupta <santosh.gupta@locuz.com>
 * @copyright 2012 - 2016 Locuz Enterprise Solutions Ltd.
 * @license   Locuz Proprietary License
 * @link      http://www.locuz.com
 */

/**
 * User controller
 * Manage Users
 *
 * @category Controller
 * @package  GHPCS
 * @author   Santosh Kumar Gupta <santosh.gupta@locuz.com>
 * @license  Locuz Proprietary License
 * @link     http://www.locuz.com
 */
class ApplicationController extends Controller
{
    /**
     * Specify the application alert generation rules
     * This method is used by beforeAction
     *
     * @return array alert generation rules
     */
    public function alertRules()
    {
        return array(
            'actions'=>array('index', 'view', 'update', 'role',
             'password','listInstnaces','installApplication',
             'assignAppToUser')
        );
    }

    /**
     * Default view layout
     *
     * @var string the default layout for the views. Defaults to '//layouts/column2',
     * meaning using two-column layout. See 'protected/views/layouts/column2.php'.
     */
    public $layout='//layouts/column2';

    /**
     * Access control filters
     *
     * @return array action filters
     */
    public function filters()
    {
        return array(
            'accessControl', // perform access control for CRUD operations
            'postOnly + delete', // we only allow deletion via POST request
        );
    }
    /**
     * Executes before action if needed
     * 
     * @param Object $action Action Object
     *
     * @return NULL No Return
     */
    public function beforeAction($action) 
    {
        parent::beforeAction();
        if (in_array($action->getId(), array('importt', 'export'))) {
            foreach (Yii::app()->log->routes as $route) {
                if ($route instanceof CWebLogRoute) {
                    $route->enabled = false;
                }
            }
        }
        return true;
    }

    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     *
     * @return array access control rules
     */
    public function accessRules()
    {
        return array(
            array(
                // allow authenticated user to perform 'view' and 'update' actions
                'allow',
                'actions'=>array('index','view','update','create',
                    'listInstnaces','installApplication','assignAppToUser'),
                'users'=>array('@'),
            ),
            array(
                // allow admin role to perform 'index' and 'delete' actions
                'allow',
                'actions'=>array('delete','role','password'),
                'roles'=>array('admin'),
            ),
            array('deny',  // deny all users
                'users'=>array('*'),
            ),
        );
    }

    /**
     * Index action
     *
     * @return @see Yii document
     */
    public function actionIndex()
    {
        /*if (!Yii::app()->user->checkAccess('admin')) {
            $this->redirect(array('view','id'=>Yii::app()->user->id));
        }*/
        $model=new GcmpApplication('search');
        $model->unsetAttributes();  // clear any default values
        if (isset($_GET['GcmpApplication'])) {
            $model->attributes=$_GET['GcmpApplication'];
        }
        $this->render('index', array('model'=>$model,));
    }

    /**
     * Returns the data model based on the primary key given in the GET variable.
     * If the data model is not found, an HTTP exception will be raised.
     *
     * @param integer $id the ID of the model to be loaded
     *
     * @throws CHttpException
     *
     * @return User the loaded model
     */
    public function loadModel($id)
    {
        $model=GcmpApplication::model()->findByPk($id);
        if ($model===null) {
            throw new CHttpException(404, 'The requested page does not exist.');
        }
        return $model;
    }

    /**
     * Displays a particular model.
     *
     * Creating 
     *
     * @return @see Yii documentation
     */
    public function actionCreate()
    {
        $model = new GcmpApplication();
        /*if (!Yii::app()->user->checkAccess('updateSelfInfo', array('User'=>$model))
            && !Yii::app()->user->checkAccess('admin')
        ) {
            throw new CHttpException(
                403, 
                'You are not authorized to perform this action'
            );
        }*/
        if (isset($_POST['GcmpApplication'])) {
            $model->attributes=$_POST['GcmpApplication'];
            if ($model->validate() && $model->save()) {
                Yii::app()->user->setFlash(
                    'success',
                    'Application <strong><i>' . $model->name
                    . '</i></strong> Created successfully'
                );
                $this->redirect(array('view', 'id'=>$model->id));
            }
        }
        $this->render(
            'create',
            array(
                'model'=>$model,
            )
        );
    }

    /**
     * Displays a particular model.
     *
     * @param integer $id the ID of the model to be displayed
     *
     * @return @see Yii documentation
     */
    public function actionView($id)
    {
        $model=$this->loadModel($id);
        /*if (!Yii::app()->user->checkAccess('updateSelfInfo', array('User'=>$model))
            && !Yii::app()->user->checkAccess('admin')
        ) {
            throw new CHttpException(
                403,
                'You are not authorized to perform this action'
            );
        }*/
        $this->render(
            'view',
            array(
                'model'=>$model,
            )
        );
    }

    /**
     * Updates a particular model.
     * If update is successful, the browser will be redirected to the 'view' page.
     *
     * @param integer $id the ID of the model to be updated
     *
     * @return @see Yii document
     */
    public function actionUpdate($id)
    {
        $model=$this->loadModel($id);

        // Uncomment the following line if AJAX validation is needed
        // $this->performAjaxValidation($model);

        /*if (!Yii::app()->user->checkAccess('updateSelfInfo', array('User'=>$model))
            && !Yii::app()->user->checkAccess('admin')
        ) {
            throw new CHttpException(
                403,
                'You are not authorized to perform this action'
            );
        }*/
        if (isset($_POST['GcmpApplication'])) {
            $model->attributes=$_POST['GcmpApplication'];
            if ($model->save()) {
                Yii::app()->user->setFlash(
                    'success',
                    'Application <strong><i>' . $model->name
                    . '</i></strong> updated successfully'
                );
            }
            $this->redirect(array('view', 'id'=>$model->id));
        }

        $this->render(
            'update',
            array(
                'model'=>$model,
            )
        );
    }

    /**
     * Deletes a particular model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     *
     * @param integer $id the ID of the model to be deleted
     *
     * @return @see Yii documentation
     */
    public function actionDelete($id)
    {
            $model=$this->loadModel($id);
            $user=$model->name;
            $id=$model->id;
            $model->delete();
        if (!isset($_GET['ajax'])) {
            Yii::app()->user->setFlash(
                'success',
                'User <strong><i>' . $user . '</i></strong> deleted successfully'
            );
        } else {
            echo GUtils::FLASH(
                'success',
                'User <strong><i>' . $user . '</i></strong> deleted successfully'
            );
        } 

        // if AJAX request (triggered by deletion via index grid view),
        // we should not redirect the browser
        if (!isset($_GET['ajax'])) {
            $this->redirect(
                isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('index')
            );
        }
    }
    /**
     * Displays a particular model.
     *
     * @param integer $id the ID of the model to be displayed
     *
     * @return @see Yii documentation
     */
    public function actionListInstnaces($id)
    {
        $appId = base64_decode($id);
        if (!empty($id)) {
             $userId = Yii::app()->user->id;
            $roleId = GcmpUtils::getGcmpRoleId($userId);
            if ($roleId == 1) {
                $instanceList = GcmpInstance::model()
                ->findAll("is_deleted=FALSE");
            } else {
                $condtion = "created_by='".$userId."' and is_deleted=FALSE";
                $instanceList = GcmpInstance::model()
                ->findAll($condtion);
            }
            $appData = $this->loadModel($appId);
            $this->render(
                'listInstnaces', array(
                'model'=>$appData,
                'instanceList'=>$instanceList,
                )
            );
        } else {
            $this->redirect('index');
        }
    }

    /**
     * Displays a particular model.
     *
     * @return @see Yii documentation 
     */
    public function actionInstallApplication()
    {
        $host = Yii::app()->params->GCMP['submitHost'];
        $sshHost = new GSsh(array('host' => $host));
        $sshHost->getConnected();
        $sshHost->authenticateAuto(1);

        if (isset($_POST['appId'])) {

            $appId = $_POST['appId'];
            $model=$this->loadModel($appId);
            $script = $model->script;
            $file = $model->name;
            $instances = $_POST['instances'];

            $cmd = "touch /tmp/".$file.".sh;chmod -R 777 /tmp/".
                $file.".sh; echo '".$script."' | base64 --decode >> /tmp/".
                $file.".sh";
            $sshHost->cmd($cmd);

            foreach ($instances as $key => $value) {
                $condtion = "instance_id='".$value."'";
                $instanceData = GcmpInstance::model()
                ->find($condtion);
                $node = $instanceData->instance_classification;
                if ($node == "master") {
                    $sshHost->cmd("bash /tmp/".$file.".sh");
                } else {
                    $sshHost->cmd(
                        "scp /tmp/".$file.".sh ".
                        $instanceData->instance_name.":/tmp/"
                    );
                    $sshHost->cmd(
                        "ssh ".$instanceData->instance_name.
                        " \"/bin/bash /tmp/".$file.".sh\" &"
                    );
                }
            }
            //This is for uploading XML File
            if (isset($_FILES['file'])) {
                $fileContent = simplexml_load_file($_FILES['file']['tmp_name']);
                $name = $fileContent->name;
                $script = $fileContent->script;
                $attributes = base64_decode($fileContent->attributes);
                $details = $fileContent->details;
                $query = "INSERT INTO gjspslurm_application (name,script,".
                "attributes,details) VALUES ('".$name."','".$script.
                "','".$attributes."','".$details."') RETURNING id";
                GcmpUtils::jspslurmDb()->createCommand($query)->execute();
            }
            Yii::app()->user->setFlash(
                'success',
                'Installed successfully'
            );
            $this->redirect('index');
        } else {
            $this->redirect('index');
        }
    }
    /**
     * Displays a particular model.
     *
     * @return @see Yii documentation 
     */
    public function actionAssignAppToUser()
    {
        if (!empty($_POST)) {
            $appId = $_POST['appId'];
            $userIds = $_POST['userId'];
            if (!empty($userIds) && !empty($appId)) {
                foreach ($userIds as $key => $value) {
                    if (GcmpUtils::jspslurmDb()) {
                        $query = "DELETE FROM gjspslurm_app_permission ".
                        "WHERE app_id = ".$appId;
                        $data = GcmpUtils::jspslurmDb()->
                        createCommand($query)->execute();
                        $insertQuery = "INSERT INTO gjspslurm_app_permission".
                        " (app_id,type,target_id,edit_script,access_application)".
                        " values (".$appId.",'user',".$value.",true,true)";
                        GcmpUtils::jspslurmDb()->
                        createCommand($insertQuery)->execute(); 
                        Yii::app()->user->setFlash(
                            'success',
                            'Application Assigned successfully'
                        ); 
                    }
                }
            }
        }
        $users = REQUIRED::readSystemUsers();
        $query = "SELECT id,name FROM gjspslurm_application";
        $apps = '';
        if (GcmpUtils::jspslurmDb()) {
            $apps = GcmpUtils::jspslurmDb()->createCommand($query)->queryAll();
        }
        $this->render(
            'assignAppToUser', array(
            'users' => $users,
            'apps' => $apps,
            )
        );
    }
}
