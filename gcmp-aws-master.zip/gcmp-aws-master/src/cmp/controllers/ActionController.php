<?php
/**
 * GHPCS controllers
 *
 * PHP version 5.3
 *
 * @category  Ganana
 * @package   GHPCS
 * @author    Santosh Kumar Gupta <santosh.gupta@locuz.com>
 * @copyright 2012 - 2016 Locuz Enterprise Solutions Ltd.
 * @license   Locuz Proprietary License
 * @link      http://www.locuz.com
 */

/**
 * User controller
 * Manage Users
 *
 * @category Controller
 * @package  GHPCS
 * @author   Santosh Kumar Gupta <santosh.gupta@locuz.com>
 * @license  Locuz Proprietary License
 * @link     http://www.locuz.com
 */
class ActionController extends Controller
{
    /**
     * Specify the application alert generation rules
     * This method is used by beforeAction
     *
     * @return array alert generation rules
     */
    public function alertRules()
    {
        return array(
            'actions'=>array('index', 'view', 'update', 'role', 'password')
        );
    }

    /**
     * Default view layout
     *
     * @var string the default layout for the views. Defaults to '//layouts/column2',
     * meaning using two-column layout. See 'protected/views/layouts/column2.php'.
     */
    public $layout='//layouts/column2';

    /**
     * Access control filters
     *
     * @return array action filters
     */
    public function filters()
    {
        return array(
            'accessControl', // perform access control for CRUD operations
            'postOnly + delete', // we only allow deletion via POST request
        );
    }
    /**
     * Executes before action if needed
     * 
     * @param Object $action Action Object
     *
     * @return NULL No Return
     */
    public function beforeAction($action) 
    {
        parent::beforeAction();
        if (in_array($action->getId(), array('importt', 'export'))) {
            foreach (Yii::app()->log->routes as $route) {
                if ($route instanceof CWebLogRoute) {
                    $route->enabled = false;
                }
            }
        }
        return true;
    }

    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     *
     * @return array access control rules
     */
    public function accessRules()
    {
        return array(
            array(
                // allow authenticated user to perform 'view' and 'update' actions
                'allow',
                'actions'=>array('index','view','update','create'),
                'users'=>array('@'),
            ),
            array(
                // allow admin role to perform 'index' and 'delete' actions
                'allow',
                'actions'=>array('delete','role','password'),
                'roles'=>array('admin'),
            ),
            array('deny',  // deny all users
                'users'=>array('*'),
            ),
        );
    }

    /**
     * Index action
     *
     * @return @see Yii document
     */
    public function actionIndex()
    {
        // if (!Yii::app()->user->checkAccess('admin')) {
        // $this->redirect(array('view','id'=>Yii::app()->user->id));
        // }
        $model=new GcmpAction('search');
        $model->unsetAttributes();  // clear any default values
        if (isset($_GET['GcmpAction'])) {
            $model->attributes=$_GET['GcmpAction'];
        }
        $this->render('index', array('model'=>$model,));
    }

    /**
     * Returns the data model based on the primary key given in the GET variable.
     * If the data model is not found, an HTTP exception will be raised.
     *
     * @param integer $id the ID of the model to be loaded
     *
     * @throws CHttpException
     *
     * @return User the loaded model
     */
    public function loadModel($id)
    {
        $model=GcmpAction::model()->findByPk($id);
        if ($model===null) {
            throw new CHttpException(404, 'The requested page does not exist.');
        }
        return $model;
    }

    /**
     * Displays a particular model.
     *
     * Creating 
     *
     * @return @see Yii documentation
     */
    public function actionCreate()
    {
        $model = new GcmpAction();
        /*if (!Yii::app()->user->checkAccess('updateSelfInfo', array('User'=>$model))
            && !Yii::app()->user->checkAccess('admin')
        ) {
            throw new CHttpException(
                403, 
                'You are not authorized to perform this action'
            );
        }*/
        if (isset($_POST['GcmpAction'])) {
            $model->attributes=$_POST['GcmpAction'];
            if ($model->validate() && $model->save()) {
                Yii::app()->user->setFlash(
                    'success',
                    'Module <strong><i>' . $model->name
                    . '</i></strong> Created successfully'
                );
                $this->redirect(array('view', 'id'=>$model->id));
            }
        }
        $this->render(
            'create',
            array(
                'model'=>$model,
            )
        );
    }

    /**
     * Displays a particular model.
     *
     * @param integer $id the ID of the model to be displayed
     *
     * @return @see Yii documentation
     */
    public function actionView($id)
    {
        $model=$this->loadModel($id);
        /*if (!Yii::app()->user->checkAccess('updateSelfInfo', array('User'=>$model))
            && !Yii::app()->user->checkAccess('admin')
        ) {
            throw new CHttpException(
                403,
                'You are not authorized to perform this action'
            );
        }*/
        $this->render(
            'view',
            array(
                'model'=>$model,
            )
        );
    }

    /**
     * Updates a particular model.
     * If update is successful, the browser will be redirected to the 'view' page.
     *
     * @param integer $id the ID of the model to be updated
     *
     * @return @see Yii document
     */
    public function actionUpdate($id)
    {
        $model=$this->loadModel($id);

        // Uncomment the following line if AJAX validation is needed
        // $this->performAjaxValidation($model);

        /*if (!Yii::app()->user->checkAccess('updateSelfInfo', array('User'=>$model))
            && !Yii::app()->user->checkAccess('admin')
        ) {
            throw new CHttpException(
                403,
                'You are not authorized to perform this action'
            );
        }*/
        if (isset($_POST['GcmpAction'])) {
            $model->attributes=$_POST['GcmpAction'];
            if ($model->save()) {
                Yii::app()->user->setFlash(
                    'success',
                    'Module <strong><i>' . $model->name
                    . '</i></strong> updated successfully'
                );
            }
            $this->redirect(array('view', 'id'=>$model->id));
        }

        $this->render(
            'update',
            array(
                'model'=>$model,
            )
        );
    }

    /**
     * Deletes a particular model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     *
     * @param integer $id the ID of the model to be deleted
     *
     * @return @see Yii documentation
     */
    public function actionDelete($id)
    {
            $model=$this->loadModel($id);
            $user=$model->name;
            $id=$model->id;
            $model->delete();
        if (!isset($_GET['ajax'])) {
            Yii::app()->user->setFlash(
                'success',
                'User <strong><i>' . $user . '</i></strong> deleted successfully'
            );
        } else {
            echo GUtils::FLASH(
                'success',
                'User <strong><i>' . $user . '</i></strong> deleted successfully'
            );
        } 

        // if AJAX request (triggered by deletion via index grid view),
        // we should not redirect the browser
        if (!isset($_GET['ajax'])) {
            $this->redirect(
                isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('index')
            );
        }
    }

}
