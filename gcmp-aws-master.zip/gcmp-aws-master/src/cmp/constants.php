<?php
/**
 * PHP version PHP 5.3.3 (cli) (built: Jul  9 2015 17:39:00)
 *
 * @category Job_Submission_Portal
 * @package  SGE_PORTAL
 * @author   Rajesh Mayara <rajesh.mayara@locuz.com>
 * @license  http://www.locuz.com/in/developer/tools/php_cs/licence Locuz Licence
 * @link     https://ditlab.locuz.com/package/PHP_CodeSniffer
 * @since    GIT: 2.0
 */
/**
 * AES Encrytion/Decrytion Cypher Key
 * Don not change at all except at installation time.
 */
define('AES_CYPHER_KEY',  md5('Locuz Enterprise Solutions Limited'));
/**
 * Ajax Request's Response Codes
 */
define('SUCCESS', 100);
define('INVALID_REQUEST', 101);
define('DATABASE_ERROR', 102);
define('COMMAND_ERROR', 103);
define('AUTHENTICATION_ERROR', 104);
define('INVALID_ACCESS', 105);
define('UN_AUTH_ACCESS', 106);
define('UNKNOWN_ERROR', 107);

